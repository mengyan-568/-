"""Test search extraction quality"""
import requests, re, html as html_mod, urllib.parse, sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept-Language': 'zh-CN,zh;q=0.9',
}

def clean_html(text):
    if not text:
        return ""
    text = re.sub(r'<[^>]+>', '', text)
    text = html_mod.unescape(text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

def test_search(engine, url_template, result_pattern, title_pattern, snippet_pattern, kw):
    print(f'\n{"="*60}')
    print(f'  {engine}: {kw}')
    print(f'{"="*60}')
    try:
        url = url_template.format(q=urllib.parse.quote(kw))
        r = requests.get(url, headers=headers, timeout=15)
        r.encoding = 'utf-8'
        text = r.text

        blocks = re.findall(result_pattern, text, re.DOTALL)
        print(f'  Found {len(blocks)} result blocks')

        for i, b in enumerate(blocks[:8]):
            t_match = re.search(title_pattern, b, re.DOTALL) if title_pattern else None
            s_match = re.search(snippet_pattern, b, re.DOTALL) if snippet_pattern else None

            title = clean_html(t_match.group(1)) if t_match else ""
            snippet = clean_html(s_match.group(1)) if s_match else ""

            # Fallback: just grab any text in the block
            if not snippet:
                snippet = clean_html(b)[:200]

            print(f'  [{i}] {title[:80]}')
            print(f'      {snippet[:150]}')
            print()
    except Exception as e:
        print(f'  Failed: {e}')

# --- Test 1: 搜狗搜索 ---
test_search(
    "搜狗搜索",
    "https://www.sogou.com/web?query={q}",
    r'<div class="vrwrap[^"]*"[^>]*>(.*?)</div>\s*</div>',
    r'<a[^>]*id="[^"]*"[^>]*>(.*?)</a>',
    r'<p[^>]*class="[^"]*star[^"]*"[^>]*>(.*?)</p>',
    "卫生纸 配送 评价"
)

# --- Test 2: 搜狗微信搜索 (weixin.sogou.com) ---
test_search(
    "搜狗微信",
    "https://weixin.sogou.com/weixin?type=2&query={q}",
    r'<li[^>]*class="news-list-item[^"]*"[^>]*>(.*?)</li>',
    r'<h3[^>]*><a[^>]*>(.*?)</a>',
    r'<p[^>]*class="txt-info[^"]*"[^>]*>(.*?)</p>',
    "卫生纸 配送 差评"
)

# --- Test 3: 百度搜索 ---
test_search(
    "百度搜索",
    "https://www.baidu.com/s?wd={q}&rn=10",
    r'<div[^>]*class="result[^"]*c-container[^"]*"[^>]*>(.*?)</div>\s*</div>\s*</div>',
    r'<h3[^>]*><a[^>]*>(.*?)</a>',
    r'<span[^>]*class="content-right_[^"]*"[^>]*>(.*?)</span>',
    "卫生纸 配送 评价 差评"
)

# --- Test 4: 直接搜索评论内容 ---
for query in [
    "卫生纸 配送 太慢了 差评",
    "卫生纸 物流 投诉",
    "大连 卫生纸 配送 吐槽",
]:
    print(f'\n--- 搜狗: {query} ---')
    try:
        url = "https://www.sogou.com/web?query=" + urllib.parse.quote(query)
        r = requests.get(url, headers=headers, timeout=15)
        r.encoding = 'utf-8'
        text = r.text
        blocks = re.findall(r'<div class="vrwrap[^"]*"[^>]*>(.*?)</div>\s*</div>', text, re.DOTALL)
        print(f'  Blocks: {len(blocks)}')
        for b in blocks[:4]:
            title_match = re.search(r'<a[^>]*id="[^"]*"[^>]*>(.*?)</a>', b, re.DOTALL)
            snip = re.search(r'<p[^>]*class="[^"]*star[^"]*"[^>]*>(.*?)</p>', b, re.DOTALL)
            title = clean_html(title_match.group(1)) if title_match else ""
            snippet = clean_html(snip.group(1)) if snip else clean_html(b)[:200]
            print(f'    [{len(title)}] {title[:80]}')
            print(f'    [{len(snippet)}] {snippet[:150]}')
            print()
    except Exception as e:
        print(f'  Failed: {e}')
