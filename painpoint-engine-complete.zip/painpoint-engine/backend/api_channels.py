"""
官方商机渠道 API — 平台导航 + 爬虫抓取 + AI 分析
"""
import json, logging, os
from datetime import datetime
from fastapi import APIRouter, Query
from pydantic import BaseModel
from collectors.official_channels import OfficialChannelCrawler, get_all_platforms


logger = logging.getLogger("channels_api")
router = APIRouter(prefix="/api/channels", tags=["官方商机渠道"])

class CrawlRequest(BaseModel):
    city: str = "大连"
    use_ai: bool = True

@router.get("/platforms")
def get_platforms():
    platforms = get_all_platforms()
    return {"total": len(platforms), "platforms": platforms, "note": "所有平台均为真实官方/商业网站，可直接点击跳转。"}

@router.post("/crawl")
def crawl_channels(req: CrawlRequest):
    logger.info("开始抓取官方商机渠道: city=%s", req.city)
    crawler = OfficialChannelCrawler(city=req.city)
    return crawler.crawl_all()

@router.post("/analyze")
def crawl_and_analyze(req: CrawlRequest):
    logger.info("抓取+AI分析: city=%s", req.city)
    crawler = OfficialChannelCrawler(city=req.city)
    crawl_result = crawler.crawl_all()
    ai_analysis = _run_ai_analysis(crawl_result) if req.use_ai else _fallback_analysis(crawl_result)
    return {
        "city": req.city, "analyzed_at": datetime.now().isoformat(),
        "crawl_result": crawl_result, "ai_analysis": ai_analysis,
        "ai_available": bool(os.environ.get("DEEPSEEK_API_KEY", "")),
    }

def _run_ai_analysis(crawl_result: dict) -> dict:
    opportunities = crawl_result.get("opportunities", [])
    if not opportunities:
        return {"note": "未抓取到商机数据"}
    by_industry = crawl_result.get("by_industry_detail", {})
    summary_parts = []
    for ind, items in by_industry.items():
        if items:
            summary_parts.append(f"- {ind}: {len(items)} 条商机")
            for item in items[:3]:
                summary_parts.append(f"  . {item.get('title', '')[:80]}")
    context = "\n".join(summary_parts) if summary_parts else "暂无商机数据"
    system_prompt = """你是商机分析专家。请基于抓取到的真实招标/货源数据，分析大连同城配送商机。

输出JSON格式：
{
  "overall_assessment": "整体评估",
  "by_industry": {
    "餐饮配送": {"opportunity_count": 0, "assessment": "行业评估", "top_opportunity": "最佳商机", "action_advice": "行动建议"},
    "生鲜冷链": {"opportunity_count": 0, "assessment": "行业评估", "top_opportunity": "最佳商机", "action_advice": "行动建议"},
    "医药配送": {"opportunity_count": 0, "assessment": "行业评估", "top_opportunity": "最佳商机", "action_advice": "行动建议"},
    "家具配送": {"opportunity_count": 0, "assessment": "行业评估", "top_opportunity": "最佳商机", "action_advice": "行动建议"},
    "商超补货": {"opportunity_count": 0, "assessment": "行业评估", "top_opportunity": "最佳商机", "action_advice": "行动建议"}
  },
  "source_channels": [
    {"category": "政府招标/企业货源/个人商家需求", "platforms": ["平台名"], "count": 0, "authority_level": "高/中/一般", "description": "数据来源说明"}
  ],
  "top_recommendations": ["建议1", "建议2", "建议3"]
}

注意：source_channels 维度必须标注每条商机来源于哪个招标网站/物流平台，证明数据来源可追溯。"""
    user_prompt = f"共抓取到 {len(opportunities)} 条大连同城配送商机，来自 {crawl_result.get('platform_stats', {})}。\n按行业分类:\n{context}\n请分析各行业的商机价值、竞争程度、盈利空间，并标注每条商机的来源渠道（政府招标/企业货源/个人商家需求）。"
    try:
        api_key = os.environ.get("DEEPSEEK_API_KEY", "")
        if api_key:
            import urllib.request
            model = os.environ.get("DEEPSEEK_MODEL", "deepseek-chat")
            base_url = os.environ.get("DEEPSEEK_BASE_URL", "https://api.deepseek.com")
            payload = json.dumps({"model":model,"messages":[{"role":"system","content":system_prompt},{"role":"user","content":user_prompt}],"temperature":0.5,"max_tokens":4096,"response_format":{"type":"json_object"}}).encode("utf-8")
            req = urllib.request.Request(f"{base_url}/v1/chat/completions",data=payload,headers={"Content-Type":"application/json","Authorization":f"Bearer {api_key}"},method="POST")
            with urllib.request.urlopen(req, timeout=90) as resp:
                result = json.loads(resp.read().decode("utf-8"))
                text = result["choices"][0]["message"]["content"].strip()
                if text.startswith("```"): text = text.split("\n",1)[1].rsplit("```",1)[0]
                return json.loads(text)
    except Exception as e:
        logger.warning(f"DeepSeek analysis failed: {e}")
    return _fallback_analysis(crawl_result)

def _fallback_analysis(crawl_result: dict) -> dict:
    by_industry = crawl_result.get("by_industry_detail", {})
    total = crawl_result.get("total_opportunities", 0)
    platform_stats = crawl_result.get("platform_stats", {})

    # Build source channel summary
    source_channels = []
    source_categories = {"政府招标": [], "企业货源": [], "个人商家需求": []}
    platforms_config = get_all_platforms()
    platform_category_map = {p["name"]: p.get("source_category", "企业货源") for p in platforms_config}

    for opp in crawl_result.get("opportunities", []):
        pname = opp.get("platform", "")
        cat = platform_category_map.get(pname, "企业货源")
        if pname not in source_categories[cat]:
            source_categories[cat].append(pname)

    for cat, plats in source_categories.items():
        if plats:
            source_channels.append({
                "category": cat,
                "platforms": plats,
                "count": sum(platform_stats.get(p, 0) for p in plats),
                "authority_level": "高" if cat == "政府招标" else ("中" if cat == "企业货源" else "一般"),
                "description": "政府/国企官方采购平台，数据权威性最高，适合长期跟踪投标" if cat == "政府招标" else ("专业物流B2B平台，企业级货源需求，适合建立长期合作" if cat == "企业货源" else "个人商家/小店实时需求，适合散单补充运力"),
            })

    analysis = {
        "overall_assessment": f"共从8个官方商机渠道抓取到 {total} 条大连同城配送相关商机。官方招标平台数据权威性最高，物流货源平台反映市场实时需求。建议优先跟进官方招标平台的采购公告。",
        "by_industry": {},
        "source_channels": source_channels,
        "top_recommendations": [
            "优先跟进大连市公共资源交易平台和辽宁政府采购网的官方招标公告",
            "关注锦程物流网和物通网的大连同城冷链货源，樱桃季前1个月锁定运力",
            "九州物流网的搬家/家具配送需求可作为补充业务",
            "中国招标投标公共服务平台的大额配送项目适合长期跟踪",
        ],
    }
    assessments = {
        "餐饮配送": {"assessment":"大连餐饮配送招标集中在学校/机关/国企食堂食材配送，需求稳定、合同周期长（通常1-3年），是B端配送的优质切入点。","top_opportunity":"学校/机关食堂食材同城日配招标","action_advice":"关注大连市公共资源交易平台和辽宁政府采购网的食堂食材招标公告，提前准备食品经营许可证和冷链配送资质。"},
        "生鲜冷链": {"assessment":"生鲜冷链是大连同城配送的高价值赛道，樱桃季/海鲜季运力缺口30-60%。官方招标+物流平台双渠道均有大量需求。","top_opportunity":"樱桃季/海鲜季冷链运力招标 + 生鲜电商前置仓配送","action_advice":"5月底前锁定冷藏车运力，与产地合作社签包车协议。关注锦程物流网和物通网的大连冷链货源。"},
        "医药配送": {"assessment":"医药配送门槛最高（GSP认证），但利润空间最大。大连连锁药房+医院配送需求稳定，竞争相对较小。","top_opportunity":"连锁药房冷链药品日配 + 医院间标本/药品急送","action_advice":"优先获取GSP认证和药品经营许可证，关注辽宁政府采购网的医药配送招标。"},
        "家具配送": {"assessment":"家具配送需求集中在搬家/大件入户，周末高峰明显。九州物流网和锦程物流网是主要需求来源。","top_opportunity":"家具城->客户家配送安装 + 老小区无电梯上楼搬运","action_advice":"配备爬楼机+2人搬运组，与宜家/红星美凯龙建立合作。关注九州物流网的搬家配送需求。"},
        "商超补货": {"assessment":"便利店日配是刚需，鲜食保质期仅24小时，对时效要求极高。官方招标+物流平台均有稳定需求。","top_opportunity":"连锁便利店鲜食凌晨日配 + 商超促销期集中补货","action_advice":"建立凌晨配送体系（2:00-6:00），与便利店系统对接。关注大连市公共资源交易平台的商超配送招标。"},
    }
    for ind in ["餐饮配送","生鲜冷链","医药配送","家具配送","商超补货"]:
        count = len(by_industry.get(ind, []))
        a = assessments.get(ind, {})
        analysis["by_industry"][ind] = {"opportunity_count":count,"assessment":a.get("assessment",""),"top_opportunity":a.get("top_opportunity",""),"action_advice":a.get("action_advice","")}
    return analysis
