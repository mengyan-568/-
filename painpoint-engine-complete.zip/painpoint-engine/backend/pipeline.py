
"""
商机挖掘全流程编排器 — 数据源采集 → 分析 → 产物生成

整合路径:
  1. 公开数据源采集（货拉拉/58同城/天眼查/招标/POI）
  2. 半公开数据源采集（招聘/抖音/加油站/违章）
  3. Web搜索采集（DuckDuckGo）
  4. NLP评论分析 + 聚类
  5. 商机洞察报告生成
  6. 四大产物输出（运力地图/需求热力图/竞品对标/商机清单）
"""
import json
import logging
from datetime import datetime
from typing import Optional

from collectors.public_sources import PublicSourceCollector
from collectors.semi_public_sources import SemiPublicSourceCollector
from collectors.products import ProductGenerator
from nlp.analyzer import NLPAnalyzer, PainClusterer
from analyzer.engine import InsightEngine
from knowledge.dalian_delivery import match_scenario, get_scenario_profile

try:
    from collectors.web_search import WebSearchCollector
except ImportError:
    WebSearchCollector = None

logger = logging.getLogger("pipeline")


class OpportunityPipeline:
    """商机挖掘全流程编排器"""

    def __init__(self, city: str = "大连", keyword: str = "同城配送"):
        self.city = city
        self.keyword = keyword
        self.public_collector = PublicSourceCollector(city=city)
        self.semi_public_collector = SemiPublicSourceCollector(city=city)
        self.product_generator = ProductGenerator(city=city)
        self.nlp = NLPAnalyzer()
        self.engine = InsightEngine()

    def run_full_pipeline(self, include_web_search: bool = True,
                          include_demo_reviews: bool = True) -> dict:
        """运行完整的商机挖掘流程"""
        logger.info("=" * 60)
        logger.info("启动商机挖掘全流程: city=%s, keyword=%s", self.city, self.keyword)
        logger.info("=" * 60)

        pipeline_start = datetime.now()
        pipeline_result = {
            "pipeline_metadata": {
                "city": self.city,
                "keyword": self.keyword,
                "started_at": pipeline_start.isoformat(),
                "steps": [],
            },
            "data_sources": {},
            "analysis": {},
            "insight_report": {},
            "products": {},
        }

        # Step 1: 公开数据源采集
        step = "public_sources"
        logger.info("[Step 1/6] 采集公开数据源...")
        try:
            public_data = self.public_collector.collect_all()
            pipeline_result["data_sources"]["public"] = public_data
            pipeline_result["pipeline_metadata"]["steps"].append({
                "step": step, "status": "success",
                "sources": public_data.get("success_count", 0),
            })
        except Exception as e:
            logger.error("  ✗ 公开数据源采集失败: %s", str(e))
            pipeline_result["data_sources"]["public"] = {"error": str(e)}
            pipeline_result["pipeline_metadata"]["steps"].append({
                "step": step, "status": "error", "error": str(e),
            })

        # Step 2: 半公开数据源采集
        step = "semi_public_sources"
        logger.info("[Step 2/6] 采集半公开数据源...")
        try:
            semi_public_data = self.semi_public_collector.collect_all()
            pipeline_result["data_sources"]["semi_public"] = semi_public_data
            pipeline_result["pipeline_metadata"]["steps"].append({
                "step": step, "status": "success",
                "sources": semi_public_data.get("success_count", 0),
            })
        except Exception as e:
            logger.error("  ✗ 半公开数据源采集失败: %s", str(e))
            pipeline_result["data_sources"]["semi_public"] = {"error": str(e)}
            pipeline_result["pipeline_metadata"]["steps"].append({
                "step": step, "status": "error", "error": str(e),
            })

        # Step 3: Web搜索采集
        step = "web_search"
        companies = []
        web_reviews = []
        industry_info = ""

        if include_web_search and WebSearchCollector is not None:
            logger.info("[Step 3/6] Web搜索采集...")
            try:
                web_collector = WebSearchCollector()
                search_results = web_collector.search(
                    f"{self.city} {self.keyword} 同城配送 痛点 评价",
                    max_results=10
                )
                companies = search_results if search_results else []
                try:
                    web_reviews = web_collector.collect_reviews(
                        self.keyword, max_reviews=50
                    )
                except Exception:
                    web_reviews = []
                pipeline_result["data_sources"]["web"] = {
                    "companies_found": len(companies),
                    "companies": companies[:10],
                    "web_reviews_count": len(web_reviews),
                }
                pipeline_result["pipeline_metadata"]["steps"].append({
                    "step": step, "status": "success",
                    "companies": len(companies),
                    "reviews": len(web_reviews),
                })
            except Exception as e:
                logger.warning("  ⚠ Web搜索失败: %s", str(e))
                pipeline_result["pipeline_metadata"]["steps"].append({
                    "step": step, "status": "warning", "error": str(e),
                })
        else:
            logger.info("[Step 3/6] 跳过Web搜索")
            pipeline_result["pipeline_metadata"]["steps"].append({
                "step": step, "status": "skipped",
            })

        # Step 4: 准备评论数据
        step = "review_generation"
        logger.info("[Step 4/6] 准备评论数据...")
        all_reviews = list(web_reviews) if web_reviews else []
        if include_demo_reviews and len(all_reviews) < 30:
            try:
                demo_reviews = self.engine.generate_demo_reviews(
                    self.keyword, companies
                )
                all_reviews.extend(demo_reviews)
            except Exception as e:
                logger.warning("  ⚠ 模拟评论生成失败: %s", str(e))
        pipeline_result["data_sources"]["reviews"] = {
            "total": len(all_reviews),
            "web_count": len(web_reviews),
            "demo_count": len(all_reviews) - len(web_reviews),
        }
        pipeline_result["pipeline_metadata"]["steps"].append({
            "step": step, "status": "success",
            "total_reviews": len(all_reviews),
        })

        # Step 5: NLP分析 + 商机洞察报告
        step = "analysis"
        logger.info("[Step 5/6] NLP分析 + 商机洞察报告生成...")
        try:
            analyzed_reviews = self.nlp.analyze_reviews(all_reviews, self.keyword)
            report = self.engine.generate_report(
                keyword=self.keyword,
                analyzed_reviews=analyzed_reviews,
                companies=companies,
                industry_info=industry_info,
            )
            pipeline_result["insight_report"] = report
            pipeline_result["analysis"] = {
                "total_reviews": len(analyzed_reviews),
                "negative_count": sum(1 for r in analyzed_reviews if r.get("is_negative")),
                "scenario": report.get("scenario", "通用"),
                "top_opportunities": report.get("opportunities", [])[:3],
            }
            pipeline_result["pipeline_metadata"]["steps"].append({
                "step": step, "status": "success",
            })
        except Exception as e:
            logger.error("  ✗ 分析失败: %s", str(e))
            pipeline_result["pipeline_metadata"]["steps"].append({
                "step": step, "status": "error", "error": str(e),
            })

        # Step 6: 四大产物生成
        step = "products"
        logger.info("[Step 6/6] 生成商机挖掘产物...")
        try:
            products = self.product_generator.generate_all(
                public_data=pipeline_result["data_sources"].get("public"),
                semi_public_data=pipeline_result["data_sources"].get("semi_public"),
                keyword=self.keyword,
            )
            pipeline_result["products"] = products
            pipeline_result["pipeline_metadata"]["steps"].append({
                "step": step, "status": "success",
                "products": products.get("success_count", 0),
            })
        except Exception as e:
            logger.error("  ✗ 产物生成失败: %s", str(e))
            pipeline_result["pipeline_metadata"]["steps"].append({
                "step": step, "status": "error", "error": str(e),
            })

        # 汇总
        pipeline_end = datetime.now()
        duration = (pipeline_end - pipeline_start).total_seconds()
        pipeline_result["pipeline_metadata"]["completed_at"] = pipeline_end.isoformat()
        pipeline_result["pipeline_metadata"]["duration_seconds"] = round(duration, 1)
        pipeline_result["pipeline_metadata"]["status"] = "completed"

        logger.info("=" * 60)
        logger.info("商机挖掘全流程完成! 耗时 %.1f 秒", duration)
        logger.info("=" * 60)
        return pipeline_result

    def run_quick_products_only(self) -> dict:
        """快速模式：跳过Web搜索和NLP分析，直接生成四大产物"""
        logger.info("快速模式: 仅生成产物")
        public_data = self.public_collector.collect_all()
        semi_public_data = self.semi_public_collector.collect_all()
        products = self.product_generator.generate_all(
            public_data=public_data,
            semi_public_data=semi_public_data,
            keyword=self.keyword,
        )
        return {
            "mode": "quick_products_only",
            "city": self.city,
            "keyword": self.keyword,
            "generated_at": datetime.now().isoformat(),
            "data_sources": {
                "public_success": public_data.get("success_count", 0),
                "semi_public_success": semi_public_data.get("success_count", 0),
            },
            "products": products,
        }

    def export_to_json(self, result: dict, filepath: str = None) -> str:
        """将流水线结果导出为JSON文件"""
        if filepath is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filepath = f"opportunity_pipeline_{self.city}_{self.keyword}_{timestamp}.json"
        def clean_for_json(obj):
            if isinstance(obj, dict):
                return {k: clean_for_json(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [clean_for_json(item) for item in obj]
            elif isinstance(obj, datetime):
                return obj.isoformat()
            return obj
        cleaned = clean_for_json(result)
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(cleaned, f, ensure_ascii=False, indent=2)
        logger.info("结果已导出到: %s", filepath)
        return filepath


def run_pipeline(city: str = "大连", keyword: str = "同城配送",
                 include_web_search: bool = True,
                 include_demo_reviews: bool = True,
                 quick_mode: bool = False) -> dict:
    """便捷函数：一键运行商机挖掘全流程"""
    pipeline = OpportunityPipeline(city=city, keyword=keyword)
    if quick_mode:
        return pipeline.run_quick_products_only()
    else:
        return pipeline.run_full_pipeline(
            include_web_search=include_web_search,
            include_demo_reviews=include_demo_reviews,
        )
