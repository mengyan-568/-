"""
数据库 Schema 定义 — PostgreSQL/TimescaleDB 兼容

核心表:
  - vehicles: 车辆信息（车型、载重、温区等）
  - drivers: 司机信息
  - gps_pings: GPS 轨迹点（TimescaleDB hypertable）
  - orders: 配送订单
  - order_stops: 订单经停点
  - routes: 规划路线
  - customers: 客户信息
  - pain_analyses: 痛点分析历史（原 reports 表升级）

辅助表:
  - geofences: 电子围栏
  - route_waypoints: 路线途经点

所有表使用 UUID 主键，PostgreSQL 下自动启用 TimescaleDB + PostGIS 扩展。
"""

SCHEMA_VERSION = 2

# ============================================================
# DDL — PostgreSQL 版本（含 TimescaleDB + PostGIS）
# ============================================================

PG_DDL = """
-- 扩展
CREATE EXTENSION IF NOT EXISTS timescaledb;
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ===== 车辆 =====
CREATE TABLE IF NOT EXISTS vehicles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    plate_number VARCHAR(16) NOT NULL UNIQUE,
    vehicle_type VARCHAR(32) NOT NULL,           -- 面包车/4.2m厢货/冷藏车/平板车
    brand_model VARCHAR(64),
    max_load_kg NUMERIC(8,1) DEFAULT 0,
    max_volume_m3 NUMERIC(6,2) DEFAULT 0,
    temp_zone_count INT DEFAULT 1,               -- 温区数量（冷藏车可能多温区）
    has_lift_gate BOOLEAN DEFAULT FALSE,          -- 是否有升降尾板
    fuel_type VARCHAR(16) DEFAULT '柴油',
    status VARCHAR(16) DEFAULT 'idle',           -- idle/dispatched/maintenance/offline
    device_id VARCHAR(64),                        -- GPS 设备 IMEI（关联 Traccar）
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ===== 司机 =====
CREATE TABLE IF NOT EXISTS drivers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(64) NOT NULL,
    phone VARCHAR(20) NOT NULL UNIQUE,
    license_type VARCHAR(8) DEFAULT 'C1',
    health_cert_expiry DATE,                     -- 健康证有效期（餐饮/医药配送需要）
    status VARCHAR(16) DEFAULT 'offline',        -- online/offline/dispatched/leave
    current_vehicle_id UUID REFERENCES vehicles(id),
    rating NUMERIC(3,2) DEFAULT 5.0,             -- 客户评分
    completed_orders INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ===== GPS 轨迹点 (TimescaleDB hypertable) =====
CREATE TABLE IF NOT EXISTS gps_pings (
    time TIMESTAMPTZ NOT NULL,
    vehicle_id UUID NOT NULL,
    driver_id UUID,
    latitude NUMERIC(10,7) NOT NULL,
    longitude NUMERIC(10,7) NOT NULL,
    speed_kmh NUMERIC(5,1),
    heading SMALLINT,                            -- 方向角 0-360
    accuracy_m NUMERIC(5,1),                     -- GPS 精度
    ignition BOOLEAN,                            -- 点火状态
    order_id UUID,                               -- 当前配送订单
    extra JSONB DEFAULT '{}',                    -- 扩展字段（温度、油耗等）
    -- PostGIS geometry（自动从 lat/lon 生成）
    geom GEOMETRY(Point, 4326) GENERATED ALWAYS AS (
        ST_SetSRID(ST_MakePoint(longitude, latitude), 4326)
    ) STORED
);

-- 转为 TimescaleDB hypertable
SELECT create_hypertable('gps_pings', 'time', if_not_exists => TRUE);

-- GPS 压缩策略（7天后自动压缩，节省 90% 存储）
SELECT add_compression_policy('gps_pings', INTERVAL '7 days', if_not_exists => TRUE);

-- 索引
CREATE INDEX IF NOT EXISTS idx_gps_vehicle_time ON gps_pings (vehicle_id, time DESC);
CREATE INDEX IF NOT EXISTS idx_gps_geom ON gps_pings USING GIST (geom);
CREATE INDEX IF NOT EXISTS idx_gps_order ON gps_pings (order_id) WHERE order_id IS NOT NULL;

-- ===== 客户 =====
CREATE TABLE IF NOT EXISTS customers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(128) NOT NULL,
    short_name VARCHAR(64),
    industry VARCHAR(32),                        -- 餐饮/生鲜/医药/家具/商超
    contact_person VARCHAR(64),
    contact_phone VARCHAR(20),
    address TEXT,
    location GEOMETRY(Point, 4326),              -- 主要地址坐标
    service_area GEOMETRY(Polygon, 4326),        -- 服务区域
    delivery_window_start TIME,                  -- 期望配送开始时间
    delivery_window_end TIME,                    -- 期望配送结束时间
    requires_cold_chain BOOLEAN DEFAULT FALSE,
    requires_upstairs BOOLEAN DEFAULT FALSE,      -- 需要上楼搬运
    contract_status VARCHAR(16) DEFAULT 'prospect', -- prospect/active/suspended/churned
    monthly_order_estimate INT DEFAULT 0,
    pain_profile JSONB DEFAULT '{}',             -- 痛点画像（来自 NLP 分析）
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_customers_industry ON customers (industry);
CREATE INDEX IF NOT EXISTS idx_customers_location ON customers USING GIST (location);
CREATE INDEX IF NOT EXISTS idx_customers_contract ON customers (contract_status);

-- ===== 配送订单 =====
CREATE TABLE IF NOT EXISTS orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_number VARCHAR(32) UNIQUE,
    customer_id UUID NOT NULL REFERENCES customers(id),
    status VARCHAR(16) DEFAULT 'pending',        -- pending/assigned/pickup/in_transit/delivered/cancelled
    priority SMALLINT DEFAULT 3,                 -- 1=紧急 2=高 3=普通
    cargo_type VARCHAR(32),
    cargo_weight_kg NUMERIC(8,1),
    cargo_volume_m3 NUMERIC(6,2),
    requires_cold_chain BOOLEAN DEFAULT FALSE,
    temp_min_c NUMERIC(4,1),
    temp_max_c NUMERIC(4,1),
    requires_upstairs BOOLEAN DEFAULT FALSE,
    upstairs_floors INT DEFAULT 0,
    pickup_address TEXT,
    pickup_location GEOMETRY(Point, 4326),
    pickup_time_window_start TIMESTAMPTZ,
    pickup_time_window_end TIMESTAMPTZ,
    delivery_address TEXT,
    delivery_location GEOMETRY(Point, 4326),
    delivery_time_window_start TIMESTAMPTZ,
    delivery_time_window_end TIMESTAMPTZ,
    assigned_vehicle_id UUID REFERENCES vehicles(id),
    assigned_driver_id UUID REFERENCES drivers(id),
    route_id UUID,
    estimated_distance_km NUMERIC(8,2),
    estimated_duration_min INT,
    actual_distance_km NUMERIC(8,2),
    actual_duration_min INT,
    signed_by VARCHAR(64),                       -- 签收人
    signed_photo_url TEXT,                       -- 签收照片
    delivery_notes TEXT,
    price_quoted NUMERIC(10,2),
    price_actual NUMERIC(10,2),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    delivered_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders (customer_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders (status);
CREATE INDEX IF NOT EXISTS idx_orders_vehicle ON orders (assigned_vehicle_id);
CREATE INDEX IF NOT EXISTS idx_orders_created ON orders (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_pickup_loc ON orders USING GIST (pickup_location);
CREATE INDEX IF NOT EXISTS idx_orders_delivery_loc ON orders USING GIST (delivery_location);

-- ===== 订单经停点 =====
CREATE TABLE IF NOT EXISTS order_stops (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    stop_type VARCHAR(16) NOT NULL,              -- pickup/delivery
    sequence_num INT NOT NULL,
    address TEXT,
    location GEOMETRY(Point, 4326),
    planned_arrival TIMESTAMPTZ,
    actual_arrival TIMESTAMPTZ,
    status VARCHAR(16) DEFAULT 'pending',
    notes TEXT
);

-- ===== 规划路线 =====
CREATE TABLE IF NOT EXISTS routes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    vehicle_id UUID NOT NULL REFERENCES vehicles(id),
    driver_id UUID REFERENCES drivers(id),
    date DATE NOT NULL,
    status VARCHAR(16) DEFAULT 'planned',        -- planned/in_progress/completed/cancelled
    total_distance_km NUMERIC(8,2),
    total_duration_min INT,
    total_stops INT,
    optimization_score NUMERIC(5,1),             -- VRP 求解器评分
    route_geojson JSONB,                         -- 完整路线 GeoJSON
    created_at TIMESTAMPTZ DEFAULT NOW(),
    started_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_routes_vehicle_date ON routes (vehicle_id, date);
CREATE INDEX IF NOT EXISTS idx_routes_status ON routes (status);

-- ===== 路线途经点 =====
CREATE TABLE IF NOT EXISTS route_waypoints (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    route_id UUID NOT NULL REFERENCES routes(id) ON DELETE CASCADE,
    order_id UUID REFERENCES orders(id),
    sequence_num INT NOT NULL,
    location GEOMETRY(Point, 4326),
    planned_arrival TIMESTAMPTZ,
    planned_departure TIMESTAMPTZ,
    actual_arrival TIMESTAMPTZ,
    actual_departure TIMESTAMPTZ,
    stop_type VARCHAR(16),                       -- pickup/delivery/depot/rest
    notes TEXT
);

-- ===== 电子围栏 =====
CREATE TABLE IF NOT EXISTS geofences (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(64) NOT NULL,
    type VARCHAR(16) DEFAULT 'circle',           -- circle/polygon
    geometry GEOMETRY NOT NULL,
    rule VARCHAR(16) DEFAULT 'alert',            -- alert/restrict/track
    vehicle_id UUID REFERENCES vehicles(id),     -- NULL = 全局围栏
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_geofences_geom ON geofences USING GIST (geometry);

-- ===== 痛点分析历史（原 reports 表升级） =====
CREATE TABLE IF NOT EXISTS pain_analyses (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    keyword VARCHAR(128) NOT NULL,
    scenario VARCHAR(32),
    report_data JSONB NOT NULL,
    negative_review_count INT DEFAULT 0,
    top_opportunity_score NUMERIC(6,1),
    top_opportunity_category VARCHAR(64),
    target_merchant_count INT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_pain_keyword ON pain_analyses (keyword);
CREATE INDEX IF NOT EXISTS idx_pain_created ON pain_analyses (created_at DESC);

-- ===== 商机跟踪（原 tracked_opportunities 升级） =====
CREATE TABLE IF NOT EXISTS tracked_opportunities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    analysis_id UUID REFERENCES pain_analyses(id),
    customer_id UUID REFERENCES customers(id),
    merchant_name VARCHAR(128) NOT NULL,
    contact_person VARCHAR(64) DEFAULT '',
    contact_phone VARCHAR(32) DEFAULT '',
    status VARCHAR(16) DEFAULT '新线索',
    notes TEXT DEFAULT '',
    deal_amount NUMERIC(12,2) DEFAULT 0,
    close_reason TEXT DEFAULT '',
    match_score INT DEFAULT 0,
    match_level VARCHAR(8) DEFAULT '中',
    archived_at TIMESTAMPTZ,
    deleted_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_opp_status ON tracked_opportunities (status);
CREATE INDEX IF NOT EXISTS idx_opp_customer ON tracked_opportunities (customer_id);

-- ===== 跟进记录 =====
CREATE TABLE IF NOT EXISTS follow_up_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    opportunity_id UUID NOT NULL REFERENCES tracked_opportunities(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    next_follow_date DATE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ===== 状态变更历史 =====
CREATE TABLE IF NOT EXISTS status_history (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    opportunity_id UUID NOT NULL REFERENCES tracked_opportunities(id) ON DELETE CASCADE,
    from_status VARCHAR(16),
    to_status VARCHAR(16) NOT NULL,
    note TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ===== 用户反馈/评论（原始数据，用于 NLP 分析） =====
CREATE TABLE IF NOT EXISTS reviews (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    analysis_id UUID REFERENCES pain_analyses(id),
    source VARCHAR(32),
    content TEXT NOT NULL,
    rating NUMERIC(3,1),
    sentiment NUMERIC(5,3),
    pain_score NUMERIC(5,3),
    is_negative BOOLEAN DEFAULT FALSE,
    keywords JSONB DEFAULT '[]',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_reviews_analysis ON reviews (analysis_id);
CREATE INDEX IF NOT EXISTS idx_reviews_negative ON reviews (is_negative) WHERE is_negative = TRUE;

-- ===== 持续聚合（TimescaleDB continuous aggregates） =====

-- 每5分钟聚合：车辆轨迹统计
CREATE MATERIALIZED VIEW IF NOT EXISTS vehicle_5min_stats
WITH (timescaledb.continuous) AS
SELECT
    time_bucket('5 minutes', time) AS bucket,
    vehicle_id,
    COUNT(*) AS ping_count,
    AVG(speed_kmh) AS avg_speed,
    MAX(speed_kmh) AS max_speed,
    ST_Centroid(ST_Collect(geom)) AS centroid_geom
FROM gps_pings
GROUP BY bucket, vehicle_id;

-- 每日聚合：配送统计
CREATE MATERIALIZED VIEW IF NOT EXISTS daily_delivery_stats
WITH (timescaledb.continuous) AS
SELECT
    time_bucket('1 day', time) AS day,
    COUNT(DISTINCT order_id) AS orders_completed,
    COUNT(DISTINCT vehicle_id) AS vehicles_active,
    AVG(speed_kmh) AS avg_speed
FROM gps_pings
WHERE order_id IS NOT NULL
GROUP BY day;
"""

# ============================================================
# DDL — DuckDB 版本（本地开发，功能子集）
# ============================================================

DUCKDB_DDL = """
-- 扩展
INSTALL spatial; LOAD spatial;

-- ===== 车辆 =====
CREATE TABLE IF NOT EXISTS vehicles (
    id UUID PRIMARY KEY,
    plate_number VARCHAR(16) NOT NULL UNIQUE,
    vehicle_type VARCHAR(32) NOT NULL,
    brand_model VARCHAR(64),
    max_load_kg DOUBLE DEFAULT 0,
    max_volume_m3 DOUBLE DEFAULT 0,
    temp_zone_count INTEGER DEFAULT 1,
    has_lift_gate BOOLEAN DEFAULT FALSE,
    fuel_type VARCHAR(16) DEFAULT '柴油',
    status VARCHAR(16) DEFAULT 'idle',
    device_id VARCHAR(64),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ===== 司机 =====
CREATE TABLE IF NOT EXISTS drivers (
    id UUID PRIMARY KEY,
    name VARCHAR(64) NOT NULL,
    phone VARCHAR(20) NOT NULL UNIQUE,
    license_type VARCHAR(8) DEFAULT 'C1',
    health_cert_expiry DATE,
    status VARCHAR(16) DEFAULT 'offline',
    current_vehicle_id UUID REFERENCES vehicles(id),
    rating DOUBLE DEFAULT 5.0,
    completed_orders INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ===== GPS 轨迹点 =====
CREATE TABLE IF NOT EXISTS gps_pings (
    time TIMESTAMP NOT NULL,
    vehicle_id UUID NOT NULL,
    driver_id UUID,
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    speed_kmh DOUBLE,
    heading SMALLINT,
    accuracy_m DOUBLE,
    ignition BOOLEAN,
    order_id UUID,
    extra JSON
);

CREATE INDEX IF NOT EXISTS idx_duck_gps_vehicle_time ON gps_pings (vehicle_id, time);
CREATE INDEX IF NOT EXISTS idx_duck_gps_order ON gps_pings (order_id);

-- ===== 客户 =====
CREATE TABLE IF NOT EXISTS customers (
    id UUID PRIMARY KEY,
    name VARCHAR(128) NOT NULL,
    short_name VARCHAR(64),
    industry VARCHAR(32),
    contact_person VARCHAR(64),
    contact_phone VARCHAR(20),
    address TEXT,
    lat DOUBLE,
    lon DOUBLE,
    delivery_window_start TIME,
    delivery_window_end TIME,
    requires_cold_chain BOOLEAN DEFAULT FALSE,
    requires_upstairs BOOLEAN DEFAULT FALSE,
    contract_status VARCHAR(16) DEFAULT 'prospect',
    monthly_order_estimate INTEGER DEFAULT 0,
    pain_profile JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_duck_customers_industry ON customers (industry);
CREATE INDEX IF NOT EXISTS idx_duck_customers_contract ON customers (contract_status);

-- ===== 配送订单 =====
CREATE TABLE IF NOT EXISTS orders (
    id UUID PRIMARY KEY,
    order_number VARCHAR(32) UNIQUE,
    customer_id UUID NOT NULL REFERENCES customers(id),
    status VARCHAR(16) DEFAULT 'pending',
    priority SMALLINT DEFAULT 3,
    cargo_type VARCHAR(32),
    cargo_weight_kg DOUBLE,
    cargo_volume_m3 DOUBLE,
    requires_cold_chain BOOLEAN DEFAULT FALSE,
    temp_min_c DOUBLE,
    temp_max_c DOUBLE,
    requires_upstairs BOOLEAN DEFAULT FALSE,
    upstairs_floors INTEGER DEFAULT 0,
    pickup_address TEXT,
    pickup_lat DOUBLE,
    pickup_lon DOUBLE,
    pickup_time_window_start TIMESTAMP,
    pickup_time_window_end TIMESTAMP,
    delivery_address TEXT,
    delivery_lat DOUBLE,
    delivery_lon DOUBLE,
    delivery_time_window_start TIMESTAMP,
    delivery_time_window_end TIMESTAMP,
    assigned_vehicle_id UUID REFERENCES vehicles(id),
    assigned_driver_id UUID REFERENCES drivers(id),
    route_id UUID,
    estimated_distance_km DOUBLE,
    estimated_duration_min INTEGER,
    actual_distance_km DOUBLE,
    actual_duration_min INTEGER,
    signed_by VARCHAR(64),
    signed_photo_url TEXT,
    delivery_notes TEXT,
    price_quoted DOUBLE,
    price_actual DOUBLE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    delivered_at TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_duck_orders_customer ON orders (customer_id);
CREATE INDEX IF NOT EXISTS idx_duck_orders_status ON orders (status);
CREATE INDEX IF NOT EXISTS idx_duck_orders_vehicle ON orders (assigned_vehicle_id);
CREATE INDEX IF NOT EXISTS idx_duck_orders_created ON orders (created_at);

-- ===== 规划路线 =====
CREATE TABLE IF NOT EXISTS routes (
    id UUID PRIMARY KEY,
    vehicle_id UUID NOT NULL REFERENCES vehicles(id),
    driver_id UUID REFERENCES drivers(id),
    date DATE NOT NULL,
    status VARCHAR(16) DEFAULT 'planned',
    total_distance_km DOUBLE,
    total_duration_min INTEGER,
    total_stops INTEGER,
    optimization_score DOUBLE,
    route_geojson JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    started_at TIMESTAMP,
    completed_at TIMESTAMP
);

-- ===== 电子围栏 =====
CREATE TABLE IF NOT EXISTS geofences (
    id UUID PRIMARY KEY,
    name VARCHAR(64) NOT NULL,
    type VARCHAR(16) DEFAULT 'circle',
    center_lat DOUBLE,
    center_lon DOUBLE,
    radius_m DOUBLE,
    wkt TEXT,                                    -- 多边形用 WKT
    rule VARCHAR(16) DEFAULT 'alert',
    vehicle_id UUID REFERENCES vehicles(id),
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ===== 痛点分析历史 =====
CREATE TABLE IF NOT EXISTS pain_analyses (
    id UUID PRIMARY KEY,
    keyword VARCHAR(128) NOT NULL,
    scenario VARCHAR(32),
    report_data JSON NOT NULL,
    negative_review_count INTEGER DEFAULT 0,
    top_opportunity_score DOUBLE,
    top_opportunity_category VARCHAR(64),
    target_merchant_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ===== 商机跟踪 =====
CREATE TABLE IF NOT EXISTS tracked_opportunities (
    id UUID PRIMARY KEY,
    analysis_id UUID REFERENCES pain_analyses(id),
    customer_id UUID REFERENCES customers(id),
    merchant_name VARCHAR(128) NOT NULL,
    contact_person VARCHAR(64) DEFAULT '',
    contact_phone VARCHAR(32) DEFAULT '',
    status VARCHAR(16) DEFAULT '新线索',
    notes TEXT DEFAULT '',
    deal_amount DOUBLE DEFAULT 0,
    close_reason TEXT DEFAULT '',
    match_score INTEGER DEFAULT 0,
    match_level VARCHAR(8) DEFAULT '中',
    archived_at TIMESTAMP,
    deleted_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_duck_opp_status ON tracked_opportunities (status);

-- ===== 跟进记录 =====
CREATE TABLE IF NOT EXISTS follow_up_logs (
    id UUID PRIMARY KEY,
    opportunity_id UUID NOT NULL REFERENCES tracked_opportunities(id),
    content TEXT NOT NULL,
    next_follow_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ===== 状态变更历史 =====
CREATE TABLE IF NOT EXISTS status_history (
    id UUID PRIMARY KEY,
    opportunity_id UUID NOT NULL REFERENCES tracked_opportunities(id),
    from_status VARCHAR(16),
    to_status VARCHAR(16) NOT NULL,
    note TEXT DEFAULT '',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ===== 原始评论数据 =====
CREATE TABLE IF NOT EXISTS reviews (
    id UUID PRIMARY KEY,
    analysis_id UUID REFERENCES pain_analyses(id),
    source VARCHAR(32),
    content TEXT NOT NULL,
    rating DOUBLE,
    sentiment DOUBLE,
    pain_score DOUBLE,
    is_negative BOOLEAN DEFAULT FALSE,
    keywords JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_duck_reviews_analysis ON reviews (analysis_id);
CREATE INDEX IF NOT EXISTS idx_duck_reviews_negative ON reviews (is_negative);
"""
