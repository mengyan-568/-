"""
数据库迁移管理 — 支持 PostgreSQL 和 DuckDB

用法:
    from database.migrations import run_migrations
    run_migrations()
"""

import os
import uuid
from datetime import datetime

from .connection import is_postgres, is_duckdb, execute, execute_write, get_connection, return_connection


def run_migrations():
    """自动运行所有迁移。幂等 — 已执行的迁移不会重复运行。"""
    if is_postgres():
        _run_pg_migrations()
    else:
        _run_duckdb_migrations()


def _run_pg_migrations():
    """PostgreSQL 迁移"""
    from .schema import PG_DDL

    conn = get_connection()
    try:
        cur = conn.cursor()

        # 确保迁移追踪表存在
        cur.execute("""
            CREATE TABLE IF NOT EXISTS schema_migrations (
                version INTEGER PRIMARY KEY,
                applied_at TIMESTAMPTZ DEFAULT NOW(),
                description TEXT
            )
        """)

        # 检查当前版本
        cur.execute("SELECT MAX(version) FROM schema_migrations")
        current = cur.fetchone()[0] or 0

        from .schema import SCHEMA_VERSION

        if current < SCHEMA_VERSION:
            # 逐条执行 DDL（跳过空行和注释）
            statements = _split_sql(PG_DDL)
            for stmt in statements:
                try:
                    cur.execute(stmt)
                except Exception as e:
                    # 如果是"已存在"类错误，跳过
                    if "already exists" in str(e) or "duplicate" in str(e).lower():
                        pass
                    else:
                        print(f"[Migration] Warning: {e}")

            cur.execute(
                "INSERT INTO schema_migrations (version, description) VALUES (%s, %s)",
                (SCHEMA_VERSION, f"v{SCHEMA_VERSION}: Full TMS schema with TimescaleDB + PostGIS")
            )
            conn.commit()
            print(f"[Migration] PostgreSQL schema migrated to v{SCHEMA_VERSION}")
        else:
            print(f"[Migration] PostgreSQL schema already at v{current}")
    finally:
        return_connection(conn)


def _run_duckdb_migrations():
    """DuckDB 迁移"""
    from .schema import DUCKDB_DDL

    conn = get_connection()
    try:
        cur = conn.cursor()

        # 确保迁移追踪表存在
        cur.execute("""
            CREATE TABLE IF NOT EXISTS schema_migrations (
                version INTEGER PRIMARY KEY,
                applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                description TEXT
            )
        """)

        # 检查当前版本
        cur.execute("SELECT MAX(version) FROM schema_migrations")
        row = cur.fetchone()
        current = row[0] if row and row[0] is not None else 0

        from .schema import SCHEMA_VERSION

        if current < SCHEMA_VERSION:
            statements = _split_sql(DUCKDB_DDL)
            for stmt in statements:
                try:
                    cur.execute(stmt)
                except Exception as e:
                    err_msg = str(e).lower()
                    if "already exists" in err_msg or "duplicate" in err_msg:
                        pass
                    elif "cannot" in err_msg and "index" in err_msg:
                        pass
                    else:
                        print(f"[Migration] Warning: {e}")

            cur.execute(
                "INSERT INTO schema_migrations (version, description) VALUES (?, ?)",
                (SCHEMA_VERSION, f"v{SCHEMA_VERSION}: Full TMS schema")
            )
            conn.commit()
            print(f"[Migration] DuckDB schema migrated to v{SCHEMA_VERSION}")
        else:
            print(f"[Migration] DuckDB schema already at v{current}")
    finally:
        return_connection(conn)


def _split_sql(ddl: str) -> list[str]:
    """将 DDL 文本按分号拆分为独立语句，跳过注释和空行"""
    statements = []
    current = []
    for line in ddl.split("\n"):
        stripped = line.strip()
        # 跳过注释和空行
        if not stripped or stripped.startswith("--"):
            continue
        # 跳过 SELECT create_hypertable 类只适用于 TimescaleDB 的函数调用
        if "create_hypertable" in stripped.lower() or "add_compression_policy" in stripped.lower():
            continue
        current.append(line)
        if stripped.endswith(";"):
            stmt = "\n".join(current).strip()
            if stmt and not stmt.startswith("--"):
                statements.append(stmt)
            current = []
    # 处理最后一条没有分号的语句
    if current:
        stmt = "\n".join(current).strip()
        if stmt and not stmt.startswith("--"):
            statements.append(stmt)
    return statements


def seed_demo_data():
    """插入演示数据 — 大连地区的虚拟车队和客户"""
    if is_postgres():
        _seed_pg_demo()
    else:
        _seed_duckdb_demo()


def _seed_pg_demo():
    """PostgreSQL 演示数据"""
    # 车辆
    vehicles = [
        ("辽B·12345", "面包车", "五菱荣光", 800, 2.5, False, "柴油", "imei_001"),
        ("辽B·23456", "4.2m厢货", "福田奥铃", 2500, 16.0, True, "柴油", "imei_002"),
        ("辽B·34567", "冷藏车", "解放J6F", 1800, 12.0, False, "柴油", "imei_003"),
        ("辽B·45678", "平板车", "东风天锦", 4000, 20.0, False, "柴油", "imei_004"),
        ("辽B·56789", "面包车", "长安之星", 700, 2.3, False, "汽油", "imei_005"),
    ]
    for v in vehicles:
        execute_write(
            "INSERT INTO vehicles (plate_number, vehicle_type, brand_model, max_load_kg, max_volume_m3, has_lift_gate, fuel_type, device_id) "
            "VALUES (%s,%s,%s,%s,%s,%s,%s,%s) ON CONFLICT (plate_number) DO NOTHING",
            v
        )

    # 司机
    drivers = [
        ("王德发", "13804110001", "C1"),
        ("李国强", "13804110002", "C1"),
        ("张大军", "13804110003", "B2"),
        ("赵永强", "13804110004", "B2"),
        ("刘明辉", "13804110005", "C1"),
    ]
    for d in drivers:
        execute_write(
            "INSERT INTO drivers (name, phone, license_type) VALUES (%s,%s,%s) ON CONFLICT (phone) DO NOTHING",
            d
        )

    # 客户（大连真实企业）
    customers = [
        ("喜家德水饺（大连总部）", "喜家德", "餐饮配送", "张经理", "0411-82820001", "大连市中山区青泥洼桥", True, "prospect", 300),
        ("罗森便利店（大连）", "罗森", "商超补货", "李经理", "0411-82820002", "大连市中山区人民路", False, "prospect", 600),
        ("大连辽渔国际水产品市场", "辽渔", "生鲜冷链", "王经理", "0411-82820003", "大连市甘井子区大连湾", True, "prospect", 200),
        ("海王星辰大药房（大连）", "海王星辰", "医药配送", "赵经理", "0411-82820004", "大连市沙河口区西安路", True, "prospect", 150),
        ("宜家家居大连商场", "宜家", "家具配送", "刘经理", "0411-82820005", "大连市西岗区香炉礁", False, "prospect", 80),
    ]
    for c in customers:
        execute_write(
            "INSERT INTO customers (name, short_name, industry, contact_person, contact_phone, address, requires_cold_chain, contract_status, monthly_order_estimate) "
            "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING",
            c
        )

    print("[Seed] PostgreSQL demo data inserted")


def _seed_duckdb_demo():
    """DuckDB 演示数据"""
    import uuid as _uuid

    vehicles = [
        (str(_uuid.uuid4()), "辽B·12345", "面包车", "五菱荣光", 800, 2.5, False),
        (str(_uuid.uuid4()), "辽B·23456", "4.2m厢货", "福田奥铃", 2500, 16.0, True),
        (str(_uuid.uuid4()), "辽B·34567", "冷藏车", "解放J6F", 1800, 12.0, False),
        (str(_uuid.uuid4()), "辽B·45678", "平板车", "东风天锦", 4000, 20.0, False),
        (str(_uuid.uuid4()), "辽B·56789", "面包车", "长安之星", 700, 2.3, False),
    ]
    for v in vehicles:
        try:
            execute_write(
                "INSERT INTO vehicles (id, plate_number, vehicle_type, brand_model, max_load_kg, max_volume_m3, has_lift_gate) "
                "VALUES (?,?,?,?,?,?,?)", v
            )
        except Exception:
            pass

    drivers = [
        (str(_uuid.uuid4()), "王德发", "13804110001", "C1"),
        (str(_uuid.uuid4()), "李国强", "13804110002", "C1"),
        (str(_uuid.uuid4()), "张大军", "13804110003", "B2"),
    ]
    for d in drivers:
        try:
            execute_write(
                "INSERT INTO drivers (id, name, phone, license_type) VALUES (?,?,?,?)", d
            )
        except Exception:
            pass

    customers = [
        (str(_uuid.uuid4()), "喜家德水饺（大连总部）", "喜家德", "餐饮配送", "张经理", "0411-82820001", "大连市中山区青泥洼桥", True),
        (str(_uuid.uuid4()), "罗森便利店（大连）", "罗森", "商超补货", "李经理", "0411-82820002", "大连市中山区人民路", False),
        (str(_uuid.uuid4()), "大连辽渔国际水产品市场", "辽渔", "生鲜冷链", "王经理", "0411-82820003", "大连市甘井子区大连湾", True),
    ]
    for c in customers:
        try:
            execute_write(
                "INSERT INTO customers (id, name, short_name, industry, contact_person, contact_phone, address, requires_cold_chain) "
                "VALUES (?,?,?,?,?,?,?,?)", c
            )
        except Exception:
            pass

    print("[Seed] DuckDB demo data inserted")
