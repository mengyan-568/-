"""
数据库抽象层 — PostgreSQL (生产) + DuckDB (本地开发)

用法:
    from database import get_db, DATABASE_URL

    db = get_db()  # 自动选择 PostgreSQL 或 DuckDB

环境变量:
    DATABASE_URL=postgresql://user:pass@host:5432/painpoint  → PostgreSQL
    不设置 → DuckDB (painpoint.duckdb)
"""

import os
import sys

DATABASE_URL = os.environ.get(
    "DATABASE_URL",
    f"duckdb:///{os.path.join(os.path.dirname(__file__), '..', 'data', 'painpoint.duckdb')}"
)


def get_db_url() -> str:
    """返回当前数据库连接 URL"""
    return DATABASE_URL


def is_postgres() -> bool:
    """是否使用 PostgreSQL（生产模式）"""
    return DATABASE_URL.startswith("postgresql") or DATABASE_URL.startswith("postgres")


def is_duckdb() -> bool:
    """是否使用 DuckDB（本地开发模式）"""
    return not is_postgres()


def get_connection():
    """
    返回数据库连接。
    PostgreSQL: psycopg2 connection (带连接池)
    DuckDB: duckdb connection (单连接)
    """
    if is_postgres():
        import psycopg2
        import psycopg2.pool

        # 使用模块级别的连接池（线程安全）
        pool = _get_pg_pool()
        return pool.getconn()
    else:
        import duckdb
        return duckdb.connect(DATABASE_URL.replace("duckdb:///", ""))


def return_connection(conn):
    """归还连接到池（仅 PostgreSQL）"""
    if is_postgres():
        _get_pg_pool().putconn(conn)
    else:
        conn.close()


# PostgreSQL 连接池（懒加载）
_pg_pool = None


def _get_pg_pool():
    global _pg_pool
    if _pg_pool is None:
        import psycopg2
        import psycopg2.pool
        from urllib.parse import urlparse

        url = urlparse(DATABASE_URL)
        _pg_pool = psycopg2.pool.ThreadedConnectionPool(
            minconn=2,
            maxconn=10,
            host=url.hostname,
            port=url.port or 5432,
            dbname=url.path.lstrip("/"),
            user=url.username,
            password=url.password,
        )
    return _pg_pool


def execute(sql: str, params: tuple = None) -> list[dict]:
    """执行查询并返回字典列表"""
    conn = get_connection()
    try:
        if is_postgres():
            import psycopg2.extras
            cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
        else:
            cur = conn.cursor()

        cur.execute(sql, params or ())
        try:
            rows = cur.fetchall()
            if is_postgres():
                return [dict(r) for r in rows]
            else:
                # DuckDB returns tuples; convert to dict manually
                cols = [d[0] for d in cur.description]
                return [dict(zip(cols, r)) for r in rows]
        except Exception:
            return []
    finally:
        return_connection(conn)


def execute_write(sql: str, params: tuple = None) -> int:
    """执行写入并返回 lastrowid"""
    conn = get_connection()
    try:
        cur = conn.cursor()
        cur.execute(sql, params or ())
        conn.commit()
        try:
            return cur.lastrowid
        except Exception:
            return 0
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        raise
    finally:
        return_connection(conn)


def execute_many(sql: str, params_list: list[tuple]):
    """批量写入"""
    conn = get_connection()
    try:
        cur = conn.cursor()
        cur.executemany(sql, params_list)
        conn.commit()
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        raise
    finally:
        return_connection(conn)
