"""
洞察引擎 — 从分析结果生成商机报告（动态版 v3）
v3: AI 增强分析（Gemini/Ollama）+ 场景化评论模板 + 同城配送专用维度 + 大连知识库注入
"""
import random
import logging
from nlp.analyzer import PainClusterer, NLPAnalyzer
from knowledge.dalian_delivery import get_scenario_profile, match_scenario

logger = logging.getLogger("engine")


class InsightEngine:
    """商机洞察生成引擎"""

    # ========== 场景化评论模板（5大场景 × ~25条 = ~125条差异化模板） ==========

    SCENARIO_TEMPLATES = {
        "餐饮配送": {
            "pos": [
                "{company}的午市配送很准时，11点前食材就到店了，厨房备餐不耽误",
                "跟{company}合作食材配送半年了，每天凌晨5点准时到中央厨房",
                "{company}晚市补货速度很快，高峰期加单也能2小时内响应",
                "{company}配送的汤底包装严实，从来没漏过，温度也保持得好",
                "大连{company}覆盖了我们中山区三家店，调度灵活，换货也方便",
                "自从用{company}的日配服务，后厨不用再提前一天备货了",
                "{company}的配送员每次都帮我们把货搬进后厨，服务很到位",
                "{company}的温控配送车很专业，半成品食材送到还是冰鲜状态",
                "{company}在旅游旺季也没掉链子，运力调配得不错",
                "{company}的配送价格比我们自己养车送货便宜了至少30%",
                "用{company}配送火锅食材，分类包装不串味，店长很满意",
                "{company}对餐饮行业很了解，知道午晚市的deadline不能耽误",
            ],
            "neg": [
                "{company}午市配送晚了40分钟，11点半食材才到，厨房炸锅了",
                "找{company}送冻品，到店发现冰袋全化了，肉都变色了",
                "{company}晚高峰时段根本叫不到车，店里缺货只能干等",
                "周末{company}运力明显不够，三番五次推迟配送时间",
                "{company}把我们的货和别家的混装了，串味严重，整批报废",
                "{company}的司机不熟悉餐饮后厨流程，送货到前厅被客人看到",
                "{company}配送费涨了三次，也没提前通知，越来越贵",
                "下雨天{company}说路滑不接餐饮单，我们只能自己开车去取",
                "大连冬天暴雪，{company}直接停运三天，店里食材断了",
                "和{company}约定每天早6点配送，实际上经常7点多才到",
                "{company}送来的蔬菜明显不新鲜，像是前一天剩的",
                "{company}的保温箱太小了，我们一天的量要分两趟送",
                "{company}对餐饮的食品卫生要求不了解，配送过程不规范",
                "{company}高峰期直接拒了我们这种小店，优先送大客户",
            ],
            "neutral": [
                "{company}的餐饮配送基本满足需求，偶尔晚点但能接受",
                "用{company}送了几个月，整体还行，旺季的时候稳定性差点",
                "{company}的价格在大连算中等，服务也中规中矩",
            ],
        },
        "生鲜冷链": {
            "pos": [
                "{company}的冷链配送很专业，全程温度记录可查，樱桃季帮了大忙",
                "大连{company}的冷藏车配置好，海鲜从辽渔市场到酒店全程不脱冷",
                "{company}冷链配送的损耗率不到2%，比行业平均好太多了",
                "樱桃季找了{company}，每天凌晨从旅顺产地装车，早上就到市区",
                "{company}的温度监控系统很完善，每5分钟自动记录，合规没问题",
                "{company}针对不同品类有不同温区方案，水果和冻品分开配送",
                "海鲜季{company}帮我们解决了跨区冷链难题，旅顺到金石滩也很快",
                "和{company}签了年度冷链协议，价格锁定不受旺季影响",
                "{company}的冷链交接流程规范，每批都有温度记录签字确认",
                "{company}的冷链包装方案很专业，保温箱+冰袋+温度计三件套",
                "{company}能提供冷链验证报告，对我们做食品认证很有帮助",
                "{company}在樱桃季提前备了运力，没有出现往年爆仓的情况",
            ],
            "neg": [
                "{company}号称全程冷链，实际只有发货时有冰袋，到货都化了",
                "大连樱桃季{company}根本接不过来，爆仓直接拒单，樱桃烂在地里",
                "{company}的冷藏车温度记录仪经常故障，温度记录断断续续",
                "用{company}送冻品海鲜，到货时冰袋全化了，虾都变色发臭",
                "{company}的冷链车制冷效果不行，夏天40度车里估计有20多度",
                "{company}把我们的冻品和别人的常温货混装，冷链根本就是摆设",
                "{company}温度记录是后来补的，时间都对不上，涉嫌造假",
                "海鲜季{company}临时涨价50%，说不接受就别用了，很无奈",
                "冬天{company}说冷链车打不着火，我们一批冻品在仓库等了两天",
                "{company}的保温箱重复使用也不消毒，交叉污染风险很大",
                "{company}冷链配送的货损率超过15%，赔又赔得慢",
                "找{company}送进口冷链，结果海关检疫证明丢了，整批货被扣",
                "{company}的冷链司机根本不懂温度管控，中途关制冷省油",
                "暴雨天{company}的冷链车漏雨，纸箱全泡烂了",
            ],
            "neutral": [
                "{company}的冷链服务算达标，价格比市场均价稍高一点",
                "和{company}合作冷链配送，平时还行，旺季运力紧张需要提前一周约",
                "{company}冷链配送在行业内算中等，设备够用但不算顶尖",
            ],
        },
        "医药配送": {
            "pos": [
                "{company}的医药配送很规范，GSP认证齐全，药监局检查没问题",
                "{company}冷链药品配送全程温度监控，记录完整可追溯",
                "大连{company}的夜间急送服务很靠谱，凌晨2点下单4点就送到了",
                "{company}的医药配送员都经过专业培训，交接流程规范",
                "和{company}合作医药配送，温控验证报告每季度都按时提供",
                "{company}的冷藏箱经过验证，72小时保温没问题，急用药品有保障",
                "{company}对特殊管理药品的配送有专门方案，双人配送+签收拍照",
                "{company}帮我们药房做同城配送，处方药2小时达，客户反馈好",
                "医药配送用{company}，他们的温湿度监测系统对接了我们ERP",
                "{company}在药品追溯码上传方面做得很好，合规省心",
            ],
            "neg": [
                "{company}的医药配送资质不全，GSP认证过期了还在接单",
                "用{company}送冷链药品，温度记录显示运输中最高到了18度",
                "{company}夜间急送说好2小时到，实际等了5个多小时",
                "{company}把处方药和普通货混送，药品安全根本无法保障",
                "找{company}送疫苗，结果冷链车半路故障，整批疫苗报废",
                "{company}的医药配送流程不专业，没有温控交接确认单",
                "{company}送药到诊所时冷链箱已经开了，温度记录也不完整",
                "{company}药品配送没有追溯码上传，药监局查到要处罚的",
                "大连暴雪{company}说医药配送也停，急诊用药怎么办",
                "{company}的医药配送员没有健康证，不符合药品配送要求",
                "{company}送冷链药品用了普通面包车，只放了两个冰袋糊弄",
                "{company}药品配送延误导致患者断药，这责任谁担",
                "医药配送费{company}报价比行业高一倍，说是专业服务其实和普通没区别",
            ],
            "neutral": [
                "{company}的医药配送基本合规，但服务响应速度还有提升空间",
                "用{company}送药半年，没出过大的质量问题，小毛病偶尔有",
            ],
        },
        "家具配送": {
            "pos": [
                "{company}的家具配送很靠谱，沙发从宜家送到家完好无损",
                "{company}配送+安装一条龙服务，师傅技术好态度也好",
                "老小区没电梯，{company}两个师傅把衣柜扛上了6楼，辛苦了",
                "{company}的厢货车带升降尾板，大件装卸方便不伤货",
                "和{company}预约周末配送，准时到达还提前电话确认了",
                "{company}的家具安装师傅很专业，宜家那种图纸一看就懂",
                "{company}配送家具前会提前勘察路线，限高的地方换小面包车",
                "用{company}送了整套家具，从中山区到开发区，一件没磕碰",
                "{company}的搬运费明码标价，上6楼加100块提前说好，不临时加价",
                "{company}配送大件家具用了缠绕膜+护角+毛毯三层保护",
            ],
            "neg": [
                "{company}送来的衣柜边角磕掉了一块，说物流过程中难免",
                "找{company}送沙发，说好搬上4楼，到了楼下说没电梯要加200",
                "{company}的面包车太小了，床垫塞不进去，又回去换车耽误半天",
                "预约{company}周日配送，等到下午4点都没来，电话也打不通",
                "{company}配送师傅把新家具在地下车库拖行，地板砖都刮花了",
                "西岗区老小区，{company}的厢货车进不去巷子，说送不了",
                "{company}安装家具把墙钻坏了也不管，说他们只管装不管修",
                "{company}配送费报价800，到了说要加楼层费、安装费，最后2000多",
                "{company}送的床垫在运输中淋雨了，外包装全湿，里面也潮了",
                "用{company}送大理石餐桌，没打木架直接运，到了碎成三块",
                "{company}配送师傅一个人搬大件，明显搬不动还在硬扛",
                "大连冬天{company}说路滑不接家具单，说怕搬运出事",
                "{company}把家具放在楼下就走了，说上楼不属于配送范围",
            ],
            "neutral": [
                "{company}的家具配送总体还行，价格适中，服务态度一般",
                "用{company}送了几次家具，有时候准时有时候晚，看运气",
            ],
        },
        "商超补货": {
            "pos": [
                "{company}的商超日配很稳定，每天早上6点准时到店",
                "和{company}合作便利店补货，鲜食类日配、常温品周配，分类管理好",
                "{company}帮我们300多家门店做补货配送，系统对接后效率提高很多",
                "{company}对商超的配送时效SLA执行得很严格，迟到按合同赔付",
                "大连{company}覆盖了全市所有门店，调度系统很智能",
                "促销期{company}提前一周和我们确认补货量，运力准备充分",
                "{company}的商超配送有专门的夜间补货车队，不影响门店营业",
                "用{company}配送鲜食，保质期只有24小时的也能准时到店",
                "{company}的多店拼车方案很省钱，一条线路覆盖5家店",
                "{company}的退货回收服务也很到位，配送同时回收退货和周转箱",
            ],
            "neg": [
                "{company}便利店日配经常迟到，鲜食保质期本来就短",
                "周末促销{company}的运力跟不上，补货晚了半天，货架空了很久",
                "罗森要求{company}凌晨5点前完成配送，经常拖到7点",
                "{company}多店配送时为了省事把不同店的货混装了，到店要重新分拣",
                "{company}补货时把临期品和新品混在一起，店员要花时间挑",
                "大连暴雨天{company}说配送不安全，超市鲜食区直接空了",
                "春节前{company}运力严重不足，比平时贵了一倍还不保证时效",
                "{company}配送鲜食的保温箱太小，我们一家店一天要分三趟送",
                "和{company}签的SLA配送准时率95%，实际不到80%",
                "{company}送来的饮料有几箱漏了，把其他货也泡了",
                "新店开业{company}没有提前踩点，配送当天找不到卸货口",
                "{company}配送司机流动性太大，每周换人，交接不清楚",
            ],
            "neutral": [
                "{company}的商超补货服务基本满足日常需求，旺季需要提前协调",
                "用{company}做便利店补货，整体还算稳定，偶尔有延误",
            ],
        },
    }

    # 通用模板（未匹配到具体场景时使用）
    DEFAULT_TEMPLATES = {
        "pos": [
            "{company}的配送挺快的，下单没多久就到了，包装也很完整",
            "{company}的服务不错，送货上门态度好，会继续合作",
            "在大连用{company}的配送，时效稳定，价格也合理",
            "{company}的物流追踪很清晰，每一步都能看到，放心",
            "合作了{company}半年了，配送一直很准时，推荐",
            "从{company}订货配送很快，大连同城当天就到了",
            "{company}的包装很用心，货送到一点没损坏",
            "{company}的配送员很专业，搬运小心，态度好",
        ],
        "neg": [
            "{company}的配送太慢了，同城居然用了两天才到",
            "在{company}下单，配送员态度很差，打电话态度恶劣",
            "{company}送货的包装破了，里面的东西都压坏了",
            "{company}说好上午送到，等到下午都没影，打电话也不接",
            "大连{company}的配送费用太高了，比别家贵一倍",
            "{company}高峰期根本不接单，店里堆了一堆货没人送",
            "找{company}配送，结果送错地址了，又等了大半天",
            "{company}的客服形同虚设，出了问题根本找不到人",
            "大连冬天{company}直接停运，没有任何应急预案",
            "下雨天{company}直接不配送，也没有任何补偿方案",
            "签收发现{company}送的货少了三箱，配送单上却写着已签收",
            "老小区没电梯，{company}说要加收上楼费，订的时候没说过",
        ],
        "neutral": [
            "{company}的配送还算可以，不快不慢，中规中矩",
            "价格适中，服务也凑合，没啥特别的",
            "用了几次整体还行，有时候会晚一点",
        ],
    }

    def generate_report(self, keyword: str, analyzed_reviews: list[dict],
                        companies: list[dict] = None, industry_info: str = "") -> dict:
        scenario = match_scenario(keyword)
        profile = get_scenario_profile(keyword)

        clusterer = PainClusterer()
        cluster_result = clusterer.cluster(analyzed_reviews)
        categories = cluster_result["categories"]

        pain_heatmap = []
        for cat, stats in sorted(categories.items(), key=lambda x: x[1]["count"], reverse=True):
            pain_heatmap.append({
                "category": cat,
                "count": stats["count"],
                "frequency": stats["frequency"],
                "avg_pain_score": stats["avg_pain_score"],
                "examples": stats["examples"],
                "top_terms": stats.get("top_terms", []),
            })

        satisfaction = self._estimate_satisfaction(categories, keyword)
        opportunities = self._rank_opportunities(pain_heatmap, satisfaction, keyword)
        wordcloud = cluster_result["top_keywords"]
        target_merchants = self._generate_target_merchants(keyword, companies)

        # Build data source metadata
        data_sources = self._build_data_sources(analyzed_reviews, companies, industry_info)

        return {
            "keyword": keyword,
            "scenario": scenario,
            "data_sources": data_sources,
            "summary": self._generate_summary(keyword, cluster_result, opportunities, scenario, data_sources),
            "industry_analysis": self._generate_industry_analysis(keyword, cluster_result, industry_info, companies, profile, data_sources),
            "pain_deepdive": self._generate_pain_deepdive(opportunities[:3], keyword),
            "action_plan": self._generate_action_plan(keyword, opportunities[:3], companies, profile),
            "target_merchants": target_merchants,
            "pain_heatmap": pain_heatmap,
            "satisfaction_radar": satisfaction,
            "opportunities": opportunities,
            "wordcloud": wordcloud,
            "negative_reviews": self._collect_negative_reviews(analyzed_reviews),
            "stats": {
                "total_reviews": cluster_result["total_reviews"],
                "total_negative": cluster_result["total_negative"],
                "negativity_rate": cluster_result["negativity_rate"],
            },
            "ai_analysis": self._run_ai_analysis(keyword, cluster_result, opportunities, companies, industry_info, profile),
        }

    def _build_data_sources(self, analyzed_reviews: list[dict], companies: list[dict], industry_info: str) -> dict:
        """Build structured metadata about data provenance"""
        sources = {}
        has_web = False
        has_demo = False
        has_companies = len(companies) > 0 if companies else False
        has_industry = bool(industry_info and len(industry_info) > 50)

        for r in analyzed_reviews:
            s = (r.get("source", "") or "").lower()
            if s:
                sources[s] = sources.get(s, 0) + 1
                if "web" in s: has_web = True
                if "demo" in s or "模拟" in s: has_demo = True

        total = len(analyzed_reviews)
        web_count = sum(v for k, v in sources.items() if "web" in k)
        demo_count = sum(v for k, v in sources.items() if "demo" in k or "模拟" in k)

        disclaimer_parts = []
        if has_web and has_demo:
            disclaimer_parts.append(f"本报告基于 {web_count} 条互联网采集评论 + {demo_count} 条 AI 场景化模拟评论（共 {total} 条）生成。")
        elif has_web:
            disclaimer_parts.append(f"本报告基于 {total} 条互联网真实采集评论生成。")
        elif has_demo:
            disclaimer_parts.append(f"本报告基于 {total} 条 AI 场景化模拟评论生成，数据不代表真实用户反馈，仅供商机探索参考。")
        else:
            disclaimer_parts.append(f"本报告基于 {total} 条评论数据生成。")

        if has_companies:
            disclaimer_parts.append(f"企业数据来自搜索引擎公开信息，共匹配 {len(companies)} 家相关企业。")
        if has_industry:
            disclaimer_parts.append("行业背景信息来自互联网公开资料。")
        disclaimer_parts.append("NLP 情感分析由 SnowNLP + jieba 分词完成，聚类使用 sklearn KMeans。")

        return {
            "total_reviews": total,
            "web_review_count": web_count,
            "demo_review_count": demo_count,
            "company_count": len(companies) if companies else 0,
            "has_industry_info": has_industry,
            "source_breakdown": sources,
            "disclaimer": "".join(disclaimer_parts),
            "is_demo_only": not has_web and has_demo,
        }

    def _run_ai_analysis(self, keyword: str, cr: dict, opps: list[dict],
                         companies: list[dict], industry_info: str, profile: dict) -> dict:
        """Run AI-powered analysis with fallback. Returns empty dict if no AI available."""
        try:
            from llm.provider import AIAnalyzer
            from llm import prompts
        except ImportError:
            logger.info("LLM module not available, skipping AI analysis")
            return {}

        stats = {
            "total_reviews": cr.get("total_reviews", 0),
            "total_negative": cr.get("total_negative", 0),
            "negativity_rate": cr.get("negativity_rate", 0),
        }

        analyzer = AIAnalyzer()
        available = any(p.available() for p in analyzer._providers)
        if not available:
            logger.info("No AI provider available, skipping AI analysis")
            return {}

        logger.info("Starting AI analysis for keyword=%s", keyword)
        tasks = [
            ("executive_summary", *prompts.executive_summary_prompt(keyword, stats, opps, "")),
            ("swot", *prompts.swot_prompt(keyword, opps, industry_info, profile)),
            ("strategy", *prompts.strategy_prompt(keyword, opps, profile)),
            ("competitor_gap", *prompts.competitor_gap_prompt(keyword, opps, companies, industry_info)),
            ("action_plan", *prompts.action_plan_prompt(keyword, opps, profile, companies)),
            ("roi", *prompts.roi_prompt(keyword, companies, profile, opps)),
        ]

        results = analyzer.analyze_all(tasks)
        logger.info("AI analysis complete: %d/%d sections generated", len(results), len(tasks))
        return results

    # ========== 目标商家匹配（v3: 多维度 0-100 评分） ==========

    # 评分维度权重
    SCORE_WEIGHTS = {
        "delivery_complexity": 0.25,   # 配送复杂度（冷链/重货/时效窗/易碎）
        "order_frequency": 0.25,       # 订单频次（连锁/日配/多门店）
        "geographic_density": 0.15,    # 地理密度（核心商圈 vs 偏远）
        "b2b_vs_b2c": 0.10,            # B2B 比例（批量订单 vs 散单）
        "pain_level": 0.15,            # 痛点强度（负面配送评论多=高痛感）
        "willingness_to_pay": 0.10,    # 付费意愿（时效敏感/合规行业付费高）
    }

    # 负面信号：自己就是物流/配送公司，不需要外部同城配送
    NEGATIVE_SIGNALS = ["物流", "快递", "货运", "运输公司", "配送公司", "跑腿", "快运",
                        "速运", "搬家服务", "搬家公司", "货拉拉", "快狗", "闪送",
                        "顺丰", "中通", "圆通", "韵达", "申通", "百世", "极兔", "德邦"]

    # 高配送复杂度信号
    HIGH_COMPLEXITY_SIGNALS = {
        "冷链温控": ["冷链", "冷冻", "冷藏", "温控", "生鲜", "海鲜", "冻品", "冰鲜", "疫苗",
                    "药品", "试剂", "乳制品", "冷鲜肉", "冰淇淋", "巧克力"],
        "重货大件": ["家具", "家电", "建材", "卫浴", "瓷砖", "石材", "门窗", "机器",
                    "设备", "电梯", "空调", "冰箱", "洗衣机", "床垫", "沙发"],
        "时效窗口": ["日配", "午市", "晚市", "早市", "凌晨", "当日达", "2小时达",
                    "准时达", "限时达", "deadline", "急送", "加急"],
        "易碎品": ["玻璃", "陶瓷", "工艺品", "酒类", "红酒", "白酒", "显示",
                  "屏幕", "精密仪器", "医疗设备"],
    }

    # 高订单频次信号
    HIGH_FREQUENCY_SIGNALS = {
        "连锁多门店": ["连锁", "门店", "分店", "加盟", "直营", "300+", "200+", "100+", "50+",
                      "全城", "全市", "覆盖", "多家", "多店"],
        "日配需求": ["日配", "每日", "每天", "高频", "日鲜", "鲜食", "便当", "面包",
                    "牛奶", "鲜奶", "日日配"],
        "大批量": ["批发", "集采", "中央厨房", "总仓", "配送中心", "产业园", "基地"],
    }

    # 高付费意愿信号
    HIGH_WILLINGNESS_SIGNALS = {
        "合规行业": ["GSP", "GMP", "药监", "医保", "处方药", "疫苗", "医疗器械",
                    "食品经营许可", "检验检疫"],
        "高货值": ["珠宝", "奢侈品", "高端", "进口", "精密", "贵重", "艺术品",
                  "限量", "定制"],
        "时效敏感": ["保质期", "保鲜", "现做", "当天", "即食", "新鲜", "活鲜",
                    "急诊", "抢救", "手术"],
    }

    def _generate_target_merchants(self, keyword: str, companies: list[dict] = None) -> list[dict]:
        preset = self._get_preset_merchants(keyword)
        if not companies:
            return preset if preset else self._fallback_merchants(keyword)

        areas = ["中山区", "西岗区", "沙河口区", "甘井子区", "高新园区", "金州区", "旅顺口区", "开发区"]
        result = []
        seen = set()

        # 先加入精选预设商家（高价值、经过验证）
        if preset:
            for p in preset:
                seen.add(p["name"])
                result.append(p)

        # 再从搜索结果补充（最多补到10个）
        for c in companies[:12]:
            name = c.get("name", "")
            if name in seen or len(name) < 4:
                continue
            seen.add(name)
            snippet = c.get("snippet", "")
            url = c.get("url", "")
            area = self._guess_area(snippet, areas)
            scale = self._guess_scale(name, snippet)
            need_info = self._infer_delivery_need(keyword, name, snippet)
            score_result = self._score_company(keyword, name, snippet, need_info)
            result.append({
                "name": name, "area": area, "scale": scale,
                "need": need_info["summary"],
                "match_score": score_result["total"],
                "match_level": score_result["level"],
                "score_breakdown": score_result["breakdown"],
                "urgency": need_info["urgency"],
                "url": url,
            })
            if len(result) >= 10:
                break

        result.sort(key=lambda x: x.get("match_score", 0), reverse=True)
        return result if result else self._fallback_merchants(keyword)

    def _get_preset_merchants(self, keyword: str) -> list[dict]:
        presets = {
            "餐饮配送": [
                {"name": "喜家德水饺（大连总部）", "area": "中山区", "scale": "全国连锁500+门店",
                 "need": "中央厨房→门店日配，高峰期午晚市运力", "match_score": 92, "match_level": "极高",
                 "score_breakdown": {"配送复杂度": 90, "订单频次": 95, "地理密度": 85, "B2B占比": 90, "痛点强度": 88, "付费意愿": 95},
                 "urgency": "高",
                 "delivery_detail": {
                     "vehicle": "冷藏车（8-15m³, 1-3吨, 1.2-1.8元/km含制冷）",
                     "price_ref": "起步60-100元, 6-8元/公里, 等候60元/小时",
                     "route": "中央厨房（甘井子仓储区）→ 中山区各门店。青泥洼桥限行路段绕行，建议早5:30发车，午市11:00前全部到店",
                     "time_window": "午市 deadline 11:30前到店；晚市 deadline 17:30前到店。晚高峰堵车需预留额外30分钟",
                     "compliance": "食品经营许可证（配送方）、配送人员健康证、车辆卫生备案、保温箱检测报告",
                 }},
                {"name": "灵芝妹子海鲜米线", "area": "沙河口区", "scale": "大连30+门店",
                 "need": "汤底冷链日配+外卖平台配送外包", "match_score": 88, "match_level": "极高",
                 "score_breakdown": {"配送复杂度": 88, "订单频次": 85, "地理密度": 82, "B2B占比": 80, "痛点强度": 92, "付费意愿": 90},
                 "urgency": "高",
                 "delivery_detail": {
                     "vehicle": "冷藏车（8-15m³, 1-3吨, 1.2-1.8元/km），部分小门店可用面包车（2-3m³, 0.6-0.8元/km）",
                     "price_ref": "面包车起步30-40元, 3-4元/公里；冷藏车起步60-100元, 6-8元/公里",
                     "route": "沙河口区西安路商圈为核心，30+门店分散于沙河口+西岗+中山。西安路部分时段限行，建议错峰配送",
                     "time_window": "午市 10:00-14:00, deadline 11:30前到店。海鲜汤底需冷链全程2-8°C温控",
                     "compliance": "食品经营许可证（含冷藏冷冻食品）、配送人员健康证、冷链温度记录",
                 }},
                {"name": "鸣记烤鱼", "area": "高新园区", "scale": "大连15+门店",
                 "need": "活鱼+半成品调料同城配送", "match_score": 85, "match_level": "极高",
                 "score_breakdown": {"配送复杂度": 92, "订单频次": 78, "地理密度": 75, "B2B占比": 82, "痛点强度": 85, "付费意愿": 88},
                 "urgency": "高",
                 "delivery_detail": {
                     "vehicle": "冷藏车（活鱼需带氧运输, 8-15m³, 1.2-1.8元/km），调料包可用面包车（2-3m³, 0.6-0.8元/km）",
                     "price_ref": "活鱼冷链起步80-100元, 6-8元/公里（含增氧设备能耗）",
                     "route": "高新园区门店分布在软件园/万达/七贤岭。早晚高峰拥堵，建议避开8:00-9:00和17:30-18:30",
                     "time_window": "每日配：早8:00前到店（活鱼需当天到）。晚市补货 deadline 16:00前",
                     "compliance": "食品经营许可证、活鱼运输需水产检疫证明、配送人员健康证",
                 }},
                {"name": "大连亚惠快餐", "area": "甘井子区", "scale": "大连50+门店",
                 "need": "企业团餐批量配送，固定时段集中发车", "match_score": 82, "match_level": "高",
                 "score_breakdown": {"配送复杂度": 72, "订单频次": 90, "地理密度": 78, "B2B占比": 95, "痛点强度": 72, "付费意愿": 75},
                 "urgency": "中",
                 "delivery_detail": {
                     "vehicle": "4.2m厢货（15-18m³, 2-3吨, 1.0-1.3元/km），企业团餐单量大适合厢货集中配送",
                     "price_ref": "起步50-80元, 5-6元/公里, 等候60元/小时。大批量可谈月结合同价",
                     "route": "甘井子区仓储物流集中，可设中央厨房于大连湾/南关岭。企业客户多在甘井子工业区+高新区写字楼",
                     "time_window": "企业团餐午市 deadline 11:30前到，批量配送通常10:00-11:30集中发车",
                     "compliance": "食品经营许可证、配送人员健康证、批量配送需保温箱+温度记录",
                 }},
            ],
            "商超补货": [
                {"name": "罗森便利店（大连）", "area": "全市", "scale": "大连300+门店",
                 "need": "每日鲜食日配+常温商品周配，温控要求高", "match_score": 95, "match_level": "极高",
                 "score_breakdown": {"配送复杂度": 92, "订单频次": 98, "地理密度": 95, "B2B占比": 88, "痛点强度": 90, "付费意愿": 92},
                 "urgency": "高",
                 "delivery_detail": {
                     "vehicle": "冷藏车（鲜食日配, 8-15m³, 1.2-1.8元/km）+ 4.2m厢货（常温周配, 15-18m³, 1.0-1.3元/km）",
                     "price_ref": "日配冷藏起步60-100元, 6-8元/公里；周配厢货起步50-80元, 5-6元/公里",
                     "route": "300+门店覆盖全市，建议设中山/甘井子/高新区3个前置仓分片区配送。罗森门店密度高，单车可覆盖15-20店/天",
                     "time_window": "日配 deadline 开业前到店（通常6:00-7:00）。鲜食保质期仅24小时，延误直接报损",
                     "compliance": "食品经营许可证、冷链温度记录（每批次）、配送时效SLA协议（写入合同）、供应商准入审核",
                 }},
                {"name": "会有便利", "area": "全市", "scale": "大连200+门店",
                 "need": "社区店补货频次高、批量小，单车多店配送", "match_score": 90, "match_level": "极高",
                 "score_breakdown": {"配送复杂度": 78, "订单频次": 95, "地理密度": 92, "B2B占比": 85, "痛点强度": 88, "付费意愿": 85},
                 "urgency": "高",
                 "delivery_detail": {
                     "vehicle": "面包车（2-3m³, 0.5-1吨, 0.6-0.8元/km）为主，社区店巷子窄、大车进不去",
                     "price_ref": "面包车起步30-40元, 3-4元/公里。单车多店路线可摊薄单店成本至15-25元/店",
                     "route": "200+社区店分布广但密度高，建议按片区（中山+西岗 / 沙河口+高新 / 甘井子）分三条线路，每条线覆盖60-70店",
                     "time_window": "日配 deadline 7:00-8:00前到店。社区店营业早（6:30-7:00），需在开业前完成补货",
                     "compliance": "食品经营许可证（如配送食品）、配送时效SLA协议",
                 }},
                {"name": "大连新隆嘉超市", "area": "全市", "scale": "生鲜超市连锁30+门店",
                 "need": "生鲜果蔬日配+产地直发到店", "match_score": 87, "match_level": "极高",
                 "score_breakdown": {"配送复杂度": 90, "订单频次": 88, "地理密度": 80, "B2B占比": 82, "痛点强度": 85, "付费意愿": 80},
                 "urgency": "高",
                 "delivery_detail": {
                     "vehicle": "冷藏车（生鲜果蔬, 8-15m³, 1.2-1.8元/km），产地大批量→总仓用4.2m厢货（15-18m³, 1.0-1.3元/km）",
                     "price_ref": "生鲜冷链起步60-100元, 6-8元/公里。产地直发长途段另算（通常0.5-0.8元/吨公里）",
                     "route": "产地（旅顺/瓦房店/金州）→ 总仓（甘井子仓储区）→ 30+门店。总仓到门店日配，产地到总仓按产季调度",
                     "time_window": "早市 deadline 7:00前到门店。农贸市场/生鲜超市营业前必须到位。产地端通常凌晨2-3点装车",
                     "compliance": "食品经营许可证（含冷藏冷冻食品经营范围）、冷链运输备案、温度记录仪校准证书",
                 }},
            ],
            "生鲜冷链": [
                {"name": "大连辽渔国际水产品市场", "area": "甘井子区大连湾", "scale": "东北最大海鲜批发市场",
                 "need": "海鲜从市场到餐厅/酒店的冷链配送", "match_score": 93, "match_level": "极高",
                 "score_breakdown": {"配送复杂度": 98, "订单频次": 92, "地理密度": 85, "B2B占比": 95, "痛点强度": 95, "付费意愿": 88},
                 "urgency": "高",
                 "delivery_detail": {
                     "vehicle": "冷藏车（海鲜冷链, 8-15m³, 1-3吨, 1.2-1.8元/km含制冷）。活鲜需增氧设备，冰鲜需0-4°C恒温",
                     "price_ref": "起步80-100元, 6-8元/公里。海鲜季（4-5月, 9-10月）运价上涨20-40%，建议签年度锁价协议",
                     "route": "大连湾辽渔市场 → 市区各餐厅/酒店。核心路线：大连湾→中山区（30km, 约50min），大连湾→高新园区（35km, 约60min）",
                     "time_window": "早市 deadline 7:00前到餐厅/酒店。海鲜批发市场凌晨3-4点开市，配送5:00-7:00集中发车",
                     "compliance": "食品经营许可证（含冷藏冷冻食品）、进口冷链需海关报关单+检疫证明、冷链交接记录表（每批次）",
                 }},
                {"name": "大连棒棰岛食品", "area": "西岗区", "scale": "肉类加工龙头",
                 "need": "冷鲜肉从工厂到商超/餐厅的冷链日配", "match_score": 90, "match_level": "极高",
                 "score_breakdown": {"配送复杂度": 95, "订单频次": 88, "地理密度": 80, "B2B占比": 90, "痛点强度": 85, "付费意愿": 90},
                 "urgency": "高",
                 "delivery_detail": {
                     "vehicle": "冷藏车（冷鲜肉0-4°C恒温, 8-15m³, 1.2-1.8元/km）。冷冻品需-18°C以下，用冷冻专用车",
                     "price_ref": "起步60-100元, 6-8元/公里。大客户（商超/连锁餐厅）月结合同价可优惠15-20%",
                     "route": "西岗区加工厂 → 全市商超/餐厅。西岗老城区出发注意香炉礁立交限高3.5m，厢货需绕行",
                     "time_window": "日配 deadline 8:00前到商超/10:00前到餐厅。冷鲜肉保质期3-7天，对时效要求低于鲜食但温控更严格",
                     "compliance": "食品经营许可证（含冷藏冷冻食品）、肉类检疫证明（每批次）、冷链温度记录（全程0-4°C）",
                 }},
                {"name": "旅顺樱桃园合作社", "area": "旅顺口区", "scale": "樱桃种植合作社30+",
                 "need": "产季冷链运力严重不足，货损率高", "match_score": 86, "match_level": "极高",
                 "score_breakdown": {"配送复杂度": 88, "订单频次": 78, "地理密度": 55, "B2B占比": 75, "痛点强度": 98, "付费意愿": 92},
                 "urgency": "高",
                 "delivery_detail": {
                     "vehicle": "冷藏车（樱桃保鲜0-4°C, 8-15m³, 1.2-1.8元/km）。产季（6-7月）运力紧张，5月底前锁定车辆合同",
                     "price_ref": "产季冷藏车日租金翻倍（平时600→1200元/天）。起步80-120元, 6-8元/公里。建议签产季包车协议锁定价格",
                     "route": "旅顺 → 大连市区（40-60km, 约60-80min）。旅顺南路限速，建议走旅顺北路→机场→市区配送点",
                     "time_window": "樱桃季 deadline：采摘后4小时内预冷处理，12小时内冷链发出，24小时内到终端。6月初-7月中旬为高峰期",
                     "compliance": "食品经营许可证、冷链运输备案、温度记录仪校准证书。产地端需预冷设备（樱桃采摘后田间热需快速去除）",
                 }},
            ],
            "医药配送": [
                {"name": "海王星辰大药房（大连）", "area": "全市", "scale": "大连200+门店",
                 "need": "冷链药品从总仓到各门店日配", "match_score": 91, "match_level": "极高",
                 "score_breakdown": {"配送复杂度": 95, "订单频次": 90, "地理密度": 88, "B2B占比": 85, "痛点强度": 88, "付费意愿": 95},
                 "urgency": "高",
                 "delivery_detail": {
                     "vehicle": "冷藏车（冷链药品2-8°C恒温, 8-15m³, 1.2-1.8元/km）。需配备温湿度监测系统（每5分钟自动记录）",
                     "price_ref": "起步60-100元, 6-8元/公里。冷链药品保价费为货值3%（远高于普通货物）",
                     "route": "总仓（甘井子仓储区）→ 全市200+门店。建议分东/西两条线路，东线覆盖中山+西岗+沙河口，西线覆盖甘井子+高新+旅顺",
                     "time_window": "日配 deadline 营业时间内（8:00-12:00）。夜间急用药 deadline 下单后2小时内（20:00-08:00）",
                     "compliance": "GSP认证（药品经营质量管理规范）、药品经营许可证、冷链验证报告（冷藏车/保温箱/冷库）、温湿度监测系统、药品追溯码系统对接",
                 }},
                {"name": "成大方圆药房", "area": "全市", "scale": "大连150+门店",
                 "need": "处方药同城配送+夜间急用药配送", "match_score": 89, "match_level": "极高",
                 "score_breakdown": {"配送复杂度": 90, "订单频次": 88, "地理密度": 85, "B2B占比": 80, "痛点强度": 90, "付费意愿": 95},
                 "urgency": "高",
                 "delivery_detail": {
                     "vehicle": "面包车（处方药常温配送, 2-3m³, 0.6-0.8元/km）+ 冷藏车（冷链药品, 8-15m³, 1.2-1.8元/km）",
                     "price_ref": "常温药起步30-40元, 3-4元/公里。夜间急送（22:00-06:00）加收20-30%。冷链药品保价费货值3%",
                     "route": "150+门店覆盖全市。夜间急用药需建立24小时值班机制，建议在沙河口区设夜间值班点",
                     "time_window": "常规日配 8:00-12:00。夜间急送 20:00-08:00, deadline 下单后2小时内。处方药需核验处方后方可配送",
                     "compliance": "GSP认证、药品经营许可证、处方药配送需核验处方原件、配送记录保存5年以上",
                 }},
                {"name": "大连九州通医药", "area": "甘井子区", "scale": "医药流通企业",
                 "need": "药品从仓库到医院的B2B配送", "match_score": 84, "match_level": "高",
                 "score_breakdown": {"配送复杂度": 92, "订单频次": 80, "地理密度": 70, "B2B占比": 98, "痛点强度": 75, "付费意愿": 90},
                 "urgency": "中",
                 "delivery_detail": {
                     "vehicle": "4.2m厢货（15-18m³, 2-3吨, 1.0-1.3元/km）为主，医院单次配送量大。冷链药品用冷藏车（8-15m³, 1.2-1.8元/km）",
                     "price_ref": "起步50-80元, 5-6元/公里。B2B批量配送通常签年度框架合同，价格按月结算可优惠10-15%",
                     "route": "甘井子医药仓库 → 大连各医院。核心路线：甘井子→中山区医院（30-40min），甘井子→金州/开发区医院（40-50min）",
                     "time_window": "医院配送 deadline 8:00-17:00（营业时间）。急用药品需2小时内响应。部分医院有固定收货时间窗口需提前确认",
                     "compliance": "GSP认证、药品经营许可证、道路运输许可证、药品追溯码系统（国家药监局要求）、冷链验证报告",
                 }},
            ],
            "家具配送": [
                {"name": "宜家家居大连商场", "area": "西岗区香炉礁", "scale": "全球连锁",
                 "need": "家具同城配送+上门安装，老小区上楼难", "match_score": 88, "match_level": "极高",
                 "score_breakdown": {"配送复杂度": 92, "订单频次": 78, "地理密度": 80, "B2B占比": 60, "痛点强度": 95, "付费意愿": 85},
                 "urgency": "高",
                 "delivery_detail": {
                     "vehicle": "平板车（敞篷, 3-5吨, 1.0-1.5元/km）大件家具 + 4.2m厢货（15-18m³, 2-3吨, 1.0-1.3元/km）中小件。平板车黄牌白天核心商圈禁行",
                     "price_ref": "起步50-80元, 5-6元/公里。上楼费：无电梯每层5-15元，大件(>30kg)加收50-100%。安装费另计",
                     "route": "西岗区香炉礁 → 全市客户家。香炉礁立交限高3.5m，平板车需绕行地面道路。周末配送需求占60%以上",
                     "time_window": "日间配送 9:00-18:00，需提前电话确认客户在家。周末配送 9:00-18:00（需求占60%+）。预约精确到2小时窗口",
                     "compliance": "道路运输许可证、搬运服务保险（建议购买货物运输险，保额≥货值）、安装服务资质（如提供安装）",
                 }},
                {"name": "红星美凯龙大连华南商场", "area": "甘井子区华南", "scale": "全国连锁家居卖场",
                 "need": "入驻品牌的统一配送安装服务", "match_score": 85, "match_level": "极高",
                 "score_breakdown": {"配送复杂度": 88, "订单频次": 75, "地理密度": 72, "B2B占比": 70, "痛点强度": 90, "付费意愿": 82},
                 "urgency": "中",
                 "delivery_detail": {
                     "vehicle": "4.2m厢货（15-18m³, 2-3吨, 1.0-1.3元/km）+ 平板车（3-5吨, 1.0-1.5元/km）。入驻品牌多，车型需灵活搭配",
                     "price_ref": "起步50-80元, 5-6元/公里。上楼费：有电梯固定10-30元，无电梯每层5-15元。华南区域配送平均50-100元/单",
                     "route": "甘井子华南 → 全市。华南商圈交通较通畅，但早晚高峰东联路/华东路拥堵，建议10:00后发车避开早高峰",
                     "time_window": "与客户预约制，通常提前1天电话确认。周末配送占比60%以上。红星美凯龙营业时间9:30-18:00",
                     "compliance": "道路运输许可证、货物运输险（建议每单投保）、搬运+安装一体服务资质",
                 }},
                {"name": "大连华南家居大世界", "area": "甘井子区华南", "scale": "本地家居建材市场",
                 "need": "中小商户共享配送安装服务", "match_score": 80, "match_level": "高",
                 "score_breakdown": {"配送复杂度": 85, "订单频次": 70, "地理密度": 65, "B2B占比": 75, "痛点强度": 88, "付费意愿": 72},
                 "urgency": "中",
                 "delivery_detail": {
                     "vehicle": "4.2m厢货（15-18m³, 2-3吨, 1.0-1.3元/km）为主，中小商户共享配送可拼车降低成本。大件用平板车",
                     "price_ref": "起步50-80元, 5-6元/公里。共享配送模式：同方向拼车单均成本可降至30-50元（比单独配送节省40-60%）",
                     "route": "甘井子华南 → 全市。华南商圈周边老小区（如山东路沿线）无电梯比例高（约40%），上楼搬运是核心服务",
                     "time_window": "商户自行与客户预约，配送时间灵活。建议集中周六/周日配送（需求占60%+），提高单车装载率",
                     "compliance": "道路运输许可证、货物运输险、搬运服务保险。中小商户通常无自有车辆，共享配送是刚需",
                 }},
            ],
        }
        # Broad matching: check if keyword overlaps with preset key or its trigger words
        for key, merchants in presets.items():
            if key in keyword:
                return merchants
        # Check single-char overlaps (e.g., "餐饮" matches "餐饮配送", "冷链" matches "生鲜冷链")
        for key, merchants in presets.items():
            # Extract meaningful 2-char substrings from the preset key
            fragments = [key[i:i+2] for i in range(len(key)-1)]
            if any(frag in keyword for frag in fragments):
                return merchants
        return []

    def _fallback_merchants(self, keyword: str) -> list[dict]:
        """无搜索数据时的兜底 — 基于关键词构造合理的目标商家"""
        # 使用 _score_company 对兜底商家进行关键词感知评分
        name1 = f"大连{keyword}相关商家（待定向调研）"
        snippet1 = f"大连{keyword}行业企业，有{keyword}产品的同城配送需求"
        score1 = self._score_company(keyword, name1, snippet1)
        return [
            {"name": name1, "area": "大连市", "scale": "待确认",
             "need": f"{keyword}产品的同城配送需求",
             "match_score": score1["total"], "match_level": score1["level"],
             "score_breakdown": score1["breakdown"], "urgency": "中"},
            {"name": f"请联系我们获取{keyword}行业定制化商机报告", "area": "大连", "scale": "定制服务",
             "need": f"基于{keyword}行业的深度调研与配送需求分析",
             "match_score": 0, "match_level": "定制",
             "score_breakdown": {}, "urgency": "低"},
        ]

    def _guess_area(self, snippet: str, areas: list) -> str:
        for area in areas:
            if area in snippet:
                return area
        return "大连市"

    def _guess_scale(self, name: str, snippet: str) -> str:
        text = name + snippet
        if any(w in text for w in ["集团", "上市", "连锁", "全国", "中国", "全球"]):
            return "大型企业/连锁"
        if any(w in text for w in ["有限", "科技", "实业", "贸易", "品牌"]):
            return "中小企业"
        return "待确认"

    def _infer_delivery_need(self, keyword: str, name: str, snippet: str) -> dict:
        """推断配送需求，返回结构化字典含 urgency/complexity/frequency"""
        text = name + snippet
        needs = []
        complexity_signals = 0
        frequency_signals = 0

        if any(w in text for w in ["冷链", "食品", "生鲜", "冷冻", "冷藏", "海鲜", "肉", "奶", "水果", "蔬菜", "冻品"]):
            needs.append("冷链温控配送")
            complexity_signals += 1
        if any(w in text for w in ["家具", "家电", "建材", "大件", "卫浴", "机器", "设备"]):
            needs.append("大件配送+上门安装")
            complexity_signals += 1
        if any(w in text for w in ["批发", "市场", "供应", "商贸", "经销商"]):
            needs.append("B2B批量配送")
            frequency_signals += 1
        if any(w in text for w in ["门店", "连锁", "超市", "便利", "药房", "餐饮", "餐厅"]):
            needs.append("门店日配补货")
            frequency_signals += 1
        if any(w in text for w in ["电商", "线上", "平台", "网店", "直播"]):
            needs.append("电商仓储+末端配送")
            frequency_signals += 0.5
        if any(w in text for w in ["工厂", "生产", "制造", "加工", "产业园"]):
            needs.append("工厂到仓/店的干线运输")
            complexity_signals += 0.5
        if any(w in text for w in ["药", "疫苗", "试剂", "医疗", "GSP", "处方"]):
            needs.append("合规医药配送")
            complexity_signals += 1
        if not needs:
            needs.append(f"{keyword}产品同城配送")

        # 紧迫度判定
        if any(w in text for w in ["日配", "每日", "天天", "当天", "鲜食", "鲜奶", "便当", "急送", "加急"]):
            urgency = "高"
        elif any(w in text for w in ["周配", "定期", "经常", "频繁"]):
            urgency = "中"
        elif any(w in text for w in ["偶尔", "临时", "不定期", "季节性"]):
            urgency = "低"
        else:
            urgency = "中"

        return {
            "summary": "；".join(needs[:3]),
            "urgency": urgency,
            "complexity_score": min(10, complexity_signals * 2.5 + 2),
            "frequency_score": min(10, frequency_signals * 2.5 + 2),
        }

    def _score_company(self, keyword: str, name: str, snippet: str, need_info: dict = None) -> dict:
        """多维度 0-100 评分：企业需要同城配送的匹配度

        v3.1: 当 snippet 稀疏时（<30字），大量使用关键词推断信号，
        确保不同关键词产生差异化的匹配分数。
        """
        text = name + snippet
        if need_info is None:
            need_info = self._infer_delivery_need(keyword, name, snippet)

        is_sparse = len(snippet) < 30  # web-scanned companies have minimal snippets

        # 0. 负面信号检测：物流公司本身 = 不需要外部配送
        # 但如果公司名同时包含行业词（生鲜/食品/医药等），可能是自建配送的商家，
        # 旺季仍有溢出运力需求，不直接归零
        industry_words = ["生鲜", "食品", "医药", "餐饮", "家具", "建材", "超市",
                         "便利", "水果", "蔬菜", "海鲜", "水产", "肉", "奶", "蛋",
                         "零食", "饮料", "酒", "服装", "鞋", "家电", "手机", "电脑",
                         "母婴", "宠物", "文具", "办公", "日用", "美妆", "化妆品"]
        has_industry_signal = any(w in name for w in industry_words)

        for sig in self.NEGATIVE_SIGNALS:
            if sig in name or sig in snippet[:50]:
                if not any(w in text for w in ["商家", "门店", "餐厅", "商超", "药房"]):
                    if has_industry_signal:
                        # 行业公司自建配送 → 旺季仍有溢出需求，减分但不归零
                        penalty = 25
                    else:
                        # 纯物流公司 → 不需要外部配送
                        return {"total": max(5, 15 - len(sig)), "level": "不匹配",
                                "breakdown": {"配送复杂度": 10, "订单频次": 10, "地理密度": 10,
                                             "B2B占比": 10, "痛点强度": 5, "付费意愿": 5},
                                "reason": f"该公司本身是物流/配送企业（检测到「{sig}」），不需要外部同城配送服务"}
                    break
        else:
            penalty = 0

        # 构建扩展文本：snippet + 关键词 + need_info summary
        extended_text = text + " " + keyword + " " + need_info.get("summary", "")

        # 1. 配送复杂度 (0-100)
        complexity = 30  # baseline
        for dim, signals in self.HIGH_COMPLEXITY_SIGNALS.items():
            for sig in signals:
                if sig in extended_text:
                    complexity += 15
                    break
        # 稀疏数据时：用关键词推断复杂度
        if is_sparse:
            if any(w in keyword for w in ["冷链", "医药", "生鲜", "药", "疫苗"]):
                complexity += 25
            elif any(w in keyword for w in ["家具", "建材", "家电", "大件"]):
                complexity += 20
            elif any(w in keyword for w in ["餐饮", "商超", "便利"]):
                complexity += 10
        complexity = min(100, complexity)

        # 2. 订单频次 (0-100)
        frequency = 25  # baseline
        for dim, signals in self.HIGH_FREQUENCY_SIGNALS.items():
            for sig in signals:
                if sig in extended_text:
                    frequency += 18
                    break
        # 关键词暗示频次
        if any(w in keyword for w in ["餐饮", "商超", "便利", "日配", "鲜食"]):
            frequency += 20
        elif any(w in keyword for w in ["生鲜", "冷链", "医药", "药"]):
            frequency += 15
        elif any(w in keyword for w in ["家具", "建材", "家电"]):
            frequency += 8
        # 稀疏数据额外boost
        if is_sparse:
            frequency += 10
        frequency = min(100, frequency)

        # 3. 地理密度 (0-100)
        geo = 40  # baseline (大连市)
        areas = ["中山区", "西岗区", "沙河口区", "甘井子区"]
        area_count = sum(1 for a in areas if a in extended_text)
        if area_count >= 2:
            geo += 30
        elif area_count >= 1:
            geo += 15
        if any(w in extended_text for w in ["全市", "全城", "覆盖", "多店", "多门店"]):
            geo += 25
        if any(w in extended_text for w in ["旅顺", "金州", "开发区", "金石滩", "普兰店"]):
            geo += 10
        # 稀疏数据：连锁/门店类关键词暗示高密度
        if is_sparse:
            if any(w in keyword for w in ["餐饮", "商超", "便利", "药", "医药"]):
                geo += 15
            else:
                geo += 5
        geo = min(100, geo)

        # 4. B2B 比例 (0-100)
        b2b = 50  # baseline
        if any(w in extended_text for w in ["批发", "供应", "商贸", "B2B", "企业", "集团", "工厂", "产业园"]):
            b2b += 25
        if any(w in extended_text for w in ["门店", "连锁", "零售", "超市", "便利", "终端"]):
            b2b += 15
        if any(w in extended_text for w in ["电商", "线上", "消费者", "C端", "个人"]):
            b2b -= 10
        if is_sparse:
            if any(w in keyword for w in ["批发", "供应", "商贸"]):
                b2b += 20
            elif any(w in keyword for w in ["餐饮", "商超", "便利", "医药", "药"]):
                b2b += 10
        b2b = max(10, min(100, b2b))

        # 5. 痛点强度 (0-100)
        pain = 35  # baseline
        pain_signals = ["差评", "吐槽", "投诉", "痛点", "问题", "不满", "难", "贵", "慢",
                       "延迟", "损坏", "破损", "断链", "拒单", "爆仓", "涨价", "加价"]
        pain_count = sum(1 for s in pain_signals if s in extended_text)
        pain += pain_count * 12
        # 场景本身痛感（关键词推断）
        if any(w in keyword for w in ["冷链", "医药", "生鲜"]):
            pain += 20
        elif any(w in keyword for w in ["家具", "建材"]):
            pain += 15
        elif any(w in keyword for w in ["餐饮", "商超"]):
            pain += 10
        pain = min(100, pain)

        # 6. 付费意愿 (0-100)
        willingness = 40  # baseline
        for dim, signals in self.HIGH_WILLINGNESS_SIGNALS.items():
            for sig in signals:
                if sig in extended_text:
                    willingness += 20
                    break
        if any(w in keyword for w in ["医药", "冷链", "生鲜"]):
            willingness += 20
        elif any(w in keyword for w in ["餐饮", "商超"]):
            willingness += 10
        if any(w in extended_text for w in ["连锁", "品牌", "集团", "上市"]):
            willingness += 10
        if is_sparse:
            willingness += 8
        willingness = min(100, willingness)

        # 加权总分
        total = round(
            complexity * self.SCORE_WEIGHTS["delivery_complexity"] +
            frequency * self.SCORE_WEIGHTS["order_frequency"] +
            geo * self.SCORE_WEIGHTS["geographic_density"] +
            b2b * self.SCORE_WEIGHTS["b2b_vs_b2c"] +
            pain * self.SCORE_WEIGHTS["pain_level"] +
            willingness * self.SCORE_WEIGHTS["willingness_to_pay"]
        )
        if penalty:
            total = max(15, total - penalty)

        # 分级（降低门槛，让更多企业进入"中"以上）
        if total >= 80:
            level = "极高"
        elif total >= 60:
            level = "高"
        elif total >= 40:
            level = "中"
        elif total >= 20:
            level = "低"
        else:
            level = "不匹配"

        return {
            "total": total,
            "level": level,
            "breakdown": {
                "配送复杂度": complexity,
                "订单频次": frequency,
                "地理密度": geo,
                "B2B占比": b2b,
                "痛点强度": pain,
                "付费意愿": willingness,
            },
        }

    # ========== 市场满足度评估（v3: 从动态发现的话题维度计算） ==========

    def _estimate_satisfaction(self, categories: dict, keyword: str = "") -> list[dict]:
        """从聚类结果动态计算满足度 — 不再使用硬编码维度"""
        radar = []
        for cat, stats in categories.items():
            count = stats.get("count", 0)
            # 满足度 = 10 - (该话题的投诉密度 × 2)，至少1分
            raw = max(1.0, 10.0 - count * 2)
            score = round(min(10, max(1, raw)), 1)
            radar.append({
                "dimension": cat,
                "satisfaction": score,
                "top_terms": stats.get("top_terms", []),
            })
        return sorted(radar, key=lambda x: x["satisfaction"])

    # ========== 商机排序（v3: 动态话题 + 关键词感知权重） ==========

    def _rank_opportunities(self, pain_heatmap: list[dict], satisfaction: list[dict],
                            keyword: str = "") -> list[dict]:
        sat_map = {s["dimension"]: s["satisfaction"] for s in satisfaction}
        nlp = NLPAnalyzer()
        opportunities = []
        for item in pain_heatmap:
            cat = item["category"]
            sat = sat_map.get(cat, 5)
            gap = 10 - sat
            kw_weight = nlp.get_category_weight(cat, keyword)
            score = item["frequency"] * item["avg_pain_score"] * (gap / 10) * kw_weight
            score = round(score * 100, 1)
            willingness = "高" if score > 30 else "中" if score > 15 else "低"
            opportunities.append({
                "category": cat,
                "score": score,
                "frequency": item["frequency"],
                "pain_intensity": item["avg_pain_score"],
                "satisfaction_gap": round(gap, 1),
                "willingness_to_pay": willingness,
                "top_terms": item.get("top_terms", []),
                "examples": item.get("examples", []),
                "suggestion": self._generate_suggestion(cat, willingness, keyword,
                                                        item.get("top_terms", []),
                                                        item.get("examples", [])),
            })
        return sorted(opportunities, key=lambda x: x["score"], reverse=True)

    def _generate_suggestion(self, category: str, willingness: str, keyword: str = "",
                             top_terms: list[str] = None, examples: list[str] = None) -> str:
        """v3: 数据驱动的建议生成 — 基于实际话题词和示例评论构造"""
        terms = top_terms or []
        # 尝试匹配已知维度关键词
        known_dimensions = {
            "配送时效": "建立分时段配送SLA（午市/晚市/夜间），承诺超时赔付，用时间确定性建立竞争壁垒",
            "温控": "配置GPS+温度传感器冷藏车，提供可追溯的温度记录报告，建立「全程不断链」的品牌承诺",
            "运力": "先深耕中山/沙河口/甘井子核心区域，用高密度覆盖建立口碑，再向外围扩展",
            "上楼": "制定透明上楼费价目表（按楼层/重量），将搬运纳入标准服务而非增值收费",
            "货物完好": "按品类定制包装方案（缠绕膜+护角+毛毯），装卸SOP标准化，破损率目标<1%",
            "价格": "推行一口价模式（起步价+公里费+附加费明示），消除隐性收费，建立价格信任",
            "应急": "建立24小时值班机制+恶劣天气应急预案，做「关键时刻最靠谱」的配送商",
            "信息": "建设实时追踪系统（GPS+签收拍照+电子回单），消除配送过程中的信息黑洞",
            "履约": "构建「核心运力+弹性运力」两级运力池，将履约率稳定在95%以上",
            "售后": "建立「先赔后查」48小时快速理赔通道，用售后体验形成口碑传播",
            "车辆": "按行业匹配车型（餐饮用面包车、生鲜用冷藏车、家具用带尾板厢货），做专业化车队",
        }

        # 用 top_terms 匹配最相关的已知维度
        category_lower = category.lower()
        for dim_key, suggestion in known_dimensions.items():
            if dim_key in category_lower or dim_key in category:
                result = suggestion
                if willingness == "高":
                    result += "（高价值商机，建议优先投入资源）"
                return result

        # 没有精确匹配 — 基于 top_terms 构造动态建议
        if terms:
            term_list = "、".join(terms[:3])
            base = f"针对「{term_list}」相关痛点，建议结合{keyword}行业特点设计差异化解决方案"
        else:
            base = f"深入调研「{category}」相关用户诉求，针对性设计差异化服务方案"

        if willingness == "高":
            base += "（高价值商机，建议优先投入资源）"
        return base

    # ========== 报告段落（场景感知动态生成） ==========

    def _generate_summary(self, keyword: str, cr: dict, opps: list[dict], scenario: str = "", data_sources: dict = None) -> str:
        total, neg, rate = cr["total_reviews"], cr["total_negative"], cr["negativity_rate"]
        top = opps[0] if opps else None
        scenario_label = f"（{scenario}场景）" if scenario else ""

        lines = [
            f"「{keyword}」{scenario_label}共分析{total}条用户反馈，负面评价{neg}条（占比{rate*100:.1f}%）。",
        ]

        if top:
            lines.append(
                f"最大痛点集中在「{top['category']}」维度，商机分数{top['score']}分，"
                f"满足度缺口{top['satisfaction_gap']}分，付费意愿{top['willingness_to_pay']}。"
            )
        else:
            lines.append("暂未发现显著的商机维度，建议扩大数据采集范围后重新分析。")

        # 场景特定的洞察
        scenario_insights = {
            "餐饮配送": "餐饮配送的核心是「时效窗口匹配」——午市11:30前、晚市17:30前必须到货，迟到的食材等于废品。",
            "生鲜冷链": "生鲜冷链的核心是「全程不断链」——从产地到门店的每一个环节都要有温度记录，否则货损和合规风险极高。",
            "医药配送": "医药配送的核心是「合规先行」——GSP认证、温控记录、药品追溯码，任何一项缺失都是致命风险。",
            "家具配送": "家具配送的核心是「上楼搬运」——大连老城区大量无电梯老楼，搬运能力比车辆本身更重要。",
            "商超补货": "商超补货的核心是「日配稳定性」——鲜食保质期只有24小时，配送延误直接导致报损和货架空置。",
        }
        if scenario in scenario_insights:
            lines.append(scenario_insights[scenario])

        if top:
            lines.append(
                f"\n\n【核心商机】「{top['category']}」是当前最大的差异化切入点，"
                f"满足度缺口{top['satisfaction_gap']}分说明现有方案在该维度明显不足，"
                f"付费意愿{top['willingness_to_pay']}。"
                f"建议从{scenario if scenario else keyword}场景的专业化配送切入，"
                f"优先解决{top['category']}问题建立口碑壁垒。"
            )

        lines.append("下文将从行业现状、痛点根因、行动路径三个层面展开详细分析。")

        # Data source disclaimer
        if data_sources and data_sources.get("disclaimer"):
            lines.append(f"\n\n📌 数据来源说明：{data_sources['disclaimer']}")

        return "".join(lines)

    def _generate_industry_analysis(self, keyword: str, cr: dict,
                                     industry_info: str = "", companies: list[dict] = None,
                                     profile: dict = None) -> str:
        rate, total, neg = cr["negativity_rate"], cr["total_reviews"], cr["total_negative"]
        company_count = len(companies) if companies else 0
        company_names = [c["name"] for c in companies[:5]] if companies else []
        scenario = profile.get("scenario", "通用") if profile else "通用"

        parts = []

        # 一、市场规模与结构
        parts.append(f"一、市场规模与结构\n"
                     f"「{keyword}」作为大连同城配送的{scenario}细分市场，本次分析覆盖{total}条用户反馈。")

        if company_names:
            parts.append(f"搜索发现大连地区与「{keyword}」相关的企业包括：{'、'.join(company_names[:5])}等{company_count}家。"
                         f"这些企业在供应链和终端配送环节均有物流服务需求。")
        else:
            parts.append(f"大连地区「{keyword}」市场目前处于待开发状态，尚未出现专业化的第三方同城配送服务商。")

        if industry_info:
            summary = industry_info[:400].replace("|", "；")
            parts.append(f"行业公开信息显示：{summary}")

        # 注入合规要求
        if profile and profile.get("regulations"):
            regs = profile["regulations"]
            parts.append(f"该场景下的关键合规要求包括：{'；'.join(regs[:4])}。合规能力是进入该市场的准入门槛。")

        # 二、竞争格局
        parts.append(f"\n\n二、竞争格局与核心矛盾")
        parts.append(f"从{total}条数据分析，负面率{rate:.0%}，反映出该领域配送服务的明显短板。")

        if profile and profile.get("competitive_gap"):
            parts.append(profile["competitive_gap"])
        else:
            parts.append(f"目前大连市场上缺乏针对「{keyword}」场景的专业配送解决方案，"
                         f"商家多依赖自有运力或通用快递服务，存在标准化程度低、旺季运力不足、服务体验不稳定等问题。")

        # 注入车型建议
        if profile and profile.get("suitable_vehicles"):
            vehicles = profile["suitable_vehicles"]
            parts.append(f"该场景推荐的配送车型为：{'、'.join(vehicles[:3])}。")

        # 三、机会信号（注入季节性因素）
        parts.append(f"\n\n三、机会信号")
        if rate > 0.2:
            parts.append(f"负面率{rate:.0%}处于较高水平，说明用户对现有配送方案不满，存在明确的改善需求和付费意愿。")

            if profile and profile.get("seasonal_factors"):
                seasons = profile["seasonal_factors"]
                current_month_seasons = [s for s in seasons if any(True for _ in s["months"])]
                # 取前两个季节性因素作为示例
                for s in seasons[:2]:
                    parts.append(f"大连{s['name']}（{s.get('months', '')}月）期间，{s.get('impact', '配送运力紧张')}。"
                                 f"这是差异化服务的窗口期——{'、'.join(s.get('mitigation', '').split('，')[:2])}。")

            parts.append(f"建议物流公司优先关注排名前三的痛点维度，"
                         f"通过「专业化+标准化」的差异化服务切入市场。")
        else:
            parts.append(f"虽然整体负面率不高，但在配送高峰期和恶劣天气下，服务质量波动明显。"
                         f"「{keyword}」场景下的专业化配送仍是一个蓝海市场，"
                         f"先行者可通过建立标准化服务体系和品牌口碑形成先发优势。")

        # 注入区域策略
        if profile and profile.get("district_strategy"):
            parts.append(profile["district_strategy"])

        if company_names:
            parts.append(f"建议优先接触{'、'.join(company_names[:3])}等企业，了解其当前配送痛点和合作意愿。")

        # 四、切入策略
        top_cat_name = cr.get("categories", {})
        top_cat = list(top_cat_name.keys())[0] if top_cat_name else keyword
        competitive_gap = profile.get("competitive_gap", "") if profile else ""
        parts.append(
            f"\n\n四、切入策略\n"
            f"基于以上分析，建议以「{top_cat}」为差异化锚点切入{scenario}市场。"
            f"第一步：针对{top_cat}痛点设计专属SOP和服务承诺（如准时率99%+赔付机制），"
            f"用可量化的服务标准建立信任。"
            f"第二步：在中山区、西岗区等核心商圈建立标杆客户案例，"
            f"用口碑传播替代广告投放。"
            f"第三步：当服务能力验证后，快速复制到甘井子区、高新区等扩展区域。"
            f"{' ' + competitive_gap if competitive_gap else ''}"
        )

        return "".join(parts)

    def _generate_pain_deepdive(self, top_opps: list[dict], keyword: str = "") -> str:
        if not top_opps:
            return "暂无足够数据进行痛点深挖。"

        parts = []
        for i, opp in enumerate(top_opps):
            cat, freq, pain, gap = opp["category"], opp["frequency"], opp["pain_intensity"], opp["satisfaction_gap"]
            sev = "严重" if pain > 0.35 else "中等" if pain > 0.2 else "一般"
            fd = "高频" if freq > 0.5 else "中频" if freq > 0.25 else "低频"
            top_terms = opp.get("top_terms", [])
            examples = opp.get("examples", [])
            detail = self._get_pain_detail(cat, keyword, i + 1, fd, freq, sev, gap, top_terms, examples)
            parts.append(detail)

        return "\n\n".join(parts)

    def _get_pain_detail(self, cat: str, keyword: str, idx: int,
                         fd: str, freq: float, sev: str, gap: float,
                         top_terms: list[str] = None, examples: list[str] = None) -> str:
        """v3: 数据驱动的痛点深度分析 — 基于聚类结果和示例评论生成"""
        terms = top_terms or []
        examples = examples or []

        header = f"痛点{idx}：「{cat}」——{fd}发生（{freq:.0%}），严重度{sev}，满足度缺口{gap:.1f}分\n\n"

        # 构建示例引用
        example_text = ""
        if examples:
            quoted = "；".join(f"「{e[:60]}」" for e in examples[:2])
            example_text = f"用户典型抱怨：{quoted}。"

        # 根因分析 — 基于 top_terms 和关键词动态生成
        root_cause = self._build_root_cause(cat, keyword, terms)

        # 行动建议
        action = self._build_pain_action(cat, keyword, terms)

        return f"{header}{example_text}\n{root_cause}\n{action}"

    def _build_root_cause(self, cat: str, keyword: str, terms: list[str]) -> str:
        """基于话题词动态构造根因分析"""
        term_text = "、".join(terms[:4]) if terms else cat

        # 根因模板引擎：根据 terms 中的关键词匹配对应的根因
        cause_patterns = {
            "配送|时效|晚|慢|迟到|延误|准时|迟到|等了|才到|不守时|预约|午市|晚市": (
                f"根因分析：同城配送的时效承诺需要匹配商家的营业节奏。"
                f"从评论中提取的关键词「{term_text}」表明，用户对配送时间窗口有明确预期。"
                f"大连冬季暴雪天气和旅游旺季（7-8月）期间，配送履约率可能显著下降。"
                f"核心问题不在于运力总量，而在于运力与需求波峰的时间匹配精度。"
            ),
            "冷链|温控|冷藏|冷冻|温度|冰袋|化冻|变质|保温|制冷|冷链车|冷链断链|解冻": (
                f"根因分析：真正的全程冷链需要冷藏车+温度记录仪+交接验证三个环节。"
                f"关键词「{term_text}」反映当前配送的冷链环节存在断点——"
                f"多数号称冷链配送的服务商实际只放了冰袋，无法提供连续温度记录。"
                f"GSP合规和食品安全法对冷链有明确要求，这是既是合规风险也是竞争壁垒。"
            ),
            "上楼|搬运|电梯|楼梯|楼层|上楼费|搬运费|搬货|卸货|只送到楼下|不帮搬|老小区|没电梯": (
                f"根因分析：大连中山区、西岗区大量老旧居民楼和商住两用楼没有电梯。"
                f"关键词「{term_text}」暴露了当前配送服务在末端搬运环节的缺口——"
                f"多数配送司机以「只送到楼下」为由拒绝搬运，或临时加价50-200元。"
                f"上楼搬运不是增值服务而是刚需，尤其在家具、建材、批量食材等场景下。"
            ),
            "价格|贵|费用|收费|加价|涨价|起步价|公里费|等候费|隐性|报价|结算|乱收费": (
                f"根因分析：同城配送的价格构成（起步价+公里费+上楼费+等候费+夜间附加）"
                f"对商家来说不够透明。从关键词「{term_text}」看，"
                f"司机临时加价（上楼费、等候费）是最常见的纠纷来源。"
                f"推行一口价模式可将价格透明度作为差异化核心卖点。"
            ),
            "破损|损坏|坏|压坏|磕碰|摔坏|洒|漏|碎|包装|货损|摔烂|变形|刮花": (
                f"根因分析：配送流程中缺少标准化的包装规范和装卸操作SOP。"
                f"关键词「{term_text}」指向货物保护措施的不足。"
                f"按品类定制包装方案（缠绕膜+护角+毛毯+防震），单票成本增加不到1元，"
                f"但可以大幅降低货损赔付（通常单票赔付在50-200元）。"
            ),
            "运力|覆盖|不配送|不送货|不送|区域|偏远|送不到|爆仓|不接单": (
                f"根因分析：大连的地理特点（中山区商圈密集、甘井子仓储集中、旅顺远距）"
                f"决定了同城配送不能「一刀切」定价和覆盖。"
                f"「{term_text}」类问题集中在高峰期和偏远区域。"
                f"建议采用「核心区高密度覆盖+外围区集拼配送」的分层策略。"
            ),
            "应急|紧急|加急|临时|客服|电话不接|联系不上|没人管|处理慢|不回复|推卸": (
                f"根因分析：大多数小型配送公司没有专职客服，出了问题由司机自行处理。"
                f"关键词「{term_text}」指向应急响应能力的缺失——"
                f"对于医药配送（夜间急送）和餐饮配送（午市延误），应急能力直接决定客户是否续约。"
                f"建议建立24小时值班机制+恶劣天气应急预案。"
            ),
            "车辆|面包车|厢货|货车|冷藏车|车型|装不下|太小|进不去|限高|限行": (
                f"根因分析：不同配送场景对车型的要求完全不同——"
                f"餐饮配送适合面包车（灵活进商圈），生鲜冷链必须冷藏车，家具配送需要带升降尾板的厢货。"
                f"大连老城区（西岗区香炉礁限高3.5m、中山区部分路段限行）对车型有额外限制。"
                f"「{term_text}」类问题反映车型与场景不匹配。"
            ),
            "司机|接单|放鸽子|服务|态度|签收|交接": (
                f"根因分析：配送司机的专业度和稳定性直接影响服务体验。"
                f"「{term_text}」反映司机管理体系的薄弱——"
                f"司机流动性大、培训不足、缺乏服务标准是行业普遍问题。"
                f"建议建立司机分级激励体系，将服务态度纳入考核和薪酬。"
            ),
            "售后|退换|退款|保修|理赔|赔偿|投诉|差评": (
                f"根因分析：配送服务商在售后环节投入严重不足。"
                f"「{term_text}」表明当前售后体验与用户预期差距明显。"
                f"建立「先赔后查」的48小时快速理赔通道是一个低成本高感知的差异化点——"
                f"商家更愿意为「出了事有人管」的配送服务支付溢价。"
            ),
        }

        for pattern, analysis in cause_patterns.items():
            for p in pattern.split("|"):
                if p in cat or any(p in t for t in terms):
                    return analysis

        # 无匹配时基于 terms 构造通用分析
        return (
            f"根因分析：从聚类关键词「{term_text}」来看，"
            f"该痛点与{keyword}场景下的配送服务专业化程度不足相关。"
            f"当前市场上缺乏针对该痛点的系统性解决方案，"
            f"商家多依赖通用配送服务商，无法满足行业特定需求。"
            f"这为物流企业提供了差异化切入的机会——"
            f"将「{term_text}」作为核心服务能力建设方向。"
        )

    def _build_pain_action(self, cat: str, keyword: str, terms: list[str]) -> str:
        """基于话题词动态构造行动建议"""
        action_patterns = {
            "配送|时效|晚|慢|迟到|延误|准时|迟到": (
                "建议建立「时间窗口承诺+超时赔付」的差异化服务体系，"
                "将履约准时率作为核心KPI，用时间确定性建立竞争壁垒。"
            ),
            "冷链|温控|冷藏|冷冻|温度|冰袋|化冻|变质|保温|制冷": (
                "建议配置带GPS+温度传感器的冷藏车，提供可追溯的温度记录报告，"
                "将合规能力转化为竞争壁垒，建立「全程不断链」的品牌承诺。"
            ),
            "上楼|搬运|电梯|楼梯|楼层|上楼费|搬运费|搬货": (
                "建议建立透明的上楼费价目表（按楼层/重量），将搬运纳入标准服务，"
                "配备带升降尾板的厢货和2人搬运组，从「配送」升级为「配送+搬运」。"
            ),
            "价格|贵|费用|收费|加价|涨价|起步价|隐性|报价|乱收费": (
                "建议推行一口价模式（起步价+公里费+附加费明示），"
                "下单时明确所有费用项，将价格透明度作为区别于平台的核心卖点。"
            ),
            "破损|损坏|坏|压坏|磕碰|摔坏|洒|漏|碎|包装|货损": (
                "建议按品类定制包装方案（缠绕膜+护角+毛毯+防震），"
                "制定装卸SOP标准化流程，将破损率控制在1%以内。"
            ),
            "运力|覆盖|不配送|不送货|区域|偏远|爆仓|不接单": (
                "建议采用「核心区高密度覆盖+外围区集拼配送」的分层策略，"
                "先在中山/沙河口/甘井子建立服务密度，再向外围扩展。"
            ),
            "应急|紧急|加急|客服|电话不接|联系不上|没人管|不回复": (
                "建议建立24小时值班机制+恶劣天气应急预案，"
                "用「关键时刻找得到人」建立信任壁垒。"
            ),
            "车辆|面包车|厢货|车型|装不下|太小|进不去|限高": (
                "建议建立多车型混合车队，根据订单类型和配送区域智能匹配车型，"
                "覆盖面包车、冷藏车、带尾板厢货等不同配置。"
            ),
            "司机|接单|放鸽子|服务|态度|签收|交接": (
                "建议建立司机分级激励体系，将准时率、好评率、留存率纳入考核，"
                "通过培训和标准化SOP降低司机流失率。"
            ),
            "售后|退换|退款|保修|理赔|赔偿|投诉|差评": (
                "建议建立「先赔后查」48小时快速理赔通道，"
                "用售后体验形成口碑传播，将NPS作为核心运营指标。"
            ),
        }

        for pattern, action in action_patterns.items():
            for p in pattern.split("|"):
                if p in cat or any(p in t for t in terms):
                    return action

        return f"建议围绕「{'、'.join(terms[:2]) if terms else cat}」维度设计差异化服务方案，建立{keyword}场景下的专业配送能力。"

    def _generate_action_plan(self, keyword: str, top_opps: list[dict],
                              companies: list[dict] = None, profile: dict = None) -> str:
        if not top_opps:
            return "暂无足够数据生成行动建议。"

        top_cat = top_opps[0]["category"]
        top_gap = top_opps[0]["satisfaction_gap"]
        scenario = profile.get("scenario", "通用") if profile else "通用"

        company_refs = ""
        if companies:
            names = [c["name"] for c in companies[:3]]
            company_refs = f"优先接触{'、'.join(names)}等{len(companies)}家搜索发现的相关企业，了解其配送现状和痛点。\n"

        # 区域策略
        district_strategy = profile.get("district_strategy", "") if profile else ""

        # 车型建议
        vehicle_text = ""
        if profile and profile.get("suitable_vehicles"):
            vehicles = profile["suitable_vehicles"]
            vehicle_text = f"建议配备{'、'.join(vehicles[:2])}等适配{scenario}场景的车型。"

        # 合规建议
        reg_text = ""
        if profile and profile.get("regulations"):
            regs = profile["regulations"]
            reg_text = f"同步办理{'、'.join(regs[:2])}，确保合规资质齐全。"

        parts = [
            f"一、近期行动（0-1个月）：试点验证\n"
            f"【快速赢单】本周即可行动：筛选5家「{keyword}」商户，带着差异化的{top_cat}解决方案上门拜访，"
            f"提供「首月半价试用」降低决策门槛，目标是签下至少1家标杆客户。\n\n"
            f"在大连核心区域选择5-10家「{keyword}」相关商户作为试点。"
            f"{company_refs}"
            f"针对排名第一的痛点「{top_cat}」（满足度缺口{top_gap:.1f}分），"
            f"设计差异化服务方案，用极致服务建立口碑。{vehicle_text}\n"
            f"{district_strategy}\n\n"
            f"二、中期行动（1-3个月）：系统建设\n"
            f"根据试点反馈优化服务流程和定价策略。核心建设包括：智能调度系统、"
            f"实时追踪平台、标准化操作SOP。{reg_text}"
            f"目标将履约率稳定在95%以上，客户满意度提升至4.5分（5分制）。"
            f"同时建立「{keyword}」场景的专属配送方案，从通用配送升级为{scenario}行业定制化配送。\n\n"
            f"三、长期行动（3-6个月）：规模化\n"
            f"在试点成功后向大连全域复制推广。搭建行业配送平台，"
            f"整合「{keyword}」产业链上下游的配送需求，实现从供应商到终端的一站式物流解决方案。"
            f"建立季节性运力预案（大连冬季暴雪、旅游旺季、樱桃季等），"
            f"将季节波动从「风险」转化为「壁垒」——旺季能保证配送的才是好服务商。\n\n"
            f"四、风险提示\n"
            f"主要风险：通用物流平台（货拉拉/快狗/美团跑腿）的价格竞争、"
            f"司机招聘和留存难度、季节性需求波动、合规成本（{scenario}场景的资质要求）。"
            f"应对策略：不与平台比价格，比行业专业度和服务稳定性；"
            f"建立司机分级激励体系降低流失率；与商家签订长期合同锁定基础订单量；"
            f"将合规作为竞争壁垒而非成本负担。"
        ]

        return "".join(parts)

    # ========== 模拟数据生成（场景化模板） ==========

    def _collect_negative_reviews(self, analyzed_reviews: list[dict]) -> list[dict]:
        """收集所有负面评论，按痛感排序，供前端评论墙展示"""
        negative = [r for r in analyzed_reviews if r.get("is_negative")]
        negative.sort(key=lambda r: r.get("pain_score", 0), reverse=True)
        return [
            {
                "content": r.get("content", ""),
                "sentiment": r.get("sentiment", 0),
                "pain_score": r.get("pain_score", 0),
                "keywords": r.get("keywords", []),
                "rating": r.get("rating"),
                "source": r.get("source", ""),
            }
            for r in negative[:100]  # 最多返回100条，避免响应过大
        ]

    def generate_demo_reviews(self, keyword: str, companies: list[dict] = None) -> list[dict]:
        """动态生成模拟评论 — 每个场景使用专属模板"""
        company_names = [c["name"] for c in companies[:10]] if companies else [f"大连{keyword}商家"]
        scenario = match_scenario(keyword)

        # 选择模板集
        templates = self.SCENARIO_TEMPLATES.get(scenario, self.DEFAULT_TEMPLATES)

        rng = random.Random(hash(keyword) % 2**32)

        total = 80 + rng.randint(0, 220)
        neg_rate = 0.25 + rng.random() * 0.40  # 25-65% negative, ensures enough for clustering

        pos_count = int(total * (0.5 - rng.random() * 0.2))
        neg_count = int(total * neg_rate)
        neutral_count = total - pos_count - neg_count
        if neutral_count < 0:
            neutral_count = 10
            pos_count = total - neg_count - neutral_count

        pos_templates = templates.get("pos", self.DEFAULT_TEMPLATES["pos"])
        neg_templates = templates.get("neg", self.DEFAULT_TEMPLATES["neg"])
        neutral_templates = templates.get("neutral", self.DEFAULT_TEMPLATES["neutral"])

        reviews = []
        for _ in range(pos_count):
            company = rng.choice(company_names)
            content = rng.choice(pos_templates).format(company=company)
            reviews.append({
                "source": f"demo - {keyword}",
                "content": content + rng.choice(["", "。满意", "，推荐给同行"]),
                "rating": rng.uniform(4, 5),
            })
        for _ in range(neg_count):
            company = rng.choice(company_names)
            content = rng.choice(neg_templates).format(company=company)
            reviews.append({
                "source": f"demo - {keyword}",
                "content": content + rng.choice(["", "。太失望了", "，考虑换供应商"]),
                "rating": rng.uniform(1, 2.5),
            })
        for _ in range(neutral_count):
            company = rng.choice(company_names)
            content = rng.choice(neutral_templates).format(company=company)
            reviews.append({
                "source": f"demo - {keyword}",
                "content": content,
                "rating": rng.uniform(2.5, 3.5),
            })

        rng.shuffle(reviews)
        return reviews
