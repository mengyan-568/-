"""
NLP 情感分析和痛点提取模块 v3
v3: sklearn 无监督聚类替换硬编码分类 + 数据驱动洞察生成
"""
import re
from collections import Counter, defaultdict
from typing import Optional

import jieba
import jieba.analyse
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from snownlp import SnowNLP


class NLPAnalyzer:
    """中文评论 NLP 分析器"""

    # 否定词模式
    NEGATIVE_PATTERNS = [
        "不好", "太差", "垃圾", "坑", "骗", "烂", "差劲", "失望",
        "不行", "没用", "卡顿", "崩溃", "闪退", "慢", "发热", "耗电",
        "死机", "售后差", "客服不理", "退货", "退款", "投诉", "质量差",
        "破损", "坏了", "过期", "假货", "上当", "不值", "贵了",
        "难用", "复杂", "麻烦", "没人管", "不理人", "推卸", "敷衍",
        "不发货", "虚假", "刷单", "水军", "忽悠", "套路",
        "不送货", "送得慢", "快递慢", "不包邮", "运费贵", "丢件",
        "包装烂", "暴力分拣", "压坏了", "磕碰", "不配送", "超时",
        "服务态度差", "不专业", "不及时", "信息不更新", "查不到",
        "冷链断链", "温度不达标", "化冻", "变质了", "冷藏失效",
        "温度记录空白", "冰袋化了", "保温箱破了", "没放冰袋",
        "冷链车没开制冷", "不冰了", "解冻了", "温度不够低",
        "午市延误", "晚市赶不上", "预约不准时",
        "等了三个小时", "说好上午到", "晚高峰堵车", "不守时",
        "迟到了", "误了饭点", "开业还没到", "催了好几遍",
        "上楼费", "搬运费太贵", "没电梯", "老小区", "不帮搬",
        "只送到楼下", "要加钱才搬", "搬上楼摔了", "爬楼梯",
        "自己扛上去", "拒搬", "不卸货",
        "面包车太小", "厢货进不去", "限行", "限高", "禁区",
        "不让进", "小区不让货车进", "地下车库限高", "进不了地库",
        "车进不来", "路太窄",
        "暴雪停运", "雨天不送", "台风停运", "樱桃季爆仓",
        "旅游旺季涨价", "冬天不接单", "下雪就不送", "雨季延误",
        "旺季没人送",
        "起步价贵", "公里费高", "等候费不合理", "临时加价",
        "隐性收费", "报价和结算不一样", "押金不退", "乱收费",
        "比别家贵", "坐地起价",
        "司机放鸽子", "接单不来", "中途加价", "货物丢失",
        "送错门店", "交接不清", "没有签收单", "拼货耽误时间",
        "司机态度恶劣", "电话打不通", "不接电话",
    ]

    # 场景感知权重（保留，用于商机排序阶段）
    KEYWORD_CATEGORY_WEIGHTS = {
        "餐饮配送": {
            "配送时效": 2.0, "温控能力": 1.3, "运力覆盖": 1.5,
            "上楼搬运": 0.5, "货物完好": 1.2, "价格透明度": 1.0,
            "应急响应": 1.0, "信息透明": 0.8, "履约稳定": 1.5,
            "售后服务": 0.8, "车辆适配": 0.5,
        },
        "生鲜冷链": {
            "配送时效": 1.5, "温控能力": 2.5, "运力覆盖": 1.0,
            "上楼搬运": 0.5, "货物完好": 2.0, "价格透明度": 1.0,
            "应急响应": 1.5, "信息透明": 0.8, "履约稳定": 1.2,
            "售后服务": 0.8, "车辆适配": 1.5,
        },
        "医药配送": {
            "配送时效": 1.5, "温控能力": 2.0, "运力覆盖": 1.0,
            "上楼搬运": 0.5, "货物完好": 1.5, "价格透明度": 1.0,
            "应急响应": 2.0, "信息透明": 1.2, "履约稳定": 1.5,
            "售后服务": 1.0, "车辆适配": 0.8,
        },
        "家具配送": {
            "配送时效": 1.0, "温控能力": 0.3, "运力覆盖": 1.0,
            "上楼搬运": 2.5, "货物完好": 1.5, "价格透明度": 1.2,
            "应急响应": 0.8, "信息透明": 0.8, "履约稳定": 1.0,
            "售后服务": 1.0, "车辆适配": 2.0,
        },
        "商超补货": {
            "配送时效": 1.5, "温控能力": 1.2, "运力覆盖": 1.5,
            "上楼搬运": 1.0, "货物完好": 1.0, "价格透明度": 1.2,
            "应急响应": 1.0, "信息透明": 1.0, "履约稳定": 1.5,
            "售后服务": 0.8, "车辆适配": 1.0,
        },
    }

    def __init__(self):
        for w in self.NEGATIVE_PATTERNS:
            jieba.add_word(w)

    def get_category_weight(self, category: str, keyword: str) -> float:
        if not keyword:
            return 1.0
        for scenario, weights in self.KEYWORD_CATEGORY_WEIGHTS.items():
            if scenario in keyword:
                return weights.get(category, 1.0)
        return 1.0

    def analyze_reviews(self, reviews: list[dict], keyword: str = "") -> list[dict]:
        results = []
        for review in reviews:
            analyzed = self._analyze_single(review)
            results.append(analyzed)
        return results

    def _analyze_single(self, review: dict) -> dict:
        content = review.get("content", "")
        rating = review.get("rating")

        sentiment_score = self._sentiment_analysis(content, rating)
        is_negative = sentiment_score < 0.35

        keywords = jieba.analyse.extract_tags(content, topK=10, withWeight=True)
        keyword_list = [kw for kw, weight in keywords if weight > 0.5]

        pain_score = self._calculate_pain_score(content, sentiment_score)

        return {
            **review,
            "sentiment": round(sentiment_score, 3),
            "is_negative": is_negative,
            "keywords": keyword_list,
            "pain_score": round(pain_score, 3),
        }

    def _sentiment_analysis(self, text: str, rating: Optional[float]) -> float:
        if not text or len(text) < 2:
            return 0.5

        try:
            s = SnowNLP(text)
            ml_score = s.sentiments
        except Exception:
            ml_score = 0.5

        rule_score = 1.0
        neg_count = sum(1 for pattern in self.NEGATIVE_PATTERNS if pattern in text)
        if neg_count > 0:
            rule_score = max(0.1, 1.0 - neg_count * 0.3)

        if rating is not None:
            normalized_rating = rating / 5.0
            score = ml_score * 0.3 + rule_score * 0.2 + normalized_rating * 0.5
        else:
            score = ml_score * 0.5 + rule_score * 0.5

        return max(0.0, min(1.0, score))

    def _calculate_pain_score(self, text: str, sentiment: float) -> float:
        neg_factor = max(0, (0.4 - sentiment)) / 0.4
        len_factor = min(1.0, len(text) / 100)
        excl_factor = min(1.0, (text.count("!") + text.count("！") + text.count("?") + text.count("？")) / 5)
        score = neg_factor * 0.6 + len_factor * 0.2 + excl_factor * 0.2
        return max(0.0, min(1.0, score))


class PainClusterer:
    """v3: 无监督话题发现 — TF-IDF + SVD + KMeans，不预设分类"""

    def __init__(self, n_topics: int = None, random_state: int = 42):
        self.n_topics = n_topics
        self.random_state = random_state

    # Domain-specific stop words to filter from topic labels
    _STOP_WORDS = {
        "一天", "一个", "一种", "一次", "一下", "一些", "一定", "一样",
        "这家", "那家", "这个", "那个", "这些", "那些", "什么", "怎么",
        "为什么", "因为", "所以", "但是", "虽然", "如果", "可以", "应该",
        "已经", "没有", "还是", "不是", "就是", "都是", "只是", "还有",
        "可能", "比较", "非常", "特别", "真的", "确实", "一直", "总是",
        "公司", "商家", "他们", "我们", "你们", "自己", "知道", "觉得",
        "感觉", "发现", "问题", "情况", "时候", "方面", "的话", "之后",
        "之前", "以后", "然后", "最后", "全部", "所有", "很多", "很少",
        "来说", "来说话", "不到", "不到一", "能不能", "要不要",
    }

    def cluster(self, reviews: list[dict]) -> dict:
        negative_reviews = [r for r in reviews if r.get("is_negative")]

        if len(negative_reviews) < 10:
            return self._fallback_cluster(reviews, negative_reviews)

        texts = [r.get("content", "") for r in negative_reviews]

        # Step 1: TF-IDF vectorization
        vectorizer = TfidfVectorizer(
            max_features=1500,
            ngram_range=(1, 2),
            tokenizer=self._jieba_tokenize,
            min_df=2,
            max_df=0.8,
        )
        try:
            tfidf_matrix = vectorizer.fit_transform(texts)
        except ValueError:
            return self._fallback_cluster(reviews, negative_reviews)

        feature_names = vectorizer.get_feature_names_out()

        # Step 2: Dimensionality reduction
        n_components = min(50, tfidf_matrix.shape[1] - 1, tfidf_matrix.shape[0] - 1)
        if n_components < 2:
            return self._fallback_cluster(reviews, negative_reviews)

        svd = TruncatedSVD(n_components=n_components, random_state=self.random_state)
        reduced = svd.fit_transform(tfidf_matrix)

        # Step 3: Auto-select k
        k = self._auto_select_k(reduced, max_k=min(8, len(negative_reviews) // 5 + 2))

        # Step 4: KMeans clustering
        kmeans = KMeans(n_clusters=k, random_state=self.random_state, n_init=10)
        labels = kmeans.fit_predict(reduced)

        # Step 5: Build category stats from clusters
        categories = {}
        for cluster_id in range(k):
            mask = labels == cluster_id
            cluster_reviews = [negative_reviews[i] for i, m in enumerate(mask) if m]
            cluster_texts = [texts[i] for i, m in enumerate(mask) if m]

            if not cluster_reviews:
                continue

            # Extract topic keywords using jieba TF-IDF on the cluster
            topic_text = " ".join(cluster_texts)
            cluster_keywords = jieba.analyse.extract_tags(topic_text, topK=10, withWeight=True)
            top_terms = [kw for kw, weight in cluster_keywords
                        if len(kw) >= 2 and kw not in self._STOP_WORDS][:5]

            # Generate topic label
            topic_label = self._generate_topic_label(top_terms, cluster_texts)

            # Collect stats
            examples = []
            total_pain = 0.0
            for r in cluster_reviews:
                total_pain += r.get("pain_score", 0)
                if len(examples) < 3:
                    examples.append(r["content"][:120])

            categories[topic_label] = {
                "count": len(cluster_reviews),
                "frequency": round(len(cluster_reviews) / len(negative_reviews), 3),
                "avg_pain_score": round(total_pain / len(cluster_reviews), 3),
                "examples": examples,
                "top_terms": top_terms,
            }

        # Step 6: Global keyword extraction
        all_text = " ".join(texts)
        keyword_counter = Counter()
        for r in negative_reviews:
            for kw in r.get("keywords", []):
                keyword_counter[kw] += 1

        return {
            "categories": categories,
            "top_keywords": [{"word": w, "count": c} for w, c in keyword_counter.most_common(30)],
            "total_negative": len(negative_reviews),
            "total_reviews": len(reviews),
            "negativity_rate": round(len(negative_reviews) / len(reviews), 3) if reviews else 0,
        }

    def _jieba_tokenize(self, text: str) -> list[str]:
        words = jieba.cut(text)
        # Keep only meaningful words >= 2 chars with Chinese characters
        tokens = []
        for w in words:
            w = w.strip()
            if len(w) >= 2 and re.search(r'[一-鿿]', w) and w not in self._STOP_WORDS:
                tokens.append(w)
        if not tokens:
            return [text[:4]]
        return tokens

    def _jieba_joined(self, text: str) -> str:
        """Return space-joined jieba tokens for TF-IDF"""
        return " ".join(self._jieba_tokenize(text))

    def _auto_select_k(self, reduced_matrix, max_k: int = 8) -> int:
        if self.n_topics is not None:
            return self.n_topics

        n_samples = reduced_matrix.shape[0]
        # Ensure at least 3 topics when there are enough samples, to force differentiation
        min_k = min(3, max(2, n_samples // 4))
        if n_samples < 6:
            return max(2, n_samples // 2)
        if n_samples < 12:
            return min_k

        best_k = min_k
        best_score = -1
        for k in range(min_k, min(max_k + 1, n_samples)):
            kmeans = KMeans(n_clusters=k, random_state=self.random_state, n_init=10)
            labels = kmeans.fit_predict(reduced_matrix)
            if len(set(labels)) < 2:
                continue
            try:
                score = silhouette_score(reduced_matrix, labels)
                if score > best_score:
                    best_score = score
                    best_k = k
            except Exception:
                pass

        return best_k

    def _generate_topic_label(self, top_terms: list[str], texts: list[str]) -> str:
        """从 top terms 生成有意义的主题标签"""
        if not top_terms:
            return "其他问题"

        # Filter to meaningful Chinese terms, exclude stop words
        chinese_terms = [t for t in top_terms
                        if re.search(r'[一-鿿]', t)
                        and 2 <= len(t) <= 6
                        and t not in self._STOP_WORDS]
        if not chinese_terms:
            chinese_terms = [t for t in top_terms if t not in self._STOP_WORDS]
        if not chinese_terms:
            chinese_terms = top_terms

        return chinese_terms[0]

    def _fallback_cluster(self, reviews: list[dict], negative_reviews: list[dict]) -> dict:
        """评论太少时退化为简单的关键词统计"""
        keyword_counter = Counter()
        examples = []
        total_pain = 0.0
        for r in negative_reviews:
            total_pain += r.get("pain_score", 0)
            for kw in r.get("keywords", []):
                keyword_counter[kw] += 1
            if len(examples) < 5:
                examples.append(r["content"][:120])

        categories = {}
        if negative_reviews:
            avg_pain = total_pain / len(negative_reviews)
            categories["用户反馈问题"] = {
                "count": len(negative_reviews),
                "frequency": 1.0,
                "avg_pain_score": round(avg_pain, 3),
                "examples": examples[:3],
                "top_terms": [w for w, _ in keyword_counter.most_common(5)],
            }

        return {
            "categories": categories,
            "top_keywords": [{"word": w, "count": c} for w, c in keyword_counter.most_common(20)],
            "total_negative": len(negative_reviews),
            "total_reviews": len(reviews),
            "negativity_rate": round(len(negative_reviews) / len(reviews), 3) if reviews else 0,
        }
