"""
商机挖掘 API — 数据抓取 → DeepSeek AI 分析 → 商机输出

端点:
  POST /api/mining/mine  — 完整商机挖掘流程
  GET  /api/mining/status — 检查 DeepSeek 可用状态
"""
import json
import logging
from datetime import datetime

from fastapi import APIRouter, Query
from pydantic import BaseModel

from mining_engine import OpportunityMiningEngine, mine_opportunities

logger = logging.getLogger("mining_api")

router = APIRouter(prefix="/api/mining", tags=["商机挖掘"])


class MiningRequest(BaseModel):
    keyword: str = "餐饮配送"
    city: str = "大连"
    use_deepseek: bool = True


@router.get("/status")
def mining_status():
    """检查 DeepSeek 和爬虫可用状态"""
    import os
    deepseek_key = bool(os.environ.get("DEEPSEEK_API_KEY", ""))

    return {
        "checked_at": datetime.now().isoformat(),
        "deepseek_available": deepseek_key,
        "deepseek_model": os.environ.get("DEEPSEEK_MODEL", "deepseek-chat"),
        "crawler_available": True,
        "note": "设置 DEEPSEEK_API_KEY 环境变量启用 DeepSeek AI 分析。未设置时使用规则引擎兜底。",
    }


@router.post("/mine")
def run_mining(req: MiningRequest):
    """
    执行完整商机挖掘流程:
      1. 实时爬虫抓取公开数据（招标/需求/竞品/路线/季节）
      2. 结合知识库和产物数据构建分析上下文
      3. DeepSeek AI 深度分析（6个商机维度）
      4. 输出可落地的商机结论
    """
    logger.info("商机挖掘 API 调用: keyword=%s, deepseek=%s", req.keyword, req.use_deepseek)
    result = mine_opportunities(
        city=req.city,
        keyword=req.keyword,
        use_deepseek=req.use_deepseek,
    )
    return result


@router.get("/mine/quick")
def quick_mine(
    keyword: str = Query("餐饮配送"),
    city: str = "大连"
):
    """快速商机挖掘（跳过爬虫，使用规则引擎）"""
    result = mine_opportunities(
        city=city,
        keyword=keyword,
        use_deepseek=False,
    )
    return result
