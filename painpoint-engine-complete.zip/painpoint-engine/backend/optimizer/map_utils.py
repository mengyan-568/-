"""
地图工具 — Haversine 距离矩阵 + OSRM 路网距离（可选）
"""
import math
import random
from typing import Optional


def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Haversine 直线距离 (km)"""
    R = 6371
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = (math.sin(dlat / 2) ** 2 +
         math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) *
         math.sin(dlon / 2) ** 2)
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def road_distance_km(lat1: float, lon1: float, lat2: float, lon2: float,
                     osrm_url: Optional[str] = None) -> float:
    """
    计算路网距离。如果配置了 OSRM，走 OSRM；否则用 Haversine × 1.4 估算城市道路。
    """
    if osrm_url:
        try:
            import urllib.request
            import json
            url = (f"{osrm_url}/route/v1/driving/{lon1},{lat1};{lon2},{lat2}"
                   f"?overview=false")
            req = urllib.request.Request(url, headers={"User-Agent": "painpoint-engine/1.0"})
            with urllib.request.urlopen(req, timeout=5) as resp:
                data = json.loads(resp.read())
                if data.get("code") == "Ok":
                    return data["routes"][0]["distance"] / 1000.0
        except Exception:
            pass

    # Fallback: 大连城市道路系数（非直线系数约 1.3-1.5）
    road_factor = random.uniform(1.30, 1.50)
    return haversine_km(lat1, lon1, lat2, lon2) * road_factor


def build_distance_matrix(locations: list[dict],
                          osrm_url: Optional[str] = None) -> list[list[float]]:
    """
    构建距离矩阵 (km)，索引 0 为 depot。

    locations: [{"lat": ..., "lon": ..., "name": ...}, ...]
    返回: n×n 矩阵，matrix[i][j] = i→j 的路网距离
    """
    n = len(locations)
    matrix = [[0.0] * n for _ in range(n)]

    rng = random.Random(42)  # 固定种子保证可复现
    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            d = road_distance_km(
                locations[i]["lat"], locations[i]["lon"],
                locations[j]["lat"], locations[j]["lon"],
                osrm_url=osrm_url
            )
            matrix[i][j] = round(d, 3)

    return matrix


def estimate_travel_time_minutes(dist_km: float, avg_speed_kmh: float = 35.0) -> float:
    """估算行驶时间（分钟）"""
    return (dist_km / avg_speed_kmh) * 60.0
