"""
路径优化引擎 — OR-Tools CVRP/VRPTW 路由规划

基于 Google OR-Tools 求解带容量约束和时间窗的车辆路径问题 (VRPTW)。
输入: depot + 配送点列表 + 车辆配置
输出: 每辆车的最优路线、总里程、总时长
"""
import uuid
from typing import Optional

from ortools.constraint_solver import routing_enums_pb2, pywrapcp

from .map_utils import (
    haversine_km,
    build_distance_matrix,
    estimate_travel_time_minutes,
)


class RouteOptimizer:
    """路径优化器（单例）"""

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True
        self._osrm_url = None  # 可选: "http://router.project-osrm.org"

    def optimize(self, request: dict) -> dict:
        """
        主入口 — 给定配送任务，返回最优路线。

        request = {
            "depot": {"lat": 38.9522, "lon": 121.5500, "name": "甘井子仓储中心"},
            "stops": [
                {"lat": 38.9150, "lon": 121.6400, "name": "喜家德中山店",
                 "demand_kg": 200, "time_window_min": [480, 660],  # 08:00-11:00
                 "service_minutes": 15},
                ...
            ],
            "vehicles": [
                {"id": "v1", "plate": "辽B·12345", "capacity_kg": 1000,
                 "cost_per_km": 3.5, "fixed_cost": 30},
                ...
            ],
            "strategy": "min_distance",  # "min_distance" | "min_vehicles" | "balanced"
            "max_solution_seconds": 5,
        }

        返回:
        {
            "routes": [
                {
                    "vehicle_id": "v1", "plate": "辽B·12345",
                    "stops": [{"lat": ..., "lon": ..., "name": ..., "arrive_min": 495, ...}],
                    "total_km": 45.3, "total_minutes": 95, "load_kg": 850,
                    "cost": 188.55,
                },
                ...
            ],
            "unassigned": [...],  # 无法分配的点
            "summary": {"total_km": ..., "total_cost": ..., "vehicles_used": ...},
            "solver_status": "OPTIMAL" | "FEASIBLE" | "INFEASIBLE",
        }
        """
        depot = request["depot"]
        stops = request["stops"]
        vehicles = request.get("vehicles", [])
        strategy = request.get("strategy", "min_distance")
        max_seconds = request.get("max_solution_seconds", 5)

        if not stops:
            return self._empty_result("无配送点")

        if not vehicles:
            vehicles = [self._default_vehicle()]

        # 构建位置列表: [depot, stop1, stop2, ...]
        locations = [depot] + stops
        n = len(locations)

        # 构建距离矩阵
        dist_matrix = build_distance_matrix(locations, osrm_url=self._osrm_url)

        # 构建时间矩阵 (分钟)
        time_matrix = [[estimate_travel_time_minutes(d) for d in row]
                       for row in dist_matrix]

        # 创建路由模型
        manager = pywrapcp.RoutingIndexManager(n, len(vehicles), 0)  # 0 = depot index
        routing = pywrapcp.RoutingModel(manager)

        # 距离回调
        def distance_callback(from_idx, to_idx):
            from_node = manager.IndexToNode(from_idx)
            to_node = manager.IndexToNode(to_idx)
            return int(dist_matrix[from_node][to_node] * 1000)  # 转换为米

        dist_cb_idx = routing.RegisterTransitCallback(distance_callback)
        routing.SetArcCostEvaluatorOfAllVehicles(dist_cb_idx)

        # 添加距离维度（用于累积距离）
        routing.AddDimension(
            dist_cb_idx,
            0,      # slack
            500000, # max distance per vehicle (500km)
            True,   # start cumul at zero
            "Distance"
        )
        distance_dim = routing.GetDimensionOrDie("Distance")

        # 容量约束
        if any(s.get("demand_kg", 0) > 0 for s in stops):
            def demand_callback(from_idx):
                from_node = manager.IndexToNode(from_idx)
                return int(stops[from_node - 1].get("demand_kg", 0)) if from_node > 0 else 0

            demand_cb_idx = routing.RegisterUnaryTransitCallback(demand_callback)
            routing.AddDimensionWithVehicleCapacity(
                demand_cb_idx, 0,
                [v.get("capacity_kg", 1000) for v in vehicles],
                True, "Capacity"
            )

        # 时间窗约束
        has_time_windows = any(s.get("time_window_min") is not None for s in stops)
        if has_time_windows:
            def time_callback(from_idx, to_idx):
                from_node = manager.IndexToNode(from_idx)
                to_node = manager.IndexToNode(to_idx)
                travel_min = int(time_matrix[from_node][to_node])
                # 加上停留时间
                if from_node > 0:
                    travel_min += int(stops[from_node - 1].get("service_minutes", 10))
                return travel_min

            time_cb_idx = routing.RegisterTransitCallback(time_callback)

            # 时间窗: depot 从 0 分钟开始，最大 1440 分钟 (24h)
            horizon = 1440
            routing.AddDimension(time_cb_idx, 60, horizon, False, "Time")
            time_dimension = routing.GetDimensionOrDie("Time")

            # 为每个点设置时间窗
            for i in range(n):
                idx = manager.NodeToIndex(i)
                if i == 0:
                    time_dimension.CumulVar(idx).SetRange(0, horizon)
                else:
                    tw = stops[i - 1].get("time_window_min", [0, horizon])
                    tw_max = stops[i - 1].get("time_window_min", None)
                    if tw_max:
                        if isinstance(tw_max, list):
                            time_dimension.CumulVar(idx).SetRange(tw_max[0], tw_max[1])
                        else:
                            time_dimension.CumulVar(idx).SetRange(0, horizon)
                    else:
                        time_dimension.CumulVar(idx).SetRange(0, horizon)

            # Time dimension handles time window feasibility; distance cost
            # is already minimized via SetArcCostEvaluatorOfAllVehicles

        # 搜索参数
        search_params = pywrapcp.DefaultRoutingSearchParameters()
        search_params.time_limit.seconds = max_seconds

        if strategy == "min_vehicles":
            search_params.first_solution_strategy = (
                routing_enums_pb2.FirstSolutionStrategy.PATH_CHEAPEST_ARC
            )
        else:
            search_params.first_solution_strategy = (
                routing_enums_pb2.FirstSolutionStrategy.AUTOMATIC
            )
        search_params.local_search_metaheuristic = (
            routing_enums_pb2.LocalSearchMetaheuristic.GUIDED_LOCAL_SEARCH
        )

        # 求解
        solution = routing.SolveWithParameters(search_params)

        if not solution:
            return self._empty_result("无法找到可行解", "INFEASIBLE")

        # 解析结果
        routes = []
        total_km = 0.0
        total_cost = 0.0
        unassigned = []

        for v_idx, vehicle in enumerate(vehicles):
            idx = routing.Start(v_idx)
            if routing.IsEnd(solution.Value(routing.NextVar(idx))):
                continue  # 此车未使用

            route_stops = []
            route_dist_m = 0
            prev_node = 0

            while not routing.IsEnd(idx):
                node = manager.IndexToNode(idx)
                cumul_dist = solution.Value(distance_dim.CumulVar(idx))

                if node == 0:
                    # Depot
                    route_stops.append({
                        "type": "depot",
                        "name": depot.get("name", "仓库"),
                        "lat": depot["lat"],
                        "lon": depot["lon"],
                        "arrive_min": 0,
                    })
                else:
                    stop = stops[node - 1]
                    arrive_min = 0
                    if has_time_windows:
                        time_dim = routing.GetDimensionOrDie("Time")
                        arrive_min = solution.Min(time_dim.CumulVar(idx))

                    route_stops.append({
                        "type": "stop",
                        "name": stop.get("name", f"配送点{node}"),
                        "lat": stop["lat"],
                        "lon": stop["lon"],
                        "arrive_min": arrive_min,
                        "demand_kg": stop.get("demand_kg", 0),
                        "service_minutes": stop.get("service_minutes", 10),
                    })

                next_idx = solution.Value(routing.NextVar(idx))
                if not routing.IsEnd(next_idx):
                    next_node = manager.IndexToNode(next_idx)
                    route_dist_m += dist_matrix[node][next_node] * 1000

                idx = next_idx

            # 最后一段: 回 depot
            last_node = manager.IndexToNode(idx) if not routing.IsEnd(idx) else node
            # node is the last actual stop; add return to depot
            # Actually let's compute properly

            route_km = route_dist_m / 1000.0
            # 补上最后一段回 depot
            if route_stops and route_stops[-1]["type"] == "stop":
                last_stop = route_stops[-1]
                # Find depot
                return_km = haversine_km(last_stop["lat"], last_stop["lon"],
                                         depot["lat"], depot["lon"]) * 1.35
                route_km += return_km

            # 计算总时间
            total_min = 0
            for i in range(len(route_stops)):
                s = route_stops[i]
                if s["type"] == "depot":
                    continue
                # travel time from previous
                if i > 0:
                    prev = route_stops[i - 1]
                    d = haversine_km(prev["lat"], prev["lon"], s["lat"], s["lon"]) * 1.35
                    total_min += estimate_travel_time_minutes(d, avg_speed_kmh=30)
                total_min += s.get("service_minutes", 10)

            # 回 depot
            if route_stops:
                last = route_stops[-1]
                d = haversine_km(last["lat"], last["lon"], depot["lat"], depot["lon"]) * 1.35
                total_min += estimate_travel_time_minutes(d, avg_speed_kmh=30)

            load_kg = sum(s.get("demand_kg", 0) for s in route_stops if s["type"] == "stop")
            cost = (route_km * vehicle.get("cost_per_km", 3.5) +
                    vehicle.get("fixed_cost", 30))

            routes.append({
                "vehicle_id": vehicle.get("id", f"v{v_idx}"),
                "plate": vehicle.get("plate", f"车辆{v_idx+1}"),
                "stops": route_stops,
                "total_km": round(route_km, 2),
                "total_minutes": round(total_min),
                "load_kg": load_kg,
                "load_pct": round(load_kg / vehicle.get("capacity_kg", 1000) * 100, 1),
                "cost": round(cost, 2),
            })
            total_km += route_km
            total_cost += cost

        return {
            "routes": routes,
            "unassigned": unassigned,
            "summary": {
                "total_km": round(total_km, 2),
                "total_cost": round(total_cost, 2),
                "total_minutes": max((r["total_minutes"] for r in routes), default=0),
                "vehicles_used": len(routes),
                "stops_assigned": sum(len(r["stops"]) - 1 for r in routes),  # exclude depot
            },
            "solver_status": "OPTIMAL" if not unassigned else "FEASIBLE",
            "distance_matrix_km": dist_matrix,
        }

    def _default_vehicle(self) -> dict:
        return {
            "id": "default-v1",
            "plate": "辽B·TEST",
            "capacity_kg": 1500,
            "cost_per_km": 4.0,
            "fixed_cost": 40,
        }

    def _empty_result(self, message: str, status: str = "INFEASIBLE") -> dict:
        return {
            "routes": [],
            "unassigned": [],
            "summary": {
                "total_km": 0, "total_cost": 0, "total_minutes": 0,
                "vehicles_used": 0, "stops_assigned": 0,
            },
            "solver_status": status,
            "message": message,
            "distance_matrix_km": [],
        }

    def generate_demo_stops(self, keyword: str = "餐饮配送",
                            n_stops: int = 6) -> list[dict]:
        """根据场景生成演示配送点（大连真实地标）"""
        from tracking.simulator import DALIAN_LANDMARKS

        stops = []
        if "餐饮" in keyword or "商超" in keyword:
            pool = (DALIAN_LANDMARKS["restaurants"] +
                    DALIAN_LANDMARKS["retail"])
        elif "生鲜" in keyword or "冷链" in keyword:
            pool = (DALIAN_LANDMARKS["markets"] +
                    DALIAN_LANDMARKS["restaurants"] +
                    DALIAN_LANDMARKS["retail"])
        elif "医药" in keyword:
            pool = (DALIAN_LANDMARKS["pharmacies"] +
                    DALIAN_LANDMARKS["retail"])
        elif "家具" in keyword:
            pool = (DALIAN_LANDMARKS["furniture"] +
                    DALIAN_LANDMARKS["retail"])
        else:
            pool = (DALIAN_LANDMARKS["restaurants"] +
                    DALIAN_LANDMARKS["retail"])

        import random
        rng = random.Random(hash(keyword) % 2**32)
        selected = rng.sample(pool, min(n_stops, len(pool)))

        for i, s in enumerate(selected):
            tw_start = 480 + rng.randint(0, 120)  # 8:00-10:00
            stops.append({
                "name": s["name"],
                "lat": s["lat"],
                "lon": s["lon"],
                "demand_kg": rng.randint(50, 400),
                "time_window_min": [tw_start, tw_start + 180],
                "service_minutes": rng.randint(10, 30),
            })

        return stops


_optimizer = None  # type: Optional[RouteOptimizer]


def get_optimizer() -> RouteOptimizer:
    global _optimizer
    if _optimizer is None:
        _optimizer = RouteOptimizer()
    return _optimizer
