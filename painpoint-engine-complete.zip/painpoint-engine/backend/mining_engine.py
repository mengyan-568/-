"""
商机挖掘引擎 — 数据抓取 → DeepSeek AI 分析 → 商机输出

核心流程:
  1. 实时爬虫抓取公开数据（招标/需求/竞品/路线/季节）
  2. 结合知识库和产物数据构建分析上下文
  3. DeepSeek AI 深度分析（6个商机维度）
  4. 输出可落地的商机结论
"""
import json
import logging
from datetime import datetime

from collectors.realtime_crawler import RealtimeCrawler
from collectors.products import ProductGenerator
from knowledge.dalian_delivery import (
    DALIAN_DISTRICTS, VEHICLE_TYPES, REGULATORY_MAP,
    SEASONAL_FACTORS, COMPETITIVE_LANDSCAPE,
    match_scenario, get_scenario_profile,
)

logger = logging.getLogger("mining_engine")

MINING_SYSTEM_PROMPT = """你是「洞见 Foresight」平台的资深商机挖掘分析师，专精于中国同城配送和最后一公里物流。

你的核心能力：
1. 基于真实爬虫数据 + 行业知识库，发现可落地的商业机会
2. 从数据中提取具体的、可执行的商机洞察
3. 为物流企业决策者提供数据驱动的行动建议

输出规则：
- 必须严格使用中文
- 语气专业、自信、数据驱动
- 每个结论都要有具体的数据支撑
- 商机必须是可落地的（有具体的区域/行业/客户/利润空间）
- 输出必须是合法的 JSON"""


class OpportunityMiningEngine:
    """商机挖掘引擎"""

    def __init__(self, city: str = "大连", keyword: str = "餐饮配送"):
        self.city = city
        self.keyword = keyword
        self.crawler = RealtimeCrawler(city=city)
        self.gen = ProductGenerator(city=city)
        self.scenario = match_scenario(keyword)
        self.profile = get_scenario_profile(keyword)

    def mine(self, use_deepseek: bool = True) -> dict:
        logger.info("=" * 60)
        logger.info("商机挖掘引擎启动: city=%s, keyword=%s", self.city, self.keyword)
        start_time = datetime.now()

        # Step 1: 实时数据抓取
        logger.info("[Step 1/4] 实时数据抓取...")
        crawled = self.crawler.crawl_all()

        # Step 2: 构建知识上下文
        logger.info("[Step 2/4] 构建分析上下文...")
        context = self._build_context(crawled)

        # Step 3: AI 分析
        logger.info("[Step 3/4] AI 商机分析...")
        if use_deepseek:
            ai_opportunities = self._run_deepseek_analysis(context)
        else:
            ai_opportunities = self._run_rule_based_analysis(context)

        # Step 4: 汇总
        result = {
            "metadata": {
                "city": self.city, "keyword": self.keyword,
                "scenario": self.scenario,
                "mined_at": datetime.now().isoformat(),
                "duration_seconds": round((datetime.now() - start_time).total_seconds(), 1),
                "ai_provider": "DeepSeek" if use_deepseek else "RuleEngine",
            },
            "crawled_data": {
                "bidding_count": len(crawled.get("bidding", {}).get("bids", [])),
                "demand_signals_count": len(crawled.get("demand_signals", {}).get("signals", [])),
                "pricing_entries": len(crawled.get("competitor_pricing", {}).get("pricing_data", [])),
                "route_gaps": len(crawled.get("route_gaps", {}).get("gaps", [])),
                "seasonal_patterns": len(crawled.get("seasonal_patterns", {}).get("patterns", [])),
                "data_quality": "realtime" if crawled.get("success_count", 0) > 0 else "estimated",
            },
            "knowledge_context": context,
            "opportunities": ai_opportunities,
        }

        logger.info("商机挖掘完成! 耗时 %.1f 秒", result["metadata"]["duration_seconds"])
        return result

    def _build_context(self, crawled: dict) -> dict:
        capacity = self.gen.generate_capacity_map()
        demand = self.gen.generate_demand_heatmap()
        benchmark = self.gen.generate_competitive_benchmark()
        opp_list = self.gen.generate_opportunity_list(keyword=self.keyword)

        bidding_summary = []
        for b in crawled.get("bidding", {}).get("bids", [])[:5]:
            bidding_summary.append(f"- {b.get('title', '')}: {b.get('snippet', '')[:100]}")

        demand_summary = []
        for s in crawled.get("demand_signals", {}).get("signals", [])[:5]:
            demand_summary.append(f"- {s.get('title', '')}: {s.get('snippet', '')[:100]}")

        gap_summary = []
        for g in crawled.get("route_gaps", {}).get("gaps", [])[:5]:
            gap_summary.append(f"- {g.get('title', '')}: {g.get('snippet', '')[:100]}")

        providers_info = []
        for p in capacity.get("capacity_providers", [])[:5]:
            vtypes = ", ".join(f"{v['model']}x{v['count']}" for v in p.get("vehicle_types", [])[:2])
            providers_info.append(f"- {p['name']} ({p['type']}): {vtypes}, {p.get('capacity_scale', '')}")

        zones_info = []
        for z in demand.get("demand_zones", [])[:4]:
            zones_info.append(f"- {z['zone']} ({z['demand_intensity']}): {', '.join(z.get('industries', []))}")

        price_info = []
        for v in benchmark.get("vehicle_comparison", [])[:4]:
            hl = v.get("货拉拉", {}).get("起步价", "N/A")
            kg = v.get("快狗打车", {}).get("起步价", "N/A")
            price_info.append(f"- {v['车型']}: 货拉拉 {hl}, 快狗 {kg}")

        target_info = []
        for opp in opp_list.get("opportunities", [])[:5]:
            target_info.append(
                f"- {opp.get('name', '')} ({opp.get('industry', '')}): "
                f"{opp.get('delivery_need', '')}, 紧迫度{opp.get('urgency', '')}, "
                f"年价值{opp.get('estimated_annual_value', '')}"
            )

        seasonal_info = []
        for s in SEASONAL_FACTORS:
            seasonal_info.append(f"- {s['name']}({','.join(str(m) for m in s['months'])}月): {s['impact']}")

        return {
            "city": self.city, "scenario": self.scenario, "keyword": self.keyword,
            "crawled_summary": {
                "bidding": "\n".join(bidding_summary) if bidding_summary else "暂无招标数据",
                "demand_signals": "\n".join(demand_summary) if demand_summary else "暂无需求信号",
                "route_gaps": "\n".join(gap_summary) if gap_summary else "暂无缺口数据",
            },
            "market_data": {
                "providers": "\n".join(providers_info),
                "demand_zones": "\n".join(zones_info),
                "pricing": "\n".join(price_info),
                "target_companies": "\n".join(target_info),
            },
            "industry_knowledge": {
                "seasonal_factors": "\n".join(seasonal_info),
                "competitive_landscape": COMPETITIVE_LANDSCAPE.get("gap_analysis", ""),
                "regulations": REGULATORY_MAP.get(self.scenario, []),
                "suitable_vehicles": self.profile.get("suitable_vehicles", []),
            },
        }

    def _run_deepseek_analysis(self, context: dict) -> dict:
        try:
            from llm.provider import DeepSeekProvider
            provider = DeepSeekProvider()
            if not provider.available():
                logger.info("DeepSeek API Key 未配置，使用规则引擎")
                return self._run_rule_based_analysis(context)
            logger.info("调用 DeepSeek AI 进行商机分析...")
            user_prompt = self._build_mining_prompt(context)
            result = provider.generate(MINING_SYSTEM_PROMPT, user_prompt, timeout=90)
            if result:
                logger.info("DeepSeek AI 分析成功")
                return result
            return self._run_rule_based_analysis(context)
        except Exception as e:
            logger.error(f"DeepSeek 分析异常: {e}")
            return self._run_rule_based_analysis(context)

    def _build_mining_prompt(self, context: dict) -> str:
        market = context["market_data"]
        crawled = context["crawled_summary"]
        knowledge = context["industry_knowledge"]
        return f"""## 任务：大连{context['keyword']}同城配送商机挖掘

### 一、实时爬虫数据

**招标/采购信息：**
{crawled['bidding']}

**企业发货需求信号：**
{crawled['demand_signals']}

**配送缺口/空载热点：**
{crawled['route_gaps']}

### 二、市场数据

**运力供给端：**
{market['providers']}

**需求端（区域分布）：**
{market['demand_zones']}

**竞品价格：**
{market['pricing']}

**目标企业：**
{market['target_companies']}

### 三、行业知识

**季节性因素：**
{knowledge['seasonal_factors']}

**竞争格局：**
{knowledge['competitive_landscape']}

**合规要求：**
{', '.join(knowledge['regulations']) if knowledge['regulations'] else '无特殊要求'}

### 四、分析要求

请基于以上真实数据，从以下6个维度挖掘可落地的商机：

1. **区域运力缺口**：哪些区域缺配送运力？具体到区域名称、缺口车型、缺口时段
2. **行业新增单量**：哪些行业有新增配送需求？增长趋势如何？
3. **高利润线路**：哪些时间段、哪些线路利润最高？给出具体路线和利润估算
4. **潜在客户**：哪些企业是潜在客户？按优先级排序，给出触达策略
5. **市场空白点**：目前市场有哪些未被满足的需求？可切入的机会在哪里？
6. **行动建议**：给出具体的、可执行的下一步行动建议

每个维度至少3条具体发现，每条要有数据支撑。

输出 JSON 格式：
{{
  "regional_gaps": [{{"area": "区域名", "gap_type": "缺口类型", "vehicle_needed": "需要车型", "time_slot": "缺口时段", "estimated_daily_orders": "日均缺口单量", "profit_potential": "利润潜力"}}],
  "industry_growth": [{{"industry": "行业", "growth_trend": "增长趋势", "signal_source": "信号来源", "estimated_new_orders": "预估新增单量", "recommended_action": "建议行动"}}],
  "high_profit_routes": [{{"route": "路线", "vehicle": "推荐车型", "time_slot": "最佳时段", "estimated_profit_per_trip": "单趟利润", "monthly_potential": "月利润潜力"}}],
  "potential_clients": [{{"name": "企业名", "industry": "行业", "priority": "优先级", "need": "配送需求", "estimated_annual_value": "年价值估算", "outreach_strategy": "触达策略"}}],
  "market_gaps": [{{"gap": "市场空白", "current_situation": "现状", "opportunity": "切入机会", "entry_difficulty": "进入难度", "estimated_market_size": "市场规模估算"}}],
  "action_recommendations": [{{"priority": "P0/P1/P2", "action": "具体行动", "timeline": "时间线", "expected_outcome": "预期结果", "resources_needed": "所需资源"}}]
}}"""

    def _run_rule_based_analysis(self, context: dict) -> dict:
        return {
            "regional_gaps": [
                {"area": "中山区核心商圈", "gap_type": "午晚市高峰期运力不足", "vehicle_needed": "面包车/冷藏车", "time_slot": "11:00前/17:00前", "estimated_daily_orders": "500-1000单缺口", "profit_potential": "高（商圈密度大，单车可覆盖多店）"},
                {"area": "甘井子仓储带->全市", "gap_type": "凌晨批量配送运力不足", "vehicle_needed": "4.2m厢货", "time_slot": "凌晨2:00-6:00", "estimated_daily_orders": "200-500单缺口", "profit_potential": "中高（批量配送装载率高）"},
                {"area": "旅顺->市区", "gap_type": "季节性冷链运力严重不足", "vehicle_needed": "冷藏车", "time_slot": "樱桃季6-7月全天", "estimated_daily_orders": "50-100单缺口（产季）", "profit_potential": "高（产季运价翻倍）"},
                {"area": "高新园区", "gap_type": "午间办公餐饮配送运力不足", "vehicle_needed": "电动车/面包车", "time_slot": "11:00-13:00", "estimated_daily_orders": "300-500单缺口", "profit_potential": "中（单量高但客单价低）"},
            ],
            "industry_growth": [
                {"industry": "社区团购/即时零售", "growth_trend": "年增30-50%", "signal_source": "招聘数据+电商平台扩张", "estimated_new_orders": "日均新增200-500单", "recommended_action": "与美团优选/多多买菜大连仓建立合作"},
                {"industry": "医药冷链配送", "growth_trend": "年增20-30%", "signal_source": "GSP合规趋严+连锁药房扩张", "estimated_new_orders": "日均新增50-100单", "recommended_action": "获取GSP认证，切入医药冷链细分市场"},
                {"industry": "生鲜电商", "growth_trend": "年增25-40%", "signal_source": "盒马/叮咚/朴朴大连扩张", "estimated_new_orders": "日均新增300-800单", "recommended_action": "建立前置仓+冷链配送网络"},
            ],
            "high_profit_routes": [
                {"route": "甘井子仓储中心->中山区商圈", "vehicle": "4.2m厢货", "time_slot": "凌晨4:00-6:00", "estimated_profit_per_trip": "150-250元/趟", "monthly_potential": "9000-15000元/月（日均2趟）"},
                {"route": "大连湾->市区餐厅", "vehicle": "冷藏车", "time_slot": "凌晨3:00-7:00", "estimated_profit_per_trip": "300-500元/趟", "monthly_potential": "18000-30000元/月（日均2趟）"},
                {"route": "旅顺->大连市区（樱桃季）", "vehicle": "冷藏车", "time_slot": "全天", "estimated_profit_per_trip": "500-800元/趟", "monthly_potential": "30000-48000元/月（产季2个月）"},
            ],
            "potential_clients": [
                {"name": "喜家德水饺（大连总部）", "industry": "餐饮连锁", "priority": "高", "need": "中央厨房->门店日配", "estimated_annual_value": "50-150万", "outreach_strategy": "以午晚市时效保障方案切入"},
                {"name": "罗森便利店（大连）", "industry": "便利店连锁", "priority": "高", "need": "鲜食日配+常温周配", "estimated_annual_value": "200-500万", "outreach_strategy": "以SLA保障+系统对接方案切入"},
                {"name": "海王星辰大药房（大连）", "industry": "医药零售", "priority": "高", "need": "冷链药品日配+夜间急送", "estimated_annual_value": "150-400万", "outreach_strategy": "以GSP合规一站式方案切入"},
                {"name": "旅顺樱桃园合作社", "industry": "农产品", "priority": "高（季节性）", "need": "产季冷链运力", "estimated_annual_value": "30-80万（产季2个月）", "outreach_strategy": "产季前签约包车协议"},
            ],
            "market_gaps": [
                {"gap": "专业B端同城配送服务商缺失", "current_situation": "市场被货拉拉/快狗等C端平台主导，B端定制化需求未被满足", "opportunity": "做行业垂直配送服务商（餐饮/生鲜/医药各有专属SOP）", "entry_difficulty": "中", "estimated_market_size": "大连B端同城配送市场约5000万-1亿/年"},
                {"gap": "冷链运力严重不足", "current_situation": "大连专业冷藏车仅20+台，樱桃季/海鲜季运力缺口30-60%", "opportunity": "建立专业冷链车队+产地预冷服务", "entry_difficulty": "中高", "estimated_market_size": "大连冷链配送市场约2000-5000万/年"},
                {"gap": "凌晨配送服务空白", "current_situation": "便利店/生鲜店凌晨配送需求大但供给极少", "opportunity": "建立凌晨配送专线（2:00-6:00）", "entry_difficulty": "中", "estimated_market_size": "大连凌晨配送市场约1000-3000万/年"},
                {"gap": "本地分散运力缺乏整合", "current_situation": "大连本地小车队200-300家，各自为战", "opportunity": "搭建运力共享平台，整合分散运力", "entry_difficulty": "高", "estimated_market_size": "整合后可覆盖3000-5000万/年市场"},
            ],
            "action_recommendations": [
                {"priority": "P0", "action": "锁定3-5家高紧迫度目标企业，提供免费试用期（2周）", "timeline": "第1-2周", "expected_outcome": "建立标杆案例，验证服务模式", "resources_needed": "销售团队2人+运力5台"},
                {"priority": "P0", "action": "整合10-15台本地运力（面包车+冷藏车），签订合作协议", "timeline": "第1-2周", "expected_outcome": "形成基础运力池", "resources_needed": "运力采购预算10-20万"},
                {"priority": "P1", "action": "上线调度系统MVP（订单管理+温控记录+签收）", "timeline": "第3-6周", "expected_outcome": "标准化服务能力", "resources_needed": "技术团队2-3人"},
                {"priority": "P1", "action": "以标杆案例撬动同行业5-10家客户", "timeline": "第5-8周", "expected_outcome": "规模化复制", "resources_needed": "销售团队+运力扩展"},
                {"priority": "P2", "action": "扩展至第二行业（如从餐饮扩展到生鲜冷链）", "timeline": "第9-12周", "expected_outcome": "行业多元化，降低单一行业风险", "resources_needed": "新增运力+行业专家"},
            ],
        }


def mine_opportunities(city: str = "大连", keyword: str = "餐饮配送",
                       use_deepseek: bool = True) -> dict:
    return OpportunityMiningEngine(city=city, keyword=keyword).mine(use_deepseek=use_deepseek)
