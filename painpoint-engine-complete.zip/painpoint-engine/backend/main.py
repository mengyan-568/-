"""
洞见 Foresight — 主应用入口 v2.1
FastAPI 后端，PostgreSQL (生产) / DuckDB (本地开发) 双数据库
"""
import os
import json
import uuid
from datetime import datetime

from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel

try:
    from collectors.app_store import AppStoreCollector
except ImportError:
    AppStoreCollector = None

try:
    from collectors.ecommerce import EcommerceCollector
except ImportError:
    EcommerceCollector = None

try:
    from collectors.web_search import WebSearchCollector, generate_dynamic_reviews
except ImportError:
    WebSearchCollector = None
    generate_dynamic_reviews = None
from nlp.analyzer import NLPAnalyzer
from analyzer.engine import InsightEngine
from database import execute, execute_write, execute_many, run_migrations, seed_demo_data, is_postgres

try:
    from tracking import get_tracking_service
except ImportError:
    get_tracking_service = None

try:
    from optimizer import get_optimizer
except ImportError:
    get_optimizer = None

from api_products import router as products_router
from api_ai import router as ai_router
from api_enterprise import router as enterprise_router
from api_mining import router as mining_router
from api_chat import router as chat_router
from api_channels import router as channels_router

app = FastAPI(title="洞见 Foresight", version="2.1.0")
app.include_router(products_router)
app.include_router(ai_router)
app.include_router(enterprise_router)
app.include_router(mining_router)
app.include_router(chat_router)
app.include_router(channels_router)

# AI analysis availability check
_GEMINI_KEY = os.environ.get("GEMINI_API_KEY", "")
if not _GEMINI_KEY:
    print("[INFO] GEMINI_API_KEY not set — AI analysis disabled, using template fallback")
else:
    print(f"[INFO] Gemini API key configured ({_GEMINI_KEY[:8]}...) — AI analysis enabled")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ---- 启动时自动迁移 ----
@app.on_event("startup")
def startup():
    db_type = "PostgreSQL" if is_postgres() else "DuckDB"
    print(f"[DB] Using {db_type}")
    run_migrations()
    # 首次运行时插入演示数据
    vehicles = execute("SELECT COUNT(*) as cnt FROM vehicles")
    if vehicles and list(vehicles[0].values())[0] == 0:
        seed_demo_data()


# ---- API Models ----

class AnalyzeRequest(BaseModel):
    keyword: str
    sources: list[str] = ["app_store", "ecommerce"]
    max_reviews: int = 200


class TrackOpportunityRequest(BaseModel):
    analysis_id: str = ""
    merchant_name: str
    contact_person: str = ""
    contact_phone: str = ""
    status: str = "新线索"
    notes: str = ""
    deal_amount: float = 0
    close_reason: str = ""


class AddFollowUpRequest(BaseModel):
    content: str
    next_follow_date: str = ""


class StatusChangeRequest(BaseModel):
    status: str
    note: str = ""
    deal_amount: float = 0
    close_reason: str = ""


VALID_STATUSES = ["新线索", "洽谈中", "已报价", "已成交", "已流失"]
CLOSED_STATUSES = ["已成交", "已流失"]


# ---- Helpers ----

def _now():
    return datetime.now().isoformat()


def _uid() -> str:
    return str(uuid.uuid4())


def _log_status_change(opp_id: str, from_status, to_status: str, note: str = ""):
    execute_write(
        "INSERT INTO status_history (id, opportunity_id, from_status, to_status, note, created_at) VALUES (?, ?, ?, ?, ?, ?)",
        (_uid(), opp_id, from_status, to_status, note, _now())
    )


def _row_to_dict(row: dict) -> dict:
    """确保返回的字典键是纯字符串（DuckDB 有时返回带表名的键）"""
    return {k.split(".")[-1] if "." in k else k: v for k, v in row.items()}


# ---- API Routes ----

@app.get("/api/health")
def health():
    db_type = "PostgreSQL" if is_postgres() else "DuckDB"
    return {"status": "ok", "time": _now(), "database": db_type}


@app.post("/api/analyze")
def analyze(req: AnalyzeRequest):
    """执行完整的商机分析流程"""
    keyword = req.keyword.strip()
    if not keyword:
        raise HTTPException(400, "关键词不能为空")

    engine = InsightEngine()

    # 1. 互联网搜索
    companies = []
    industry_info = ""
    web_reviews = []

    try:
        searcher = WebSearchCollector()
        companies = searcher.search_companies(keyword)
        print(f"[WebSearch] 企业发现: {len(companies)} 家")
    except Exception as e:
        print(f"[WebSearch] 企业搜索失败: {e}")

    try:
        industry_info = searcher.search_industry_info(keyword)
    except Exception as e:
        print(f"[WebSearch] 行业搜索失败: {e}")

    try:
        web_reviews = searcher.search_reviews(keyword)
        print(f"[WebSearch] 评论采集: {len(web_reviews)} 条")
    except Exception as e:
        print(f"[WebSearch] 评论搜索失败: {e}")

    # 2. 传统来源采集
    all_reviews = list(web_reviews)

    if "app_store" in req.sources:
        try:
            reviews = AppStoreCollector().search(keyword, max_results=req.max_reviews // len(req.sources))
            all_reviews.extend(reviews)
        except Exception as e:
            print(f"[AppStore] 采集异常: {e}")

    if "ecommerce" in req.sources:
        try:
            reviews = EcommerceCollector().search(keyword, max_results=req.max_reviews // len(req.sources))
            all_reviews.extend(reviews)
        except Exception as e:
            print(f"[Ecommerce] 采集异常: {e}")

    # 3. 补充动态评论
    if not all_reviews:
        all_reviews = engine.generate_demo_reviews(keyword, companies)
    elif len(all_reviews) < 30:
        extra = engine.generate_demo_reviews(keyword, companies)
        target = min(len(extra), max(80, len(all_reviews) * 3))
        all_reviews.extend(extra[:target - len(all_reviews)])

    # 4. NLP 分析
    nlp = NLPAnalyzer()
    analyzed = nlp.analyze_reviews(all_reviews, keyword=keyword)

    # 5. 生成洞察
    report = engine.generate_report(keyword, analyzed, companies, industry_info)

    # 6. 保存到数据库
    analysis_id = _uid()
    stats = report.get("stats", {})
    top_opp = report.get("opportunities", [{}])[0] if report.get("opportunities") else {}

    execute_write(
        """INSERT INTO pain_analyses (id, keyword, scenario, report_data, negative_review_count,
           top_opportunity_score, top_opportunity_category, target_merchant_count, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (analysis_id, keyword, report.get("scenario", ""),
         json.dumps(report, ensure_ascii=False),
         stats.get("total_negative", 0),
         top_opp.get("score", 0),
         top_opp.get("category", ""),
         len(report.get("target_merchants", [])),
         _now())
    )

    # 批量保存评论
    review_rows = [
        (_uid(), analysis_id, r.get("source", ""), r["content"],
         r.get("rating", 0), r.get("sentiment", 0), r.get("pain_score", 0),
         r.get("is_negative", False), json.dumps(r.get("keywords", []), ensure_ascii=False),
         _now())
        for r in analyzed
    ]
    execute_many(
        """INSERT INTO reviews (id, analysis_id, source, content, rating, sentiment,
           pain_score, is_negative, keywords, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        review_rows
    )

    report["id"] = analysis_id
    return report


@app.get("/api/reports")
def list_reports():
    rows = execute(
        "SELECT id, keyword, scenario, created_at FROM pain_analyses ORDER BY created_at DESC LIMIT 20"
    )
    return [_row_to_dict(r) for r in rows]


@app.get("/api/reports/{report_id}")
def get_report(report_id: str):
    rows = execute("SELECT * FROM pain_analyses WHERE id = ?", (report_id,))
    if not rows:
        raise HTTPException(404, "报告不存在")
    row = _row_to_dict(rows[0])

    report = json.loads(row["report_data"]) if isinstance(row["report_data"], str) else row["report_data"]
    report["id"] = row["id"]

    # 加载关联评论
    review_rows = execute(
        "SELECT * FROM reviews WHERE analysis_id = ? ORDER BY pain_score DESC", (report_id,)
    )
    report["reviews"] = [_row_to_dict(r) for r in review_rows]
    return report


# ---- 商机跟踪 API ----

@app.get("/api/track/opportunities")
def list_opportunities(status: str = "", overdue: bool = False, scope: str = "active"):
    base_filter = "o.deleted_at IS NULL"
    if scope == "active":
        scope_filter = f"{base_filter} AND o.archived_at IS NULL AND o.status NOT IN ('已成交', '已流失')"
    elif scope == "archived":
        scope_filter = f"{base_filter} AND (o.archived_at IS NOT NULL OR o.status IN ('已成交', '已流失'))"
    elif scope == "trash":
        scope_filter = "o.deleted_at IS NOT NULL"
    else:
        scope_filter = base_filter

    if overdue:
        rows = execute(f"""
            SELECT o.*,
                   (SELECT MAX(created_at) FROM follow_up_logs WHERE opportunity_id = o.id) AS last_follow,
                   (SELECT next_follow_date FROM follow_up_logs WHERE opportunity_id = o.id ORDER BY created_at DESC LIMIT 1) AS next_follow
            FROM tracked_opportunities o
            WHERE {base_filter} AND o.archived_at IS NULL AND o.status NOT IN ('已成交', '已流失')
            ORDER BY o.updated_at DESC
        """)
        result = []
        for r in rows:
            d = _row_to_dict(r)
            d["is_overdue"] = False
            try:
                if d.get("next_follow"):
                    nf = datetime.strptime(str(d["next_follow"])[:10], "%Y-%m-%d")
                    if datetime.now() > nf:
                        d["is_overdue"] = True
                elif d.get("last_follow"):
                    lf = datetime.strptime(str(d["last_follow"])[:10], "%Y-%m-%d")
                    if (datetime.now() - lf).days >= 3:
                        d["is_overdue"] = True
                else:
                    created = datetime.strptime(str(d["created_at"])[:10], "%Y-%m-%d")
                    if (datetime.now() - created).days >= 3:
                        d["is_overdue"] = True
            except Exception:
                pass
            result.append(d)
        return result

    if status and status in VALID_STATUSES:
        rows = execute(f"""
            SELECT o.*,
                   (SELECT MAX(created_at) FROM follow_up_logs WHERE opportunity_id = o.id) AS last_follow
            FROM tracked_opportunities o
            WHERE {scope_filter} AND o.status = ?
            ORDER BY o.updated_at DESC
        """, (status,))
    else:
        rows = execute(f"""
            SELECT o.*,
                   (SELECT MAX(created_at) FROM follow_up_logs WHERE opportunity_id = o.id) AS last_follow
            FROM tracked_opportunities o
            WHERE {scope_filter}
            ORDER BY o.updated_at DESC
        """)
    return [_row_to_dict(r) for r in rows]


@app.get("/api/track/stats")
def track_stats():
    rows = execute("""
        SELECT status, COUNT(*) AS cnt, COALESCE(SUM(deal_amount), 0) AS gmv
        FROM tracked_opportunities
        WHERE deleted_at IS NULL
        GROUP BY status
    """)
    stats = {s: {"count": 0, "gmv": 0} for s in VALID_STATUSES}
    for r in rows:
        rd = _row_to_dict(r)
        if rd["status"] in stats:
            stats[rd["status"]] = {"count": rd["cnt"], "gmv": float(rd["gmv"] or 0)}

    total = sum(s["count"] for s in stats.values())
    won = stats["已成交"]["count"]
    lost = stats["已流失"]["count"]
    closed = won + lost
    active_count = total - closed
    win_rate = (won / closed * 100) if closed > 0 else 0
    gmv = stats["已成交"]["gmv"]

    overdue_rows = execute("""
        SELECT o.id, o.created_at,
               (SELECT MAX(created_at) FROM follow_up_logs WHERE opportunity_id = o.id) AS last_follow,
               (SELECT next_follow_date FROM follow_up_logs WHERE opportunity_id = o.id ORDER BY created_at DESC LIMIT 1) AS next_follow
        FROM tracked_opportunities o
        WHERE o.deleted_at IS NULL AND o.archived_at IS NULL AND o.status NOT IN ('已成交', '已流失')
    """)
    overdue_count = 0
    for r in overdue_rows:
        d = _row_to_dict(r)
        try:
            if d.get("next_follow"):
                if datetime.now() > datetime.strptime(str(d["next_follow"])[:10], "%Y-%m-%d"):
                    overdue_count += 1
            elif d.get("last_follow"):
                if (datetime.now() - datetime.strptime(str(d["last_follow"])[:10], "%Y-%m-%d")).days >= 3:
                    overdue_count += 1
            else:
                if (datetime.now() - datetime.strptime(str(d["created_at"])[:10], "%Y-%m-%d")).days >= 3:
                    overdue_count += 1
        except Exception:
            pass

    return {
        "total": total, "active": active_count, "won": won, "lost": lost,
        "overdue": overdue_count, "gmv": gmv,
        "avg_deal": round(gmv / won, 2) if won > 0 else 0,
        "win_rate": round(win_rate, 1), "by_status": stats,
    }


@app.post("/api/track/opportunities")
def create_opportunity(req: TrackOpportunityRequest):
    opp_id = _uid()
    now = _now()
    execute_write(
        """INSERT INTO tracked_opportunities (id, analysis_id, merchant_name, contact_person,
           contact_phone, status, notes, deal_amount, close_reason, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (opp_id, req.analysis_id or None, req.merchant_name, req.contact_person,
         req.contact_phone, req.status, req.notes, req.deal_amount, req.close_reason, now, now)
    )
    _log_status_change(opp_id, None, req.status, "创建商机")
    return {"id": opp_id, "message": "商机已创建"}


@app.put("/api/track/opportunities/{opp_id}")
def update_opportunity(opp_id: str, req: TrackOpportunityRequest):
    rows = execute("SELECT status FROM tracked_opportunities WHERE id=? AND deleted_at IS NULL", (opp_id,))
    if not rows:
        raise HTTPException(404, "商机不存在")
    old_status = rows[0].get("status", "")
    now = _now()
    archived_at = now if req.status in CLOSED_STATUSES else None

    execute_write(
        """UPDATE tracked_opportunities
           SET merchant_name=?, contact_person=?, contact_phone=?, status=?, notes=?,
               deal_amount=?, close_reason=?,
               archived_at = CASE WHEN archived_at IS NULL AND ? IS NOT NULL THEN ? ELSE archived_at END,
               updated_at=?
           WHERE id=?""",
        (req.merchant_name, req.contact_person, req.contact_phone, req.status, req.notes,
         req.deal_amount, req.close_reason,
         archived_at, archived_at, now, opp_id)
    )
    if old_status != req.status:
        _log_status_change(opp_id, old_status, req.status, "编辑商机时变更")
    return {"message": "商机已更新"}


@app.put("/api/track/opportunities/{opp_id}/status")
def update_opportunity_status(opp_id: str, req: StatusChangeRequest):
    if req.status not in VALID_STATUSES:
        raise HTTPException(400, f"无效状态，可选值: {', '.join(VALID_STATUSES)}")
    rows = execute("SELECT status FROM tracked_opportunities WHERE id=? AND deleted_at IS NULL", (opp_id,))
    if not rows:
        raise HTTPException(404, "商机不存在")
    old_status = rows[0].get("status", "")
    now = _now()
    archived_at = now if req.status in CLOSED_STATUSES else None

    execute_write(
        """UPDATE tracked_opportunities
           SET status=?,
               deal_amount = CASE WHEN ? > 0 THEN ? ELSE deal_amount END,
               close_reason = CASE WHEN ? <> '' THEN ? ELSE close_reason END,
               archived_at = CASE WHEN archived_at IS NULL AND ? IS NOT NULL THEN ? ELSE archived_at END,
               updated_at=?
           WHERE id=?""",
        (req.status, req.deal_amount, req.deal_amount, req.close_reason, req.close_reason,
         archived_at, archived_at, now, opp_id)
    )
    if old_status != req.status:
        _log_status_change(opp_id, old_status, req.status, req.note)
    return {"message": "状态已更新"}


@app.get("/api/track/opportunities/{opp_id}/logs")
def get_follow_logs(opp_id: str):
    rows = execute(
        "SELECT * FROM follow_up_logs WHERE opportunity_id = ? ORDER BY created_at DESC", (opp_id,)
    )
    return [_row_to_dict(r) for r in rows]


@app.get("/api/track/opportunities/{opp_id}/timeline")
def get_timeline(opp_id: str):
    opp_rows = execute("SELECT * FROM tracked_opportunities WHERE id=?", (opp_id,))
    if not opp_rows:
        raise HTTPException(404, "商机不存在")

    logs = execute(
        "SELECT id, content, next_follow_date, created_at FROM follow_up_logs WHERE opportunity_id=?", (opp_id,)
    )
    changes = execute(
        "SELECT id, from_status, to_status, note, created_at FROM status_history WHERE opportunity_id=?", (opp_id,)
    )

    timeline = []
    for l in logs:
        d = _row_to_dict(l)
        d["type"] = "follow_up"
        timeline.append(d)
    for c in changes:
        d = _row_to_dict(c)
        d["type"] = "status_change"
        timeline.append(d)
    timeline.sort(key=lambda x: x.get("created_at", ""), reverse=True)
    return {"opportunity": _row_to_dict(opp_rows[0]), "timeline": timeline}


@app.post("/api/track/opportunities/{opp_id}/logs")
def add_follow_log(opp_id: str, req: AddFollowUpRequest):
    now = _now()
    log_id = _uid()
    execute_write(
        "INSERT INTO follow_up_logs (id, opportunity_id, content, next_follow_date, created_at) VALUES (?, ?, ?, ?, ?)",
        (log_id, opp_id, req.content, req.next_follow_date or "", now)
    )
    execute_write("UPDATE tracked_opportunities SET updated_at=? WHERE id=?", (now, opp_id))
    return {"id": log_id, "message": "跟进记录已添加"}


@app.post("/api/track/opportunities/{opp_id}/archive")
def archive_opportunity(opp_id: str):
    now = _now()
    execute_write(
        "UPDATE tracked_opportunities SET archived_at=?, updated_at=? WHERE id=? AND archived_at IS NULL",
        (now, now, opp_id)
    )
    return {"message": "商机已归档"}


@app.post("/api/track/opportunities/{opp_id}/unarchive")
def unarchive_opportunity(opp_id: str):
    now = _now()
    execute_write(
        "UPDATE tracked_opportunities SET archived_at=NULL, updated_at=? WHERE id=?", (now, opp_id)
    )
    return {"message": "已撤销归档"}


@app.delete("/api/track/opportunities/{opp_id}")
def delete_opportunity(opp_id: str):
    now = _now()
    execute_write("UPDATE tracked_opportunities SET deleted_at=?, updated_at=? WHERE id=?", (now, now, opp_id))
    return {"message": "商机已删除（可恢复）"}


@app.post("/api/track/opportunities/{opp_id}/restore")
def restore_opportunity(opp_id: str):
    now = _now()
    execute_write("UPDATE tracked_opportunities SET deleted_at=NULL, updated_at=? WHERE id=?", (now, opp_id))
    return {"message": "商机已恢复"}


@app.delete("/api/track/opportunities/{opp_id}/purge")
def purge_opportunity(opp_id: str):
    execute_write("DELETE FROM follow_up_logs WHERE opportunity_id = ?", (opp_id,))
    execute_write("DELETE FROM status_history WHERE opportunity_id = ?", (opp_id,))
    execute_write("DELETE FROM tracked_opportunities WHERE id = ?", (opp_id,))
    return {"message": "商机已彻底删除"}


# ---- 车辆/车队 API (NEW) ----

@app.get("/api/fleet/vehicles")
def list_vehicles():
    rows = execute("SELECT * FROM vehicles ORDER BY plate_number")
    return [_row_to_dict(r) for r in rows]


@app.get("/api/fleet/drivers")
def list_drivers():
    rows = execute("SELECT * FROM drivers ORDER BY name")
    return [_row_to_dict(r) for r in rows]


@app.get("/api/fleet/vehicles/{vehicle_id}/track")
def get_vehicle_track(vehicle_id: str, hours: int = 1):
    """获取车辆最近 N 小时的 GPS 轨迹"""
    rows = execute(
        """SELECT time, latitude, longitude, speed_kmh, heading, ignition
           FROM gps_pings
           WHERE vehicle_id = ? AND time > datetime('now', ?)
           ORDER BY time DESC
           LIMIT 500""",
        (vehicle_id, f"-{hours} hours")
    )
    return [_row_to_dict(r) for r in rows]


@app.get("/api/fleet/overview")
def fleet_overview():
    """车队概览：在线车辆数、今日订单数、活跃司机数"""
    vehicles = execute("SELECT COUNT(*) as cnt FROM vehicles WHERE status = 'idle'")
    drivers = execute("SELECT COUNT(*) as cnt FROM drivers WHERE status != 'offline'")
    online_vehicles = list(vehicles[0].values())[0] if vehicles else 0
    online_drivers = list(drivers[0].values())[0] if drivers else 0

    # 从追踪服务获取实时状态
    tracking = get_tracking_service() if get_tracking_service else None
    live_stats = tracking.get_stats()
    live_positions = tracking.get_live_positions() if live_stats.get("running") else []

    return {
        "total_vehicles": online_vehicles,
        "online_drivers": online_drivers,
        "active_orders": 0,
        "tracking_running": live_stats.get("running", False),
        "tracking_total_pings": live_stats.get("total_pings", 0),
        "live_vehicles": len(live_positions),
    }


# ---- GPS 追踪 API (NEW) ----

@app.post("/api/tracking/start")
def start_tracking():
    """启动 GPS 追踪模拟（或连接 Traccar）"""
    tracking = get_tracking_service() if get_tracking_service else None
    if tracking.get_stats().get("running"):
        return {"message": "追踪服务已在运行", "stats": tracking.get_stats()}

    tracking.start()
    return {"message": "追踪服务已启动", "stats": tracking.get_stats()}


@app.post("/api/tracking/stop")
def stop_tracking():
    """停止追踪"""
    tracking = get_tracking_service() if get_tracking_service else None
    if tracking:
        tracking.stop()
    return {"message": "追踪服务已停止", "stats": tracking.get_stats()}


@app.get("/api/tracking/live")
def live_positions():
    """获取所有车辆实时位置（地图用）"""
    tracking = get_tracking_service() if get_tracking_service else None

    # 如果没运行，自动启动
    if not tracking.get_stats().get("running"):
        tracking.start()

    positions = tracking.get_live_positions()
    stats = tracking.get_stats()

    return {
        "positions": positions,
        "total_pings": stats.get("total_pings", 0),
        "running": stats.get("running", False),
    }


@app.get("/api/tracking/history")
def tracking_history(vehicle_id: str = "", limit: int = 200):
    """获取 GPS 历史轨迹"""
    if vehicle_id:
        rows = execute(
            """SELECT time, vehicle_id, latitude, longitude, speed_kmh, heading, ignition, extra
               FROM gps_pings WHERE vehicle_id = ?
               ORDER BY time DESC LIMIT ?""",
            (vehicle_id, limit)
        )
    else:
        rows = execute(
            """SELECT time, vehicle_id, latitude, longitude, speed_kmh, heading, ignition, extra
               FROM gps_pings ORDER BY time DESC LIMIT ?""",
            (limit,)
        )
    return [_row_to_dict(r) for r in rows]


@app.get("/api/tracking/stats")
def tracking_stats():
    """追踪服务统计"""
    tracking = get_tracking_service() if get_tracking_service else None
    return tracking.get_stats()


# ---- Traccar OsmAnd 协议兼容端点 ----
# 将来真 Traccar 服务器可直接替换此端点

@app.get("/api/tracking/osmand")
def osmand_get(id: str = "", lat: float = 0, lon: float = 0,
               timestamp: int = 0, speed: float = 0, bearing: float = 0,
               altitude: float = 0, accuracy: float = 0, batt: float = 0):
    """OsmAnd 协议 GET 端点 — 手机/设备上报位置"""
    # TODO: 写入 gps_pings 表
    return {"status": "ok"}


@app.post("/api/tracking/osmand")
async def osmand_post(request: dict = None):
    """OsmAnd 协议 POST 端点"""
    # TODO: 解析 OsmAnd JSON 格式并写入数据库
    return {"status": "ok"}


# ---- 路径优化 API (NEW) ----

class OptimizeRequest(BaseModel):
    keyword: str = "餐饮配送"
    n_stops: int = 6
    depot: dict = None
    stops: list[dict] = None
    vehicles: list[dict] = None
    strategy: str = "min_distance"


@app.post("/api/optimize")
def optimize_routes(req: OptimizeRequest):
    """路径优化 — OR-Tools VRPTW 求解"""
    optimizer = get_optimizer() if get_optimizer else None

    # 使用请求中的 depot/stops，否则自动生成演示数据
    if req.depot and req.stops:
        depot = req.depot
        stops = req.stops
    else:
        from tracking.simulator import DALIAN_LANDMARKS
        depot = DALIAN_LANDMARKS["depots"][0]
        stops = optimizer.generate_demo_stops(req.keyword, req.n_stops)

    vehicles = req.vehicles if req.vehicles else [
        {"id": "v1", "plate": "辽B·12345", "capacity_kg": 1000, "cost_per_km": 3.5, "fixed_cost": 30},
        {"id": "v2", "plate": "辽B·23456", "capacity_kg": 1500, "cost_per_km": 4.0, "fixed_cost": 40},
    ]

    result = optimizer.optimize({
        "depot": depot,
        "stops": stops,
        "vehicles": vehicles,
        "strategy": req.strategy,
        "max_solution_seconds": 5,
    })

    result["depot"] = depot
    result["input_stops"] = stops
    return result


@app.get("/api/optimize/demo")
def optimize_demo(keyword: str = "餐饮配送", n_stops: int = 6):
    """快速演示 — 自动生成配送点并优化路线"""
    optimizer = get_optimizer() if get_optimizer else None
    from tracking.simulator import DALIAN_LANDMARKS

    depot = DALIAN_LANDMARKS["depots"][0]
    stops = optimizer.generate_demo_stops(keyword, n_stops)

    vehicles = [
        {"id": "v1", "plate": "辽B·12345", "capacity_kg": 1000, "cost_per_km": 3.5, "fixed_cost": 30},
        {"id": "v2", "plate": "辽B·23456", "capacity_kg": 1500, "cost_per_km": 4.0, "fixed_cost": 40},
    ]

    result = optimizer.optimize({
        "depot": depot,
        "stops": stops,
        "vehicles": vehicles,
        "strategy": "min_distance",
        "max_solution_seconds": 5,
    })

    result["depot"] = depot
    result["input_stops"] = stops
    return result


# 静态文件服务
frontend_dir = os.path.join(os.path.dirname(__file__), "..", "frontend")
if os.path.exists(frontend_dir):
    app.mount("/static", StaticFiles(directory=frontend_dir), name="static")

    @app.get("/products")
    def products_dashboard():
        return FileResponse(os.path.join(frontend_dir, "products.html"))


@app.get("/")
def index():
    return FileResponse(os.path.join(frontend_dir, "index.html"))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
