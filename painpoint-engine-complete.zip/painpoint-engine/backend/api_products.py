"""
商机挖掘产物 API 路由 — 四大产物 + 全流程流水线
"""
import json
import os
from datetime import datetime

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

from collectors.public_sources import PublicSourceCollector
from collectors.semi_public_sources import SemiPublicSourceCollector
from collectors.products import ProductGenerator
from pipeline import run_pipeline

router = APIRouter(prefix="/api/products", tags=["商机挖掘产物"])


class PipelineRequest(BaseModel):
    keyword: str = "餐饮配送"
    city: str = "大连"
    include_web_search: bool = False
    include_demo_reviews: bool = True
    quick_mode: bool = False


@router.get("/capacity-map")
def get_capacity_map(city: str = "大连"):
    """获取大连同城配送运力地图"""
    gen = ProductGenerator(city=city)
    return gen.generate_capacity_map()


@router.get("/demand-heatmap")
def get_demand_heatmap(city: str = "大连"):
    """获取大连同城配送需求热力图"""
    gen = ProductGenerator(city=city)
    return gen.generate_demand_heatmap()


@router.get("/competitive-benchmark")
def get_competitive_benchmark(city: str = "大连"):
    """获取竞品价格对标表"""
    gen = ProductGenerator(city=city)
    return gen.generate_competitive_benchmark()


@router.get("/opportunity-list")
def get_opportunity_list(
    keyword: str = Query("餐饮配送", description="行业关键词"),
    city: str = "大连"
):
    """获取商机企业清单"""
    gen = ProductGenerator(city=city)
    return gen.generate_opportunity_list(keyword=keyword)


@router.post("/pipeline")
def run_opportunity_pipeline(req: PipelineRequest):
    """运行完整的商机挖掘流水线"""
    return run_pipeline(
        city=req.city,
        keyword=req.keyword,
        include_web_search=req.include_web_search,
        include_demo_reviews=req.include_demo_reviews,
        quick_mode=req.quick_mode,
    )


@router.get("/pipeline/quick")
def run_quick_pipeline(
    keyword: str = Query("餐饮配送"),
    city: str = "大连"
):
    """快速模式：直接生成四大产物"""
    return run_pipeline(city=city, keyword=keyword, quick_mode=True)


@router.get("/data-sources")
def get_data_source_status(city: str = "大连"):
    """获取所有数据源的采集状态"""
    return {
        "city": city,
        "checked_at": datetime.now().isoformat(),
        "public_sources": {
            "货拉拉/快狗/运满满": {"status": "estimated", "note": "需要爬虫实时抓取"},
            "58同城/赶集网": {"status": "estimated", "note": "需要爬虫实时抓取"},
            "天眼查/企查查": {"status": "estimated", "note": "需要API对接"},
            "招标网站": {"status": "estimated", "note": "需要RSS/API对接"},
            "高德/百度地图POI": {"status": "estimated", "note": "需要地图API Key"},
        },
        "semi_public_sources": {
            "招聘网站": {"status": "estimated", "note": "需要爬虫/API"},
            "抖音/快手": {"status": "estimated", "note": "需要开放平台API"},
            "加油站/充电桩": {"status": "estimated", "note": "需要第三方API"},
            "交通违章数据": {"status": "estimated", "note": "需要交管数据接口"},
        },
        "upgrade_path": "所有数据源当前使用行业经验估算数据。实际部署时替换为真实API/爬虫采集。",
    }


@router.get("/all")
def get_all_products(
    keyword: str = Query("餐饮配送"),
    city: str = "大连"
):
    """一键获取四大产物"""
    gen = ProductGenerator(city=city)
    return {
        "city": city,
        "keyword": keyword,
        "generated_at": datetime.now().isoformat(),
        "products": {
            "capacity_map": gen.generate_capacity_map(),
            "demand_heatmap": gen.generate_demand_heatmap(),
            "competitive_benchmark": gen.generate_competitive_benchmark(),
            "opportunity_list": gen.generate_opportunity_list(keyword=keyword),
        },
    }
