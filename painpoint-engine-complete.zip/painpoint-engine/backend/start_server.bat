@echo off
chcp 65001 >nul
title 洞见 Foresight Server

cd /d "D:\Desktop\painpoint-engine\backend"

:loop
echo [%date% %time%] Starting 洞见 Foresight server...
python -m uvicorn main:app --host 127.0.0.1 --port 8000 --reload
echo [%date% %time%] Server stopped with exit code %ERRORLEVEL%. Restarting in 3 seconds...
timeout /t 3 /nobreak >nul
goto loop
