#!/usr/bin/env python3
"""
商机挖掘一键 Demo — 生成完整报告并保存为 JSON

用法:
    python demo.py                          # 默认：餐饮配送
    python demo.py 生鲜冷链                  # 指定关键词
    python demo.py 医药配送 --full           # 完整流程（含NLP分析）
    python demo.py --all                     # 生成所有场景报告
"""
import json
import sys
import os
from datetime import datetime

sys.path.insert(0, os.path.dirname(__file__))

from pipeline import run_pipeline
from collectors.products import ProductGenerator

SCENARIOS = ["餐饮配送", "生鲜冷链", "医药配送", "家具配送", "商超补货"]


def print_separator(title: str = ""):
    width = 60
    if title:
        print(f"\n{'='*width}")
        print(f"  {title}")
        print(f"{'='*width}")
    else:
        print(f"{'='*width}")


def print_opportunity(opp: dict, idx: int):
    print(f"\n  [{idx}] {opp['name']}")
    print(f"      行业: {opp['industry']} | 规模: {opp['scale']}")
    print(f"      需求: {opp['delivery_need']}")
    print(f"      强度: {opp['demand_intensity']} | 紧迫度: {opp['urgency']}")
    if 'recommended_vehicle' in opp:
        v = opp['recommended_vehicle']
        print(f"      推荐车型: {v.get('primary', 'N/A')}")
        print(f"      价格估算: {v.get('price_estimate', 'N/A')}")
    if 'recommended_route' in opp:
        r = opp['recommended_route']
        print(f"      推荐路线: {r.get('main', 'N/A')}")
        print(f"      时间窗口: {r.get('time_window', 'N/A')}")
    print(f"      触达策略: {opp.get('outreach_strategy', 'N/A')}")
    print(f"      预估年价值: {opp.get('estimated_annual_value', 'N/A')}")


def demo_single(keyword: str, full_mode: bool = False):
    """运行单个场景的 Demo"""
    print_separator(f"大连同城配送商机挖掘 — 「{keyword}」场景")
    print(f"  时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"  模式: {'完整流程' if full_mode else '快速模式（仅产物）'}")

    # 运行流水线
    result = run_pipeline(
        city="大连",
        keyword=keyword,
        include_web_search=False,
        include_demo_reviews=full_mode,
        quick_mode=not full_mode,
    )

    products = result.get("products", {}).get("products", {})

    # 产物 1: 运力地图
    capacity = products.get("capacity_map", {})
    print_separator("产物 1: 运力地图 — 供给端摸底")
    providers = capacity.get("capacity_providers", [])
    stats = capacity.get("stats", {})
    print(f"  共发现 {len(providers)} 家运力提供商")
    print(f"  运力缺口分析: {stats.get('capacity_gap_analysis', 'N/A')[:120]}...")
    for p in providers[:3]:
        vtypes = ", ".join(f"{v['model']}×{v['count']}" for v in p.get("vehicle_types", [])[:2])
        print(f"  · {p['name']} ({p['type']}) — {vtypes}")

    # 产物 2: 需求热力图
    demand = products.get("demand_heatmap", {})
    print_separator("产物 2: 需求热力图 — 需求端分析")
    zones = demand.get("demand_zones", [])
    summary = demand.get("summary", {})
    print(f"  共 {len(zones)} 个需求区域")
    print(f"  日均订单估算: {summary.get('total_estimated_daily_orders', 'N/A')}")
    for z in zones[:3]:
        features = z.get("demand_features", {})
        top_feature = list(features.keys())[0] if features else "N/A"
        print(f"  · {z['zone']} — 需求强度: {z['demand_intensity']} — 主要: {top_feature}")

    # 产物 3: 竞品价格对标表
    benchmark = products.get("competitive_benchmark", {})
    print_separator("产物 3: 竞品价格对标表")
    vehicles = benchmark.get("vehicle_comparison", [])
    print(f"  共对比 {len(vehicles)} 种车型")
    for v in vehicles[:3]:
        hl = v.get("货拉拉", {}).get("起步价", "N/A")
        kg = v.get("快狗打车", {}).get("起步价", "N/A")
        local = v.get("本地车队均价", {}).get("起步价", "N/A")
        print(f"  · {v['车型']} — 货拉拉: {hl} | 快狗: {kg} | 本地: {local}")

    # 产物 4: 商机企业清单
    opp_list = products.get("opportunity_list", {})
    print_separator("产物 4: 商机企业清单 — 目标客户")
    opportunities = opp_list.get("opportunities", [])
    opp_summary = opp_list.get("summary", {})
    print(f"  共 {len(opportunities)} 家目标企业")
    print(f"  预估总价值: {opp_summary.get('total_estimated_value', 'N/A')}")
    for i, opp in enumerate(opportunities[:5], 1):
        print_opportunity(opp, i)

    # 保存报告
    output_dir = os.path.join(os.path.dirname(__file__), "..", "reports")
    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"opportunity_report_{keyword}_{timestamp}.json"
    filepath = os.path.join(output_dir, filename)

    def clean_for_json(obj):
        if isinstance(obj, dict):
            return {k: clean_for_json(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [clean_for_json(item) for item in obj]
        elif isinstance(obj, datetime):
            return obj.isoformat()
        return obj

    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(clean_for_json(result), f, ensure_ascii=False, indent=2)

    print_separator()
    print(f"  ✅ 报告已保存: {filepath}")
    print(f"  📊 产物数量: {result.get('products', {}).get('success_count', 0)}")
    print_separator()
    return result


def demo_all():
    """生成所有场景报告"""
    print_separator("大连同城配送商机挖掘 — 全场景报告")
    print(f"  场景数: {len(SCENARIOS)}")
    print(f"  时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    all_results = {}
    for scenario in SCENARIOS:
        print(f"\n  🔍 正在分析: {scenario}...")
        result = run_pipeline(city="大连", keyword=scenario, quick_mode=True)
        all_results[scenario] = {
            "products": result.get("products", {}).get("products", {}),
            "summary": {
                "capacity_providers": len(result.get("products", {}).get("products", {}).get("capacity_map", {}).get("capacity_providers", [])),
                "demand_zones": len(result.get("products", {}).get("products", {}).get("demand_heatmap", {}).get("demand_zones", [])),
                "opportunities": len(result.get("products", {}).get("products", {}).get("opportunity_list", {}).get("opportunities", [])),
            },
        }

    # 跨场景汇总
    print_separator("跨场景汇总")
    total_opps = 0
    for scenario, data in all_results.items():
        n = data["summary"]["opportunities"]
        total_opps += n
        print(f"  · {scenario}: {n} 家目标企业")

    print(f"\n  📊 全场景共发现 {total_opps} 条商机线索")
    print(f"  💡 建议按行业优先级排序: 餐饮 > 生鲜冷链 > 医药 > 商超补货 > 家具")

    # 保存全场景报告
    output_dir = os.path.join(os.path.dirname(__file__), "..", "reports")
    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filepath = os.path.join(output_dir, f"opportunity_report_ALL_{timestamp}.json")

    def clean_for_json(obj):
        if isinstance(obj, dict):
            return {k: clean_for_json(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [clean_for_json(item) for item in obj]
        elif isinstance(obj, datetime):
            return obj.isoformat()
        return obj

    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(clean_for_json(all_results), f, ensure_ascii=False, indent=2)

    print(f"\n  ✅ 全场景报告已保存: {filepath}")
    print_separator()


if __name__ == "__main__":
    args = sys.argv[1:]

    if "--all" in args:
        demo_all()
    elif "--full" in args:
        keyword = args[0] if args and not args[0].startswith("--") else "餐饮配送"
        demo_single(keyword, full_mode=True)
    elif args and not args[0].startswith("--"):
        demo_single(args[0])
    else:
        demo_single("餐饮配送")
