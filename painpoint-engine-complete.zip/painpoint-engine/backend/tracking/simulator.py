"""
GPS 轨迹模拟器 — 生成大连同城配送的真实路线

特点:
  - 基于大连真实地标（商圈、市场、仓库）生成取送路线
  - 模拟城市道路车速（核心商圈 15-25 km/h，主干道 40-60 km/h）
  - 支持多种配送场景（餐饮午市、冷链早市、家具上楼等）
  - 输出格式兼容 Traccar OsmAnd 协议，方便将来切换真设备
"""
import math
import random
import time
import uuid
from datetime import datetime, timedelta
from dataclasses import dataclass, field
from typing import Optional

# ============================================================
# 大连地标 — 模拟真实配送起终点
# ============================================================

DALIAN_LANDMARKS = {
    "depots": [
        {"name": "甘井子仓储中心", "lat": 38.9522, "lon": 121.5500, "type": "warehouse"},
        {"name": "大连湾物流园", "lat": 38.9833, "lon": 121.6833, "type": "warehouse"},
        {"name": "开发区配送站", "lat": 39.0500, "lon": 121.7833, "type": "hub"},
        {"name": "高新园区前置仓", "lat": 38.8500, "lon": 121.5167, "type": "hub"},
    ],
    "restaurants": [
        {"name": "喜家德水饺（中山总部）", "lat": 38.9150, "lon": 121.6400},
        {"name": "灵芝妹子（西安路店）", "lat": 38.9120, "lon": 121.5950},
        {"name": "鸣记烤鱼（高新万达）", "lat": 38.8550, "lon": 121.5200},
        {"name": "亚惠快餐（青泥洼桥）", "lat": 38.9180, "lon": 121.6350},
        {"name": "喜家德（开发区安盛）", "lat": 39.0550, "lon": 121.7800},
    ],
    "markets": [
        {"name": "辽渔国际水产品市场", "lat": 38.9900, "lon": 121.6900},
        {"name": "南关岭果菜批发市场", "lat": 38.9700, "lon": 121.5800},
        {"name": "大菜市批发市场", "lat": 38.9220, "lon": 121.6250},
    ],
    "retail": [
        {"name": "罗森（人民路店）", "lat": 38.9200, "lon": 121.6450},
        {"name": "罗森（西安路二店）", "lat": 38.9100, "lon": 121.5920},
        {"name": "会有便利（华南广场）", "lat": 38.9850, "lon": 121.5700},
        {"name": "新隆嘉（中山广场）", "lat": 38.9190, "lon": 121.6420},
        {"name": "盒马鲜生（高新店）", "lat": 38.8520, "lon": 121.5180},
    ],
    "pharmacies": [
        {"name": "海王星辰（中山总仓）", "lat": 38.9160, "lon": 121.6380},
        {"name": "成大方圆（西安路）", "lat": 38.9130, "lon": 121.5980},
    ],
    "furniture": [
        {"name": "宜家家居（香炉礁）", "lat": 38.9280, "lon": 121.6050},
        {"name": "红星美凯龙（华南）", "lat": 38.9880, "lon": 121.5720},
        {"name": "幸福家居世界", "lat": 38.9350, "lon": 121.6100},
    ],
}


@dataclass
class VehicleState:
    """单辆车的模拟状态"""
    vehicle_id: str
    plate_number: str
    driver_name: str
    route: list[dict]          # 途经点列表 [{lat, lon, name, type, stay_sec}]
    current_leg: int = 0       # 当前在第几段
    lat: float = 0
    lon: float = 0
    speed: float = 0           # km/h
    heading: float = 0         # 0-360
    ignition: bool = True
    order_id: Optional[str] = None
    status: str = "idle"       # idle/driving/stopped/delivering
    ping_interval: float = 5.0 # 秒
    # 内部
    _leg_start_time: float = 0
    _leg_progress: float = 0
    _stay_until: float = 0
    _next_ping: float = 0


class GPSSimulator:
    """GPS 轨迹模拟器 — 管理多辆车同时模拟"""

    def __init__(self, seed: int = 42):
        self.rng = random.Random(seed)
        self.vehicles: dict[str, VehicleState] = {}
        self._active = False

    def create_delivery_route(self, scenario: str = "餐饮配送") -> list[dict]:
        """根据配送场景生成一条大连真实路线"""
        depot = self.rng.choice(DALIAN_LANDMARKS["depots"])

        if scenario in ("餐饮配送", "商超补货"):
            stops = self.rng.sample(
                DALIAN_LANDMARKS["restaurants"] + DALIAN_LANDMARKS["retail"],
                self.rng.randint(2, 4)
            )
        elif scenario == "生鲜冷链":
            market = self.rng.choice(DALIAN_LANDMARKS["markets"])
            stops = [market] + self.rng.sample(
                DALIAN_LANDMARKS["restaurants"] + DALIAN_LANDMARKS["retail"],
                self.rng.randint(1, 3)
            )
        elif scenario == "医药配送":
            stops = self.rng.sample(DALIAN_LANDMARKS["pharmacies"] + DALIAN_LANDMARKS["retail"],
                                    self.rng.randint(2, 4))
        elif scenario == "家具配送":
            stops = self.rng.sample(DALIAN_LANDMARKS["furniture"] + DALIAN_LANDMARKS["retail"],
                                    self.rng.randint(1, 2))
        else:
            stops = self.rng.sample(
                DALIAN_LANDMARKS["restaurants"] + DALIAN_LANDMARKS["retail"],
                self.rng.randint(2, 4)
            )

        route = [
            {"lat": depot["lat"], "lon": depot["lon"], "name": depot["name"],
             "type": "depot", "stay_sec": 0}
        ]
        for s in stops:
            route.append({
                "lat": s["lat"], "lon": s["lon"], "name": s["name"],
                "type": "delivery",
                "stay_sec": self.rng.randint(60, 300),  # 1-5分钟卸货
            })
        route.append({
            "lat": depot["lat"], "lon": depot["lon"], "name": depot["name"],
            "type": "return", "stay_sec": 0
        })
        return route

    def add_vehicle(self, vehicle_id: str, plate: str, driver: str,
                    scenario: str = "餐饮配送") -> VehicleState:
        """添加一辆车并分配路线"""
        route = self.create_delivery_route(scenario)
        start = route[0]
        vs = VehicleState(
            vehicle_id=vehicle_id,
            plate_number=plate,
            driver_name=driver,
            route=route,
            lat=start["lat"],
            lon=start["lon"],
            status="idle",
            order_id=str(uuid.uuid4())[:8],
        )
        self.vehicles[vehicle_id] = vs
        return vs

    def remove_vehicle(self, vehicle_id: str):
        self.vehicles.pop(vehicle_id, None)

    def start(self):
        """开始模拟"""
        self._active = True
        now = time.time()
        for vs in self.vehicles.values():
            vs._next_ping = now
            if len(vs.route) > 1:
                vs.status = "driving"
                vs.current_leg = 0
                vs._leg_start_time = now
                vs._leg_progress = 0

    def stop(self):
        self._active = False

    def tick(self) -> list[dict]:
        """推进一帧，返回本帧产生的 GPS ping 列表"""
        if not self._active:
            return []

        now = time.time()
        pings = []

        for vs in self.vehicles.values():
            if now < vs._next_ping:
                continue
            vs._next_ping = now + vs.ping_interval

            # 如果正在停留
            if vs.status == "stopped" and now < vs._stay_until:
                pings.append(self._make_ping(vs, now))
                continue
            elif vs.status == "stopped" and now >= vs._stay_until:
                # 停留结束，去下一站
                vs.current_leg += 1
                if vs.current_leg >= len(vs.route) - 1:
                    vs.status = "idle"
                    vs.ignition = False
                    pings.append(self._make_ping(vs, now))
                    continue
                vs.status = "driving"
                vs._leg_start_time = now
                vs._leg_progress = 0

            # 行驶中
            if vs.status == "idle":
                pings.append(self._make_ping(vs, now))
                continue

            current = vs.route[vs.current_leg]
            next_pt = vs.route[vs.current_leg + 1]

            # 计算距离和预估时间
            dist_km = _haversine(current["lat"], current["lon"],
                                 next_pt["lat"], next_pt["lon"])
            # 模拟城市道路速度：商圈内慢，跨区快
            avg_speed = self._simulate_speed(current, next_pt)
            travel_time = (dist_km / avg_speed) * 3600  # 秒

            elapsed = now - vs._leg_start_time
            vs._leg_progress = min(1.0, elapsed / travel_time)

            # 插值当前位置
            t = vs._leg_progress
            # 添加随机偏移模拟 GPS 漂移（±15米）
            jitter_lat = self.rng.gauss(0, 0.00015)
            jitter_lon = self.rng.gauss(0, 0.00015)
            vs.lat = current["lat"] + (next_pt["lat"] - current["lat"]) * t + jitter_lat
            vs.lon = current["lon"] + (next_pt["lon"] - current["lon"]) * t + jitter_lon

            # 速度模拟（加减速曲线）
            if t < 0.1:
                vs.speed = avg_speed * (t / 0.1) * self.rng.uniform(0.8, 1.2)
            elif t > 0.9:
                vs.speed = avg_speed * ((1 - t) / 0.1) * self.rng.uniform(0.8, 1.2)
            else:
                vs.speed = avg_speed * self.rng.uniform(0.85, 1.15)

            vs.heading = _bearing(current["lat"], current["lon"],
                                  next_pt["lat"], next_pt["lon"])
            vs.ignition = True

            if vs._leg_progress >= 1.0:
                # 到达
                vs.lat = next_pt["lat"] + jitter_lat
                vs.lon = next_pt["lon"] + jitter_lon
                vs.speed = 0
                next_type = next_pt.get("type", "")
                if next_type in ("delivery",):
                    vs.status = "stopped"
                    stay = next_pt.get("stay_sec", 120)
                    vs._stay_until = now + stay
                    vs.status = "stopped"
                elif next_type == "return":
                    vs.status = "idle"
                    vs.ignition = False
                else:
                    vs.current_leg += 1
                    vs._leg_start_time = now
                    vs._leg_progress = 0

            pings.append(self._make_ping(vs, now))

        return pings

    def _make_ping(self, vs: VehicleState, ts: float) -> dict:
        return {
            "time": datetime.fromtimestamp(ts).isoformat(),
            "vehicle_id": vs.vehicle_id,
            "driver_id": None,
            "latitude": round(vs.lat, 7),
            "longitude": round(vs.lon, 7),
            "speed_kmh": round(vs.speed, 1),
            "heading": int(vs.heading),
            "accuracy_m": round(self.rng.uniform(3, 15), 1),
            "ignition": vs.ignition,
            "order_id": vs.order_id,
            "status": vs.status,
            "plate_number": vs.plate_number,
            "driver_name": vs.driver_name,
        }

    def _simulate_speed(self, a: dict, b: dict) -> float:
        """模拟城市道路车速"""
        dist = _haversine(a["lat"], a["lon"], b["lat"], b["lon"])
        a_type = a.get("type", "")
        b_type = b.get("type", "")

        # 核心商圈低速
        a_in_downtown = 38.90 < a["lat"] < 38.93 and 121.58 < a["lon"] < 121.65
        b_in_downtown = 38.90 < b["lat"] < 38.93 and 121.58 < b["lon"] < 121.65

        if a_in_downtown or b_in_downtown:
            base = self.rng.uniform(15, 25)  # 商圈拥堵
        elif dist > 15:
            base = self.rng.uniform(50, 70)  # 跨区快速路
        elif dist > 5:
            base = self.rng.uniform(35, 55)  # 主干道
        else:
            base = self.rng.uniform(20, 35)  # 一般道路

        # 雨天/雪天减速（随机模拟）
        if self.rng.random() < 0.1:
            base *= 0.7
        return base


# ============================================================
# 地理工具函数
# ============================================================

def _haversine(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Haversine 距离 (km)"""
    R = 6371
    dlat = math.radians(lat2 - lat1)
    dlon = math.radians(lon2 - lon1)
    a = math.sin(dlat/2)**2 + math.cos(math.radians(lat1)) * \
        math.cos(math.radians(lat2)) * math.sin(dlon/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))


def _bearing(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """方位角 (0-360)"""
    dlon = math.radians(lon2 - lon1)
    lat1r = math.radians(lat1)
    lat2r = math.radians(lat2)
    x = math.sin(dlon) * math.cos(lat2r)
    y = math.cos(lat1r) * math.sin(lat2r) - math.sin(lat1r) * math.cos(lat2r) * math.cos(dlon)
    brg = math.degrees(math.atan2(x, y))
    return (brg + 360) % 360
