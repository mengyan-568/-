"""
GPS 追踪服务 — 管理模拟器和数据库的桥接层

职责:
  - 启动/停止 GPS 模拟器
  - 将 ping 数据写入数据库
  - 提供实时车辆位置查询
  - 兼容 Traccar OsmAnd 协议（将来可直接替换为真 Traccar 服务）
"""
import json
import threading
import time
import uuid
from datetime import datetime

from database import execute, execute_write, execute_many

from .simulator import GPSSimulator


class TrackingService:
    """GPS 追踪服务（单例）"""

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._initialized = True
        self.simulator = GPSSimulator()
        self._thread = None  # type: Optional[threading.Thread]
        self._running = False
        self._ping_buffer: list[dict] = []
        self._flush_interval = 2.0  # 每2秒批量写入数据库
        self._last_flush = time.time()
        self._stats = {
            "total_pings": 0,
            "active_vehicles": 0,
            "started_at": None,
        }

    def start(self, vehicle_ids: list[str] = None):
        """启动追踪服务

        如果没有指定车辆，自动从数据库加载已注册车辆。
        """
        if self._running:
            return

        # 加载车辆
        if vehicle_ids:
            rows = execute(
                f"SELECT id, plate_number FROM vehicles WHERE id IN ({','.join(['?']*len(vehicle_ids))})",
                tuple(vehicle_ids)
            )
        else:
            rows = execute("SELECT id, plate_number FROM vehicles WHERE status != 'maintenance' LIMIT 5")

        if not rows:
            # 没有真实车辆，创建演示车辆
            self._ensure_demo_vehicles()
            rows = execute("SELECT id, plate_number FROM vehicles LIMIT 5")

        # 获取司机
        drivers = execute("SELECT id, name FROM drivers LIMIT 5")
        driver_names = [d.get("name", "司机") for d in drivers] if drivers else ["王德发", "李国强", "张大军", "赵永强", "刘明辉"]

        # 为每辆车分配路线和司机
        scenarios = ["餐饮配送", "生鲜冷链", "医药配送", "商超补货", "家具配送"]
        for i, row in enumerate(rows):
            vid = row.get("id", "")
            plate = row.get("plate_number", f"辽B·TEST{i}")
            driver = driver_names[i % len(driver_names)]
            scenario = scenarios[i % len(scenarios)]
            self.simulator.add_vehicle(vid, plate, driver, scenario)

        self.simulator.start()
        self._running = True
        self._stats["started_at"] = datetime.now().isoformat()
        self._stats["active_vehicles"] = len(self.simulator.vehicles)

        # 启动后台线程
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()

        print(f"[Tracking] Started with {len(self.simulator.vehicles)} vehicles")

    def stop(self):
        """停止追踪服务"""
        self._running = False
        self.simulator.stop()
        if self._thread:
            self._thread.join(timeout=5)
        # 最终 flush
        self._flush_to_db()
        print(f"[Tracking] Stopped. Total pings: {self._stats['total_pings']}")

    def get_live_positions(self) -> list[dict]:
        """获取所有车辆的最新位置"""
        positions = []
        for vid, vs in self.simulator.vehicles.items():
            positions.append({
                "vehicle_id": vid,
                "plate_number": vs.plate_number,
                "driver_name": vs.driver_name,
                "latitude": vs.lat,
                "longitude": vs.lon,
                "speed_kmh": vs.speed,
                "heading": vs.heading,
                "ignition": vs.ignition,
                "status": vs.status,
                "order_id": vs.order_id,
            })
        return positions

    def get_stats(self) -> dict:
        """获取追踪统计"""
        return {
            **self._stats,
            "buffered_pings": len(self._ping_buffer),
            "running": self._running,
        }

    def _ensure_demo_vehicles(self):
        """确保数据库中有演示车辆"""
        existing = execute("SELECT COUNT(*) as cnt FROM vehicles")
        cnt = list(existing[0].values())[0] if existing else 0
        if cnt == 0:
            vehicles = [
                (str(uuid.uuid4()), "辽B·12345", "面包车", "五菱荣光"),
                (str(uuid.uuid4()), "辽B·23456", "4.2m厢货", "福田奥铃"),
                (str(uuid.uuid4()), "辽B·34567", "冷藏车", "解放J6F"),
                (str(uuid.uuid4()), "辽B·45678", "平板车", "东风天锦"),
                (str(uuid.uuid4()), "辽B·56789", "面包车", "长安之星"),
            ]
            for v in vehicles:
                try:
                    execute_write(
                        "INSERT INTO vehicles (id, plate_number, vehicle_type, brand_model) VALUES (?,?,?,?)", v
                    )
                except Exception:
                    pass

    def _run_loop(self):
        """后台循环：tick 模拟器 → 写入缓冲区 → 定期 flush"""
        ping_interval = 1.0  # tick 频率

        while self._running:
            try:
                pings = self.simulator.tick()
                if pings:
                    self._ping_buffer.extend(pings)
                    self._stats["total_pings"] += len(pings)

                # 定期 flush 到数据库
                now = time.time()
                if now - self._last_flush >= self._flush_interval and self._ping_buffer:
                    self._flush_to_db()
                    self._last_flush = now

                time.sleep(ping_interval)
            except Exception as e:
                print(f"[Tracking] Error in loop: {e}")
                time.sleep(1)

    def _flush_to_db(self):
        """批量写入 GPS ping 到数据库"""
        if not self._ping_buffer:
            return

        # 只保留最近 200 条避免内存膨胀
        to_write = self._ping_buffer[-200:]
        self._ping_buffer = []

        rows = []
        for p in to_write:
            rows.append((
                str(uuid.uuid4()),
                p["time"],
                p["vehicle_id"],
                None,
                p["latitude"],
                p["longitude"],
                p["speed_kmh"],
                p["heading"],
                p["accuracy_m"],
                p["ignition"],
                p.get("order_id"),
                json.dumps({"status": p.get("status", ""),
                            "driver": p.get("driver_name", ""),
                            "plate": p.get("plate_number", "")},
                           ensure_ascii=False)
            ))

        try:
            execute_many(
                """INSERT INTO gps_pings (id, time, vehicle_id, driver_id, latitude, longitude,
                   speed_kmh, heading, accuracy_m, ignition, order_id, extra)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                rows
            )
        except Exception as e:
            print(f"[Tracking] DB write error: {e}")


# 全局单例
_tracking_service = None  # type: Optional[TrackingService]


def get_tracking_service() -> TrackingService:
    global _tracking_service
    if _tracking_service is None:
        _tracking_service = TrackingService()
    return _tracking_service
