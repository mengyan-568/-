# 洞见 Foresight — 持久化启动脚本 (PowerShell)
# 双击运行，窗口保持常驻，崩溃自动重启

$Host.UI.RawUI.WindowTitle = "洞见 Foresight Server"

Set-Location "D:\Desktop\painpoint-engine\backend"

$restartCount = 0

while ($true) {
    $restartCount++
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host " 洞见 Foresight Server" -ForegroundColor Yellow
    Write-Host " 第 $restartCount 次启动 | $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor Gray
    Write-Host " 访问: http://127.0.0.1:8000" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Cyan

    $process = Start-Process -FilePath "python" `
        -ArgumentList "-m", "uvicorn", "main:app", "--host", "127.0.0.1", "--port", "8000", "--reload" `
        -NoNewWindow -Wait -PassThru

    $exitCode = $process.ExitCode
    Write-Host "服务器已停止 (exit code: $exitCode)" -ForegroundColor Red
    Write-Host "3 秒后自动重启..." -ForegroundColor Yellow
    Start-Sleep -Seconds 3
}
