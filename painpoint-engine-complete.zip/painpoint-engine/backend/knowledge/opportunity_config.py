"""
商机挖掘数据源与产物配置（v4 扩展）

补充 dalian_delivery.py 中已有的领域知识，新增：
  - 数据源配置（公开 + 半公开）
  - 产物配置（四大产物体系）
  - 落地路径规划
"""

DATA_SOURCE_CONFIG = {
    "public_sources": {
        "货拉拉/快狗/运满满": {
            "type": "公开数据源",
            "data_items": ["车型报价", "起步价", "里程计价", "等候费", "附加费"],
            "collection_method": "爬取公开报价页/API",
            "update_frequency": "每周",
            "priority": "高",
            "usage": "竞品价格对标、定价策略参考",
        },
        "58同城/赶集网": {
            "type": "公开数据源",
            "data_items": ["个体司机信息", "小车队信息", "常跑路线", "报价区间"],
            "collection_method": "爬取本地货运版块",
            "update_frequency": "每周",
            "priority": "高",
            "usage": "运力地图、本地运力摸底",
        },
        "天眼查/企查查": {
            "type": "公开数据源",
            "data_items": ["企业名称", "注册资本", "成立时间", "社保人数", "经营范围"],
            "collection_method": "API/爬虫",
            "update_frequency": "每月",
            "priority": "高",
            "usage": "企业清单、运力供给端摸底",
        },
        "招标网站": {
            "type": "公开数据源",
            "data_items": ["招标标题", "招标方", "配送需求", "预算范围", "截止日期"],
            "collection_method": "RSS/爬虫/API",
            "update_frequency": "每日",
            "priority": "极高",
            "usage": "需求端发现、商机企业清单",
        },
        "高德/百度地图POI": {
            "type": "公开数据源",
            "data_items": ["批发市场", "物流园", "仓储区", "商圈", "建材市场"],
            "collection_method": "地图API",
            "update_frequency": "每月",
            "priority": "中",
            "usage": "需求热力图、配送路线规划",
        },
    },
    "semi_public_sources": {
        "招聘网站（BOSS直聘/前程无忧）": {
            "type": "半公开数据源",
            "data_items": ["配送司机招聘", "车型要求", "招聘数量", "薪资范围"],
            "collection_method": "爬虫/API",
            "update_frequency": "每周",
            "priority": "高",
            "usage": "业务扩张信号、车型需求反推",
        },
        "抖音/快手": {
            "type": "半公开数据源",
            "data_items": ["车队运营视频", "实际车型", "常跑路线", "客户类型"],
            "collection_method": "关键词搜索/API",
            "update_frequency": "每周",
            "priority": "中",
            "usage": "运力供给验证、车队发现",
        },
        "加油站/充电桩": {
            "type": "半公开数据源",
            "data_items": ["柴油站分布", "充电桩分布", "加油频次"],
            "collection_method": "加油站网络API/充电桩平台API",
            "update_frequency": "每月",
            "priority": "低",
            "usage": "配送热力路线推断",
        },
        "交通违章公开数据": {
            "type": "半公开数据源",
            "data_items": ["货运车辆违章路段", "违停热点", "限行违章"],
            "collection_method": "交管公开数据/第三方交通大数据",
            "update_frequency": "每季度",
            "priority": "低",
            "usage": "高频配送路线推断、限行规避",
        },
    },
}

PRODUCT_CONFIG = {
    "运力地图": {
        "description": "大连同城配送供给端全景摸底",
        "key_fields": ["企业名称", "类型", "自有车型", "常跑路线", "报价区间", "运力规模"],
        "data_sources": ["天眼查/企查查", "58同城/赶集网", "抖音/快手"],
        "update_frequency": "每月",
        "target_users": ["市场拓展团队", "运营团队"],
    },
    "需求热力图": {
        "description": "大连各区域/行业的配送需求强度和特征",
        "key_fields": ["区域", "行业", "需求强度", "推荐车型", "配送特征", "痛点"],
        "data_sources": ["高德/百度地图POI", "招标网站", "招聘网站"],
        "update_frequency": "每月",
        "target_users": ["市场拓展团队", "运力规划团队"],
    },
    "竞品价格对标表": {
        "description": "货拉拉/快狗/滴滴货运/本地车队价格横向对比",
        "key_fields": ["车型", "各平台起步价", "超公里单价", "附加费", "月结参考价"],
        "data_sources": ["货拉拉/快狗/运满满"],
        "update_frequency": "每周",
        "target_users": ["定价团队", "销售团队"],
    },
    "商机企业清单": {
        "description": "最需要同城配送服务的目标企业，含车型/路线/价格/触达策略",
        "key_fields": ["企业名称", "行业", "配送需求", "推荐车型", "推荐路线", "价格估算", "触达策略"],
        "data_sources": ["招标网站", "招聘网站", "天眼查/企查查", "Web搜索"],
        "update_frequency": "每周",
        "target_users": ["销售团队", "BD团队"],
    },
}

IMPLEMENTATION_ROADMAP = {
    "week1": {
        "title": "运力供给摸底",
        "tasks": [
            "从天眼查导出大连本地注册的物流配送企业（500-800家）",
            "抓取货拉拉大连公开报价页，形成价格基准线",
            "抓取58同城大连货运版块，提取个体司机/小车队信息",
        ],
        "deliverables": ["运力底表", "价格基准线"],
    },
    "week2": {
        "title": "需求端发现",
        "tasks": [
            "从招聘数据中提取配送司机招聘信号，标注需求强度",
            "从招标公告中提取配送需求信息",
            "基于POI数据生成需求热力图",
        ],
        "deliverables": ["需求信号清单", "需求热力图"],
    },
    "week3": {
        "title": "交叉匹配与商机输出",
        "tasks": [
            "交叉匹配：招聘信号 + 天眼查扩张信号 = 高价值商机",
            "生成商机企业清单（含车型/路线/价格/触达策略）",
            "生成竞品价格对标表",
        ],
        "deliverables": ["商机企业清单", "竞品价格对标表"],
    },
    "ongoing": {
        "title": "持续运营",
        "tasks": [
            "定时任务：每周更新商机清单",
            "定时任务：每周更新竞品价格",
            "定时任务：每月更新运力地图和需求热力图",
            "数据质量监控和人工校验",
        ],
        "deliverables": ["自动化商机周报", "价格变动预警"],
    },
}
