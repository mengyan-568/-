"""
AI 分析 API — 基于产物数据生成智能洞察

提供:
  - POST /api/ai/analyze — 基于四大产物数据运行 AI 分析
  - GET  /api/ai/status   — 检查 AI Provider 可用状态
"""
import json
import logging
from datetime import datetime
from typing import Optional

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

from collectors.products import ProductGenerator

logger = logging.getLogger("ai_api")

router = APIRouter(prefix="/api/ai", tags=["AI 分析"])


class AIAnalyzeRequest(BaseModel):
    keyword: str = "餐饮配送"
    city: str = "大连"


@router.get("/status")
def ai_status():
    """检查 AI Provider 可用状态"""
    providers_status = {}
    try:
        from llm.provider import AIAnalyzer
        analyzer = AIAnalyzer()
        for p in analyzer._providers:
            providers_status[p.name()] = {
                "available": p.available(),
                "name": p.name(),
            }
        any_available = any(v["available"] for v in providers_status.values())
    except ImportError:
        providers_status = {"error": "LLM module not importable"}
        any_available = False

    return {
        "checked_at": datetime.now().isoformat(),
        "ai_available": any_available,
        "providers": providers_status,
        "note": "设置 GEMINI_API_KEY 环境变量启用 Gemini；或启动 Ollama 本地服务启用 Qwen3",
    }


@router.post("/analyze")
def run_ai_analysis(req: AIAnalyzeRequest):
    """
    基于四大产物数据运行 AI 深度分析。

    分析维度:
      - 执行摘要 (headline + summary)
      - SWOT 分析 (优势/劣势/机会/威胁)
      - 市场策略 (定位/区域扩展/定价/差异化)
      - 竞争差距 (现有玩家弱点/差异化机会/市场切入点)
      - 90天行动路线图
      - ROI 潜力评估
    """
    keyword = req.keyword
    city = req.city

    # 1. 生成四大产物作为分析基础数据
    gen = ProductGenerator(city=city)
    capacity = gen.generate_capacity_map()
    demand = gen.generate_demand_heatmap()
    benchmark = gen.generate_competitive_benchmark()
    opp_list = gen.generate_opportunity_list(keyword=keyword)

    opportunities = opp_list.get("opportunities", [])
    providers = capacity.get("capacity_providers", [])
    zones = demand.get("demand_zones", [])
    vehicles = benchmark.get("vehicle_comparison", [])

    # 2. 构建分析上下文
    stats = {
        "total_providers": len(providers),
        "total_zones": len(zones),
        "total_opportunities": len(opportunities),
        "total_vehicles": len(vehicles),
    }

    # 构建行业信息摘要
    industry_info_parts = []
    industry_info_parts.append(f"## 运力供给端")
    for p in providers[:5]:
        vtypes = ", ".join(f"{v['model']}×{v['count']}" for v in p.get("vehicle_types", [])[:2])
        industry_info_parts.append(f"- {p['name']} ({p['type']}): {vtypes}, {p.get('capacity_scale', '')}")
        industry_info_parts.append(f"  优势: {p.get('strength', '')} | 劣势: {p.get('weakness', '')}")

    industry_info_parts.append("\n## 需求端")
    for z in zones[:4]:
        features = z.get("demand_features", {})
        top_f = list(features.keys())[0] if features else ""
        industry_info_parts.append(f"- {z['zone']} ({z['demand_intensity']}): {', '.join(z.get('industries', []))}")

    industry_info_parts.append("\n## 竞品价格")
    for v in vehicles[:4]:
        hl = v.get("货拉拉", {}).get("起步价", "N/A")
        kg = v.get("快狗打车", {}).get("起步价", "N/A")
        industry_info_parts.append(f"- {v['车型']}: 货拉拉 {hl}, 快狗 {kg}")

    industry_info = "\n".join(industry_info_parts)

    # 格式化商机列表
    opps_formatted = []
    for opp in opportunities[:8]:
        opps_formatted.append({
            "name": opp.get("name", ""),
            "industry": opp.get("industry", ""),
            "demand": opp.get("delivery_need", ""),
            "intensity": opp.get("demand_intensity", ""),
            "urgency": opp.get("urgency", ""),
            "value": opp.get("estimated_annual_value", ""),
            "vehicle": (opp.get("recommended_vehicle") or {}).get("primary", ""),
            "route": (opp.get("recommended_route") or {}).get("main", ""),
        })

    # 格式化企业列表
    companies_formatted = []
    for p in providers:
        companies_formatted.append({
            "name": p.get("name", ""),
            "type": p.get("type", ""),
            "strength": p.get("strength", ""),
            "weakness": p.get("weakness", ""),
        })

    # 3. 尝试运行 AI 分析
    ai_results = {}
    ai_available = False

    try:
        from llm.provider import AIAnalyzer
        from llm import prompts
        from knowledge.dalian_delivery import get_scenario_profile

        analyzer = AIAnalyzer()
        ai_available = any(p.available() for p in analyzer._providers)

        if ai_available:
            profile = get_scenario_profile(keyword)
            logger.info("Starting AI analysis for keyword=%s", keyword)

            tasks = [
                ("executive_summary", *prompts.executive_summary_prompt(
                    keyword, stats, opps_formatted[:5], "")),
                ("swot", *prompts.swot_prompt(
                    keyword, opps_formatted[:5], industry_info, profile)),
                ("strategy", *prompts.strategy_prompt(
                    keyword, opps_formatted[:5], profile)),
                ("competitor_gap", *prompts.competitor_gap_prompt(
                    keyword, opps_formatted[:5], companies_formatted, industry_info)),
                ("action_plan", *prompts.action_plan_prompt(
                    keyword, opps_formatted[:5], profile, companies_formatted)),
                ("roi", *prompts.roi_prompt(
                    keyword, companies_formatted, profile, opps_formatted[:5])),
            ]

            ai_results = analyzer.analyze_all(tasks)
            logger.info("AI analysis complete: %d/%d sections", len(ai_results), len(tasks))
        else:
            logger.info("No AI provider available, using rule-based fallback")
    except ImportError as e:
        logger.info("LLM module not available: %s", str(e))
    except Exception as e:
        logger.error("AI analysis failed: %s", str(e))

    # 4. 规则引擎兜底分析（当 AI 不可用时）
    fallback = _generate_fallback_analysis(keyword, opportunities, providers, zones, vehicles)

    return {
        "keyword": keyword,
        "city": city,
        "analyzed_at": datetime.now().isoformat(),
        "ai_available": ai_available,
        "ai_analysis": {
            "executive_summary": ai_results.get("executive_summary", fallback["executive_summary"]),
            "swot": ai_results.get("swot", fallback["swot"]),
            "strategy": ai_results.get("strategy", fallback["strategy"]),
            "competitor_gap": ai_results.get("competitor_gap", fallback["competitor_gap"]),
            "action_plan": ai_results.get("action_plan", fallback["action_plan"]),
            "roi": ai_results.get("roi", fallback["roi"]),
        },
        "data_context": {
            "stats": stats,
            "top_opportunities": opps_formatted[:5],
            "top_providers": companies_formatted[:5],
        },
    }


def _generate_fallback_analysis(keyword, opportunities, providers, zones, vehicles):
    """规则引擎兜底分析 — 当 AI 不可用时提供基础洞察"""
    urgency_high = sum(1 for o in opportunities if o.get("urgency") == "高")
    urgency_total = len(opportunities)
    top_industries = list(set(o.get("industry", "") for o in opportunities[:5]))
    total_value = "¥880-2280万"

    return {
        "executive_summary": {
            "headline": f"大连{keyword}市场：{urgency_high}/{urgency_total}家目标企业为高紧迫度商机",
            "summary": (
                f"基于对大连{keyword}市场的全景扫描，共识别 {urgency_total} 家目标企业，"
                f"其中 {urgency_high} 家为高紧迫度商机。"
                f"主要机会集中在 {', '.join(top_industries[:3])} 领域。"
                f"当前市场运力供给分散，专业冷链运力不足，存在明显的整合机会。"
                f"建议优先攻克高紧迫度企业，以标杆案例撬动行业复制。"
            ),
        },
        "swot": {
            "strengths": [
                "大连本地市场熟悉度高，了解各区域限行/路况/商圈特征",
                "可整合本地分散运力，提供比平台更低的价格",
                "提供标准化服务+SLA保障，区别于个体司机",
                "深耕垂直行业（餐饮/生鲜/医药），建立专业壁垒",
            ],
            "weaknesses": [
                "品牌知名度远低于货拉拉/快狗等平台",
                "初期运力规模有限，难以覆盖全城即时需求",
                "信息系统建设需要投入，短期难以匹敌大平台",
                "客户信任建立周期长，需要标杆案例背书",
            ],
            "opportunities": [
                f"{keyword}市场需求旺盛，平台抽成高（15-25%），存在价格优势空间",
                "专业冷链运力严重不足，大连仅20+台冷藏车，供需缺口大",
                "本地小车队分散（200-300家），缺乏整合者",
                "樱桃季/海鲜季/旅游旺季等季节性爆发，运力缺口30-60%",
                "医药GSP合规配送门槛高，竞争者少，利润空间大",
            ],
            "threats": [
                "货拉拉/快狗等平台可能通过补贴压低价格",
                "经济下行导致企业削减配送预算",
                "冬季暴雪导致运力瘫痪，SLA违约风险",
                "司机招聘难，春节返乡导致运力断崖式下跌",
            ],
        },
        "strategy": {
            "positioning": f"大连{keyword}领域的「专业B端配送服务商」— 比平台便宜15%，比个体可靠10倍",
            "geo_rollout": [
                "Phase 1: 中山区+沙河口区（核心商圈，需求密度最高）",
                "Phase 2: 甘井子区+高新园区（仓储带+写字楼密集区）",
                "Phase 3: 金州/开发区+旅顺（工业品+季节性农产品）",
            ],
            "pricing_strategy": "比平台低10-15%（省去平台抽成），比本地车队高5-10%（提供标准化服务）。核心差异化：一口价+月结+SLA保障。",
            "key_differentiators": [
                "行业定制化方案（餐饮/生鲜/医药各有专属SOP）",
                "全程温控+合规资质（GSP认证冷链）",
                "一口价透明定价，消除隐性收费",
                "专属客户经理+7×24小时响应",
            ],
        },
        "competitor_gap": {
            "incumbent_weaknesses": [
                "货拉拉/快狗：B端定制化能力弱，平台抽成高，无行业专属方案",
                "顺丰/京东：价格偏高，不提供非自有体系外配送",
                "本地车队：无信息系统，服务质量不稳定，无SLA保障",
                "专业冷链公司：同城末端配送能力弱，覆盖范围有限",
            ],
            "differentiation_opportunities": [
                "行业定制化SOP（餐饮午晚市deadline/医药GSP合规/生鲜全程温控）",
                "整合本地分散运力+标准化管理=规模化B端服务能力",
                "一口价+月结模式，消除平台隐性收费痛点",
                "标杆客户案例驱动行业复制（拿下1家连锁→撬动整个行业）",
            ],
            "market_entry_angle": f"以{top_industries[0] if top_industries else keyword}行业为切入点，用标杆案例建立口碑，逐步扩展到相邻行业。核心策略：不跟平台拼广度，拼行业深度。",
        },
        "action_plan": {
            "items": [
                {"phase": "Phase 1 (0-30天)", "action": "锁定3-5家高紧迫度目标企业，提供免费试用期", "expected_impact": "建立标杆案例", "difficulty": "中"},
                {"phase": "Phase 1 (0-30天)", "action": "整合10-15台本地运力（面包车+冷藏车），签订合作协议", "expected_impact": "形成基础运力池", "difficulty": "中"},
                {"phase": "Phase 2 (30-60天)", "action": "上线调度系统MVP，支持订单管理+温控记录+签收", "expected_impact": "标准化服务能力", "difficulty": "高"},
                {"phase": "Phase 2 (30-60天)", "action": "以标杆案例撬动同行业5-10家客户", "expected_impact": "规模化复制", "difficulty": "中"},
                {"phase": "Phase 3 (60-90天)", "action": "扩展至第二行业（如从餐饮扩展到生鲜冷链）", "expected_impact": "行业多元化", "difficulty": "高"},
                {"phase": "Phase 3 (60-90天)", "action": "运力池扩展至30-50台，覆盖全城6个需求区域", "expected_impact": "规模化运营", "difficulty": "高"},
            ],
        },
        "roi": {
            "estimated_market_size": f"大连{keyword}B端配送市场年规模约{total_value}/年（可见商机），全行业估计5000万-1亿/年",
            "addressable_share_pct": 15.0,
            "revenue_potential": f"首年目标营收750-1500万（15%市场份额），毛利率25-35%",
            "key_assumptions": [
                "首年攻克10-15家B端客户，平均客单价50-100万/年",
                "运力以整合本地车辆为主（轻资产），车辆成本为变动成本",
                "信息系统和调度团队为固定成本，预计月均15-25万",
                "第2年起通过行业复制实现50%+增长",
            ],
        },
    }
