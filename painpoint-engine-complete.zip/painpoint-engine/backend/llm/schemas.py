"""Pydantic models for structured LLM outputs."""

from pydantic import BaseModel


class SWOTAnalysis(BaseModel):
    strengths: list[str]
    weaknesses: list[str]
    opportunities: list[str]
    threats: list[str]


class MarketStrategy(BaseModel):
    positioning: str
    geo_rollout: list[str]
    pricing_strategy: str
    key_differentiators: list[str]


class ActionItem(BaseModel):
    phase: str
    action: str
    expected_impact: str
    difficulty: str


class ActionPlan(BaseModel):
    items: list[ActionItem]


class ROIAssessment(BaseModel):
    estimated_market_size: str
    addressable_share_pct: float
    revenue_potential: str
    key_assumptions: list[str]


class ExecutiveSummary(BaseModel):
    summary: str
    headline: str


class CompetitorGap(BaseModel):
    incumbent_weaknesses: list[str]
    differentiation_opportunities: list[str]
    market_entry_angle: str
