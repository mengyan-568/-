"""
AI Provider layer with automatic fallback chain.

Gemini 2.5 Flash (free) → Ollama Qwen3 (local) → template fallback.
"""

import os
import json
import logging
from abc import ABC, abstractmethod
from concurrent.futures import ThreadPoolExecutor, as_completed

logger = logging.getLogger("llm")


class LLMProvider(ABC):
    @abstractmethod
    def name(self) -> str:
        ...

    @abstractmethod
    def available(self) -> bool:
        ...

    @abstractmethod
    def generate(self, system_prompt: str, user_prompt: str, timeout: int = 30):
        ...


class GeminiProvider(LLMProvider):
    def __init__(self):
        self._api_key = os.environ.get("GEMINI_API_KEY", "")
        self._model = None

    def name(self) -> str:
        return "Gemini 2.5 Flash"

    def available(self) -> bool:
        return bool(self._api_key)

    def _get_model(self):
        if self._model is None and self._api_key:
            try:
                import google.generativeai as genai
                genai.configure(api_key=self._api_key)
                self._model = genai.GenerativeModel("gemini-2.5-flash")
            except Exception as e:
                logger.warning(f"Gemini init failed: {e}")
        return self._model

    def generate(self, system_prompt: str, user_prompt: str, timeout: int = 30):
        model = self._get_model()
        if not model:
            return None
        try:
            full_prompt = f"{system_prompt}\n\n---\n\n{user_prompt}"
            response = model.generate_content(
                full_prompt,
                generation_config={
                    "response_mime_type": "application/json",
                    "temperature": 0.3,
                },
                request_options={"timeout": timeout * 1000},
            )
            text = response.text.strip()
            if text.startswith("```"):
                text = text.split("\n", 1)[1].rsplit("```", 1)[0]
            return json.loads(text)
        except Exception as e:
            logger.warning(f"Gemini generate failed: {e}")
            return None


class OllamaProvider(LLMProvider):
    def __init__(self):
        self._model_name = os.environ.get("OLLAMA_MODEL", "qwen3:14b")
        self._available = None

    def name(self) -> str:
        return f"Ollama {self._model_name}"

    def available(self) -> bool:
        if self._available is None:
            try:
                import ollama
                ollama.list()
                self._available = True
            except Exception:
                self._available = False
        return self._available

    def generate(self, system_prompt: str, user_prompt: str, timeout: int = 60):
        if not self.available():
            return None
        try:
            import ollama
            response = ollama.chat(
                model=self._model_name,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                format="json",
                options={"temperature": 0.3, "num_ctx": 8192},
            )
            return json.loads(response["message"]["content"])
        except Exception as e:
            logger.warning(f"Ollama generate failed: {e}")
            return None



class DeepSeekProvider(LLMProvider):
    """DeepSeek API Provider — 支持 deepseek-chat / deepseek-reasoner"""

    def __init__(self):
        self._api_key = os.environ.get("DEEPSEEK_API_KEY", "")
        self._model = os.environ.get("DEEPSEEK_MODEL", "deepseek-chat")
        self._base_url = os.environ.get("DEEPSEEK_BASE_URL", "https://api.deepseek.com")

    def name(self) -> str:
        return f"DeepSeek ({self._model})"

    def available(self) -> bool:
        return bool(self._api_key)

    def generate(self, system_prompt: str, user_prompt: str, timeout: int = 60):
        if not self._api_key:
            return None
        try:
            import urllib.request
            import urllib.error

            payload = json.dumps({
                "model": self._model,
                "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                "temperature": 0.3,
                "max_tokens": 4096,
                "response_format": {"type": "json_object"},
            }).encode("utf-8")

            req = urllib.request.Request(
                f"{self._base_url}/v1/chat/completions",
                data=payload,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {self._api_key}",
                },
                method="POST",
            )

            with urllib.request.urlopen(req, timeout=timeout) as resp:
                result = json.loads(resp.read().decode("utf-8"))
                text = result["choices"][0]["message"]["content"].strip()
                if text.startswith("```"):
                    text = text.split("\n", 1)[1].rsplit("```", 1)[0]
                return json.loads(text)
        except Exception as e:
            logger.warning(f"DeepSeek generate failed: {e}")
            return None


class AIAnalyzer:
    """Orchestrates AI analysis with fallback chain."""

    def __init__(self):
        self._providers = [DeepSeekProvider(), GeminiProvider(), OllamaProvider()]

    def analyze(self, system_prompt: str, user_prompt: str, timeout: int = 45):
        for provider in self._providers:
            if not provider.available():
                logger.info(f"Provider {provider.name()} not available, skipping")
                continue
            logger.info(f"Trying {provider.name()}...")
            result = provider.generate(system_prompt, user_prompt, timeout=timeout)
            if result:
                logger.info(f"{provider.name()} succeeded")
                return result
            logger.warning(f"{provider.name()} returned None")
        return None

    def analyze_all(self, tasks):
        """
        Run multiple analysis tasks in parallel.

        Args:
            tasks: list of (name, system_prompt, user_prompt)

        Returns:
            dict mapping task name → result (or None)
        """
        results = {}

        def _run(name, sys_p, usr_p):
            return name, self.analyze(sys_p, usr_p)

        with ThreadPoolExecutor(max_workers=3) as pool:
            futures = {pool.submit(_run, n, s, u): n for n, s, u in tasks}
            for future in as_completed(futures):
                try:
                    name, result = future.result()
                    if result:
                        results[name] = result
                except Exception as e:
                    logger.warning(f"Task failed: {e}")

        return results
