"""
Prompt templates for AI-powered business analysis.

Each function returns (system_prompt, user_prompt) tuples.
All prompts are in Chinese, targeting logistics company decision-makers.
"""

SYSTEM_PROMPT = """你是「洞见 Foresight」平台的资深商业策略分析师，专精于中国同城配送和最后一公里物流。

你的核心能力：
1. 基于真实用户评论数据，发现市场中未被满足的需求
2. 生成专业、数据驱动的商业分析报告
3. 为物流企业提供可执行的战略建议

输出规则：
- 必须严格使用中文
- 语气专业、自信、数据驱动，像麦肯锡咨询报告
- 目标受众是物流企业老板/决策者，让他们产生"这就是我要找的机会"的冲动
- 对于基于有限数据推断的结论，标注 [基于有限数据推断]
- 不要使用模糊表述（如"可能""也许"），用数据说话
- 每个结论都要有具体的、可执行的支撑
- 输出必须是合法的 JSON"""


def executive_summary_prompt(keyword: str, stats: dict, top_opps: list, scenario: str) -> tuple:
    user = f"""## 任务：生成执行摘要

### 分析数据
- **关键词/场景**：{keyword}
- **分析评论总数**：{stats.get('total_reviews', 0)} 条
- **负面评论占比**：{stats.get('negativity_rate', 0) * 100:.1f}%
- **Top 3 痛点**：
{_format_opps(top_opps[:3])}

### 要求
生成一份让物流企业老板眼前一亮的执行摘要。包含：
1. **标题级判断**（headline）：一句话点出最大的商业机会
2. **摘要正文**（summary）：2-3 句话，涵盖数据洞察 + 核心商机 + 行动方向

请输出 JSON：
{{"headline": "标题", "summary": "摘要正文"}}"""
    return SYSTEM_PROMPT, user


def swot_prompt(keyword: str, opps: list, industry_info: str, profile: dict) -> tuple:
    regulations = profile.get("regulations", [])
    competitive_gap = profile.get("competitive_gap", "")
    seasonal = profile.get("seasonal_factors", [])

    user = f"""## 任务：SWOT 分析 — 新进入者的战略评估

### 背景
一个物流企业计划进入「{keyword}」市场（大连地区）。请基于以下真实数据做 SWOT 分析。

### 市场数据
- **Top 痛点（来自真实评论）**：
{_format_opps(opps[:5])}

- **行业信息**：{industry_info[:500] if industry_info else '暂无'}
- **行业合规要求**：{', '.join(regulations) if regulations else '无特殊要求'}
- **竞争格局**：{competitive_gap}
- **季节性因素**：{', '.join(seasonal) if seasonal else '无明显季节性'}

### 要求
SWOT 分析要基于真实评论数据，不是泛泛而谈：
- **S（优势）**：新进入者相对于现有玩家的优势（从现有玩家的差评中找）
- **W（劣势）**：新进入者面临的挑战（品牌、网络、资金等）
- **O（机会）**：市场中未被满足的需求（从高频痛点中提炼）
- **T（威胁）**：现有玩家的反击、价格战、客户锁定等

每个象限至少 3 条，每条要有数据依据。

输出 JSON：
{{"strengths": ["..."], "weaknesses": ["..."], "opportunities": ["..."], "threats": ["..."]}}"""
    return SYSTEM_PROMPT, user


def strategy_prompt(keyword: str, top_opps: list, profile: dict) -> tuple:
    districts = profile.get("district_strategy", {})
    price_ref = profile.get("price_reference", {})
    vehicles = profile.get("suitable_vehicles", [])

    user = f"""## 任务：市场进入策略

### 场景
一个新物流企业要进入大连「{keyword}」市场。请基于数据制定进入策略。

### 核心痛点（评论数据）：
{_format_opps(top_opps[:3])}

### 参考信息
- **区域策略建议**：{districts}
- **价格参考**：{price_ref}
- **推荐车型**：{', '.join(vehicles) if vehicles else '4.2m厢式货车'}

### 要求
1. **定位（positioning）**：一句话定位（如"大连首家午市30分钟必达的餐饮配送服务"）
2. **区域扩展路线（geo_rollout）**：3 个区域，从易到难排列，说明为什么
3. **定价策略（pricing_strategy）**：渗透/溢价/价值定价？具体数字
4. **差异化点（key_differentiators）**：3-5 个，直接回应评论中的痛点

输出 JSON：
{{"positioning": "...", "geo_rollout": ["区域1", "区域2", "区域3"], "pricing_strategy": "...", "key_differentiators": ["..."]}}"""
    return SYSTEM_PROMPT, user


def competitor_gap_prompt(keyword: str, opps: list, companies: list, industry_info: str) -> tuple:
    company_names = [c.get('name', '') for c in companies[:8] if c.get('name')]
    user = f"""## 任务：竞争差距分析

### 场景
分析「{keyword}」市场现有玩家的服务短板，找出新进入者可以切入的缝隙。

### 现有玩家
{', '.join(company_names) if company_names else '待识别'}

### 用户反馈的痛点（来自评论）：
{_format_opps(opps[:5])}

### 行业信息
{industry_info[:400] if industry_info else '暂无'}

### 要求
1. **现有玩家的弱点（incumbent_weaknesses）**：从评论数据反推，具体到运营环节
2. **差异化机会（differentiation_opportunities）**：新进入者可以怎么做不同
3. **市场切入角度（market_entry_angle）**：一句话，最有杀伤力的切入方式

输出 JSON：
{{"incumbent_weaknesses": ["..."], "differentiation_opportunities": ["..."], "market_entry_angle": "..."}}"""
    return SYSTEM_PROMPT, user


def action_plan_prompt(keyword: str, top_opps: list, profile: dict, companies: list) -> tuple:
    user = f"""## 任务：90 天行动路线图

### 场景
一个物流企业要在 90 天内从零启动「{keyword}」业务（大连地区）。

### 需要解决的 Top 痛点：
{_format_opps(top_opps[:3])}

### 潜在目标商家数量：{len(companies)} 家

### 要求
制定分阶段的 90 天行动路线图，每个阶段 3-4 项行动：
- **Phase 1（前 30 天）**：基础设施搭建
- **Phase 2（30-60 天）**：试运营和市场验证
- **Phase 3（60-90 天）**：规模扩展

每项行动包含：具体做什么、预期效果、实施难度（低/中/高）。

输出 JSON：
{{"items": [{{"phase": "30天", "action": "...", "expected_impact": "...", "difficulty": "低|中|高"}}, ...]}}"""
    return SYSTEM_PROMPT, user


def roi_prompt(keyword: str, companies: list, profile: dict, opps: list) -> tuple:
    price_ref = profile.get("price_reference", {})
    user = f"""## 任务：ROI 潜力评估

### 场景
评估在「{keyword}」市场（大连地区）的投入回报潜力。

### 数据
- **潜在目标商家数**：{len(companies)} 家
- **Top 痛点**：{_format_opps(opps[:3])}
- **价格参考**：{price_ref}

### 要求
保守估算：
1. **市场规模（estimated_market_size）**：一句话描述（如"大连地区餐饮配送日订单量约X万单，年市场规模约Y万元"）
2. **可获取份额（addressable_share_pct）**：第一年预计可获取的市场份额百分比
3. **营收潜力（revenue_potential）**：一句话描述预期年营收
4. **关键假设（key_assumptions）**：3-4 个支撑估算的关键假设

输出 JSON：
{{"estimated_market_size": "...", "addressable_share_pct": 数字, "revenue_potential": "...", "key_assumptions": ["..."]}}"""
    return SYSTEM_PROMPT, user


def _format_opps(opps: list) -> str:
    lines = []
    for i, o in enumerate(opps, 1):
        freq = o.get('frequency', 0)
        pain = o.get('pain_intensity', 0)
        score = o.get('score', 0)
        cat = o.get('category', '未知')
        terms = o.get('top_terms', [])
        lines.append(
            f"  {i}. {cat} — 频次 {freq*100:.0f}%, "
            f"痛感 {pain*100:.0f}%, 商机分 {score:.0f}, "
            f"关键词: {', '.join(terms[:5])}"
        )
    return '\n'.join(lines)
