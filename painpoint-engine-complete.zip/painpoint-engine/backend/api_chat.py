"""
AI 自由对话 API — 支持任意输入，DeepSeek 驱动，同城配送商机挖掘场景

端点:
  POST /api/chat/send   — 发送消息，AI 实时回复
  POST /api/chat/analyze — 5大场景差异化分析
  GET  /api/chat/status  — 检查 AI 可用状态
"""
import json
import logging
import os
from datetime import datetime

from fastapi import APIRouter, Query
from pydantic import BaseModel

from collectors.products import ProductGenerator
from knowledge.dalian_delivery import (
    DALIAN_DISTRICTS, VEHICLE_TYPES, REGULATORY_MAP,
    SEASONAL_FACTORS, TIME_WINDOWS, PRICE_STRUCTURE,
    COMPETITIVE_LANDSCAPE, match_scenario, get_scenario_profile,
)

logger = logging.getLogger("chat_api")

router = APIRouter(prefix="/api/chat", tags=["AI 对话"])

DELIVERY_EXPERT_PROMPT = """你是「洞见 Foresight」平台的 AI 商业分析师，专精于中国同城配送和最后一公里物流。

## 你的身份
- 资深物流行业分析师，10年+同城配送行业经验
- 熟悉大连本地市场：7个行政区配送特征、车型适配、合规要求、季节性因素
- 数据驱动，每个结论都有具体数字支撑

## 你的知识范围
- 大连同城配送市场格局：货拉拉/快狗/滴滴货运/顺丰同城/本地车队
- 5大配送场景：餐饮配送、生鲜冷链、医药配送、家具配送、商超补货
- 车型体系：面包车/4.2m厢货/冷藏车/6.8m高栏/平板车/新能源车
- 定价体系：起步价、公里费、等候费、上楼费、月结参考价
- 季节性因素：暴雪(12-2月)、樱桃季(6-7月)、海鲜季(4-5月/9-10月)、旅游旺季(7-8月)、春节(1-2月)
- 合规要求：食品经营许可证、GSP认证、冷链运输备案、道路运输许可证

## 回答风格
- 专业、自信、数据驱动，像麦肯锡咨询报告
- 每个结论都要有具体的数据支撑
- 给出可执行的建议，不是泛泛而谈
- 如果用户问的问题超出你的知识范围，诚实说明并给出最接近的分析
- 用中文回答，语气亲切但不失专业
- 适当使用换行和分段，让回答清晰易读

## 当前上下文
- 城市：大连
- 行业：同城配送/最后一公里物流
- 数据来源：公开渠道估算 + 行业知识库 + 实时爬虫数据"""


class ChatRequest(BaseModel):
    message: str
    keyword: str = "餐饮配送"
    city: str = "大连"
    history: list[dict] = []


class SceneAnalyzeRequest(BaseModel):
    keyword: str = "餐饮配送"
    city: str = "大连"


def _call_deepseek(system_prompt: str, user_prompt: str, temperature: float = 0.7,
                   max_tokens: int = 4096, timeout: int = 90) -> str:
    api_key = os.environ.get("DEEPSEEK_API_KEY", "")
    if not api_key:
        return None
    try:
        import urllib.request
        model = os.environ.get("DEEPSEEK_MODEL", "deepseek-chat")
        base_url = os.environ.get("DEEPSEEK_BASE_URL", "https://api.deepseek.com")
        payload = json.dumps({
            "model": model,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            "temperature": temperature,
            "max_tokens": max_tokens,
        }).encode("utf-8")
        req = urllib.request.Request(
            f"{base_url}/v1/chat/completions",
            data=payload,
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {api_key}",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            return result["choices"][0]["message"]["content"].strip()
    except Exception as e:
        logger.warning(f"DeepSeek call failed: {e}")
        return None


def _call_ai_or_fallback(system_prompt: str, user_prompt: str, fallback: str,
                         temperature: float = 0.7) -> str:
    result = _call_deepseek(system_prompt, user_prompt, temperature=temperature)
    if result:
        return result
    try:
        from llm.provider import GeminiProvider
        provider = GeminiProvider()
        if provider.available():
            r = provider.generate(system_prompt, user_prompt, timeout=45)
            if r:
                return str(r) if isinstance(r, str) else json.dumps(r, ensure_ascii=False)
    except Exception:
        pass
    try:
        from llm.provider import OllamaProvider
        provider = OllamaProvider()
        if provider.available():
            r = provider.generate(system_prompt, user_prompt, timeout=60)
            if r:
                return str(r) if isinstance(r, str) else json.dumps(r, ensure_ascii=False)
    except Exception:
        pass
    return fallback


@router.post("/send")
def chat_send(req: ChatRequest):
    logger.info("Chat: user=%s...", req.message[:50])
    messages = []
    for h in (req.history or [])[-10:]:
        role = h.get("role", "user")
        content = h.get("content", "")
        if role in ("user", "assistant") and content:
            messages.append({"role": role, "content": content})
    messages.append({"role": "user", "content": req.message})
    history_text = ""
    for m in messages[:-1]:
        role_name = "用户" if m["role"] == "user" else "AI"
        history_text += f"{role_name}: {m['content']}\n"
    user_prompt = f"## 对话历史\n{history_text if history_text else '（新对话）'}\n\n## 当前问题\n{req.message}\n\n## 上下文\n- 当前场景：{req.keyword}\n- 城市：{req.city}\n\n请基于你的专业知识，给出专业、数据驱动的回答。"
    fallback = _generate_chat_fallback(req.message, req.keyword)
    reply = _call_ai_or_fallback(DELIVERY_EXPERT_PROMPT, user_prompt, fallback, temperature=0.7)
    return {
        "reply": reply,
        "keyword": req.keyword,
        "city": req.city,
        "timestamp": datetime.now().isoformat(),
        "ai_provider": "DeepSeek" if os.environ.get("DEEPSEEK_API_KEY") else "RuleEngine",
    }


@router.post("/analyze")
def chat_analyze_scene(req: SceneAnalyzeRequest):
    logger.info("Scene analyze: %s", req.keyword)
    gen = ProductGenerator(city=req.city)
    capacity = gen.generate_capacity_map()
    demand = gen.generate_demand_heatmap()
    benchmark = gen.generate_competitive_benchmark()
    opp_list = gen.generate_opportunity_list(keyword=req.keyword)
    profile = get_scenario_profile(req.keyword)
    scenario = match_scenario(req.keyword)
    providers = capacity.get("capacity_providers", [])
    zones = demand.get("demand_zones", [])
    vehicles = benchmark.get("vehicle_comparison", [])
    opportunities = opp_list.get("opportunities", [])

    providers_text = "\n".join(
        f"- {p['name']} ({p['type']}): {p.get('strength','')} | 劣势: {p.get('weakness','')}"
        for p in providers[:5]
    )
    zones_text = "\n".join(
        f"- {z['zone']} ({z['demand_intensity']}): {', '.join(z.get('industries',[]))}"
        for z in zones[:4]
    )
    opps_text = "\n".join(
        f"- {o['name']} ({o['industry']}): {o['delivery_need']}, 紧迫度{o['urgency']}, 年价值{o.get('estimated_annual_value','')}"
        for o in opportunities[:5]
    )
    vehicles_text = "\n".join(
        f"- {v['车型']}: 货拉拉{v.get('货拉拉',{}).get('起步价','N/A')}, 快狗{v.get('快狗打车',{}).get('起步价','N/A')}"
        for v in vehicles[:4]
    )
    regulations = REGULATORY_MAP.get(scenario, [])
    seasonal = "\n".join(
        f"- {s['name']}({','.join(str(m) for m in s['months'])}月): {s['impact']}"
        for s in SEASONAL_FACTORS
    )

    user_prompt = (
        f"## 任务：大连「{req.keyword}」同城配送市场全景分析\n\n"
        f"### 运力供给端\n{providers_text}\n\n"
        f"### 需求端（区域分布）\n{zones_text}\n\n"
        f"### 目标企业\n{opps_text}\n\n"
        f"### 竞品价格\n{vehicles_text}\n\n"
        f"### 合规要求\n{', '.join(regulations) if regulations else '无特殊要求'}\n\n"
        f"### 季节性因素\n{seasonal}\n\n"
        f"### 要求\n"
        f"请生成一份针对「{req.keyword}」场景的深度分析报告，包含：\n"
        f"1. **市场概览**：市场规模、竞争格局、增长趋势\n"
        f"2. **运力缺口**：供需分析，哪里缺车、缺什么车型\n"
        f"3. **利润分析**：成本结构、利润空间、高利润线路\n"
        f"4. **目标客户**：Top 3 潜在客户，为什么选他们，怎么触达\n"
        f"5. **风险与挑战**：合规风险、季节性风险、竞争风险\n"
        f"6. **行动建议**：如果现在要进入这个市场，第一步做什么\n\n"
        f"注意：这是「{req.keyword}」场景的专属分析，不要套用其他场景的模板。"
        f"每个结论都要有数据支撑。给出具体可执行的建议。用 Markdown 格式输出。"
    )

    system_prompt = (
        f"{DELIVERY_EXPERT_PROMPT}\n\n"
        f"当前分析场景：{req.keyword}\n"
        f"请生成该场景的专属深度分析报告。注意：不同场景的分析重点完全不同：\n"
        f"- 餐饮配送：重点在午晚市时效、商圈停车、冷链温控\n"
        f"- 生鲜冷链：重点在全程温控、产地预冷、季节性运力\n"
        f"- 医药配送：重点在GSP合规、温湿度监控、夜间急送\n"
        f"- 家具配送：重点在上楼搬运、预约准时、货损控制\n"
        f"- 商超补货：重点在凌晨配送、鲜食保质期、多门店调度"
    )

    fallback = _generate_scene_fallback(req.keyword, opportunities, providers, zones, vehicles)
    reply = _call_ai_or_fallback(system_prompt, user_prompt, fallback, temperature=0.5)

    return {
        "reply": reply,
        "keyword": req.keyword,
        "scenario": scenario,
        "city": req.city,
        "timestamp": datetime.now().isoformat(),
        "ai_provider": "DeepSeek" if os.environ.get("DEEPSEEK_API_KEY") else "RuleEngine",
    }


@router.get("/status")
def chat_status():
    return {
        "checked_at": datetime.now().isoformat(),
        "deepseek_available": bool(os.environ.get("DEEPSEEK_API_KEY", "")),
        "deepseek_model": os.environ.get("DEEPSEEK_MODEL", "deepseek-chat"),
        "gemini_available": bool(os.environ.get("GEMINI_API_KEY", "")),
        "note": "设置 DEEPSEEK_API_KEY 环境变量启用 DeepSeek AI。未设置时使用规则引擎兜底。",
    }


def _generate_chat_fallback(message: str, keyword: str) -> str:
    msg_lower = message.lower()

    if any(w in msg_lower for w in ["利润", "赚钱", "盈利", "收入", "成本"]):
        return (
            f"## 大连{keyword}利润分析\n\n"
            f"### 成本结构（以面包车为例）\n"
            f"- 油费/电费：25-30%\n"
            f"- 司机人工：35-40%\n"
            f"- 车辆折旧：10-15%\n"
            f"- 保险+维保：8-12%\n"
            f"- 管理费：5-8%\n"
            f"- **净利润：5-10%**\n\n"
            f"### 盈亏平衡点\n"
            f"- 面包车：日均3-5单可盈利\n"
            f"- 4.2m厢货：日均2-3单可盈利\n"
            f"- 冷藏车：日均1-2单可盈利\n\n"
            f"### 提升利润的关键\n"
            f"1. **拼车配送**：装载率从40%->70%，单趟利润提升50%\n"
            f"2. **新能源车替换**：油费降低60%，月省3000-5000元\n"
            f"3. **回程带货**：空载率从35%->15%，月增收2000-4000元\n"
            f"4. **月结合同**：锁定长期客户，降低获客成本\n\n"
            f"> 当前使用规则引擎生成。设置 DEEPSEEK_API_KEY 可启用 AI 实时分析。"
        )

    if any(w in msg_lower for w in ["路线", "线路", "路径", "怎么走", "配送路线"]):
        return (
            f"## 大连{keyword}高利润路线\n\n"
            f"### Top 3 路线\n"
            f"1. **甘井子仓储中心 -> 中山区商圈**（15km）\n"
            f"   - 推荐车型：4.2m厢货 | 最佳时段：凌晨4:00-6:00\n"
            f"   - 单趟利润：150-250元 | 月利润：9000-15000元\n\n"
            f"2. **大连湾 -> 市区餐厅**（25km）\n"
            f"   - 推荐车型：冷藏车 | 最佳时段：凌晨3:00-7:00\n"
            f"   - 单趟利润：300-500元 | 月利润：18000-30000元\n\n"
            f"3. **旅顺 -> 大连市区**（45km，樱桃季）\n"
            f"   - 推荐车型：冷藏车 | 最佳时段：全天（6-7月）\n"
            f"   - 单趟利润：500-800元 | 月利润：30000-48000元\n\n"
            f"> 当前使用规则引擎生成。设置 DEEPSEEK_API_KEY 可启用 AI 实时分析。"
        )

    if any(w in msg_lower for w in ["客户", "企业", "商家", "目标", "谁需要"]):
        opps = ProductGenerator(city="大连").generate_opportunity_list(keyword=keyword)
        ops = opps.get("opportunities", [])[:3]
        lines = [f"## 大连{keyword}潜在客户\n"]
        for i, o in enumerate(ops, 1):
            lines.append(f"### {i}. {o['name']}")
            lines.append(f"- 行业：{o['industry']}")
            lines.append(f"- 需求：{o['delivery_need']}")
            lines.append(f"- 紧迫度：{o['urgency']}")
            lines.append(f"- 年价值：{o.get('estimated_annual_value', 'N/A')}")
            lines.append(f"- 触达策略：{o.get('outreach_strategy', 'N/A')}")
            lines.append("")
        lines.append("> 当前使用规则引擎生成。设置 DEEPSEEK_API_KEY 可启用 AI 实时分析。")
        return "\n".join(lines)

    if any(w in msg_lower for w in ["竞品", "对手", "货拉拉", "快狗", "竞争", "对比"]):
        return (
            f"## 大连{keyword}竞品分析\n\n"
            f"### 主要玩家\n"
            f"1. **货拉拉**：市占率约40%，B端定制化弱，平台抽成15-25%\n"
            f"2. **快狗打车**：市占率约25%，价格略低于货拉拉\n"
            f"3. **滴滴货运**：新进入大连，补贴期价格有竞争力\n"
            f"4. **顺丰同城**：品牌强、系统完善，但价格偏高\n"
            f"5. **本地车队**：200-300家分散运力，灵活但无标准化\n\n"
            f"### 差异化机会\n"
            f"- 比平台便宜10-15%（省去平台抽成）\n"
            f"- 比本地车队可靠10倍（标准化服务+SLA保障）\n"
            f"- 行业定制化方案（餐饮/生鲜/医药各有专属SOP）\n\n"
            f"> 当前使用规则引擎生成。设置 DEEPSEEK_API_KEY 可启用 AI 实时分析。"
        )

    return (
        f"## 关于「{message[:50]}」的分析\n\n"
        f"作为大连同城配送领域的专业分析师，我理解你想了解这方面的信息。\n\n"
        f"当前我处于**规则引擎模式**，可以回答以下类型的问题：\n\n"
        f"- **利润分析**：成本结构、盈亏平衡、提升利润的方法\n"
        f"- **路线规划**：高利润线路、最佳时段、推荐车型\n"
        f"- **客户挖掘**：潜在客户、触达策略、年价值估算\n"
        f"- **竞品分析**：货拉拉/快狗/滴滴货运对比\n"
        f"- **市场分析**：市场规模、增长趋势、空白机会\n"
        f"- **车型选择**：不同车型的成本、适用场景、利润空间\n"
        f"- **季节性策略**：樱桃季/海鲜季/暴雪季应对方案\n\n"
        f"> **提示**：设置环境变量 `DEEPSEEK_API_KEY` 后，"
        f"我可以基于真实 AI 模型进行深度分析，像豆包一样灵活回答任何问题。"
    )


def _generate_scene_fallback(keyword: str, opportunities: list, providers: list,
                              zones: list, vehicles: list) -> str:
    scenario = match_scenario(keyword)
    scene_intros = {
        "餐饮配送": "大连餐饮配送市场日均订单约3-5万单，连锁餐饮品牌超过200家。核心痛点是午晚市时效压力和冷链温控。",
        "生鲜冷链": "大连生鲜冷链市场年规模约5000-8000万，樱桃/海鲜是两大核心品类。核心痛点是季节性运力缺口和全程温控。",
        "医药配送": "大连医药配送市场年规模约2000-4000万，GSP合规是最高门槛。核心痛点是温湿度监控和夜间急送。",
        "家具配送": "大连家具配送市场年规模约3000-5000万，老小区无电梯率40%+。核心痛点是上楼搬运和货损控制。",
        "商超补货": "大连便利店超过500家，鲜食日配是刚需。核心痛点是凌晨配送和鲜食保质期仅24小时。",
    }
    intro = scene_intros.get(scenario, f"大连{keyword}市场具有较大的增长潜力。")

    opps_text = "\n".join(
        f"**{i+1}. {o['name']}** — {o['industry']} | {o['delivery_need'][:60]} | 紧迫度: {o['urgency']} | 年价值: {o.get('estimated_annual_value','')}"
        for i, o in enumerate(opportunities[:5])
    )
    zones_text = "\n".join(
        f"- **{z['zone']}**（{z['demand_intensity']}）：{', '.join(z.get('industries',[]))}"
        for z in zones[:4]
    )

    return (
        f"# 大连「{keyword}」市场全景分析\n\n"
        f"## 一、市场概览\n{intro}\n\n"
        f"当前市场运力供给以平台型（货拉拉/快狗）为主，专业B端配送服务商稀缺。"
        f"{len(providers)}家主要运力提供商中，专业冷链运力仅20+台，存在明显的供需缺口。\n\n"
        f"## 二、运力缺口分析\n\n### 需求区域分布\n{zones_text}\n\n"
        f"### 缺口总结\n"
        f"- **核心商圈**：午晚市高峰期运力不足，缺口约500-1000单/日\n"
        f"- **冷链运力**：冷藏车仅20+台，樱桃季/海鲜季缺口30-60%\n"
        f"- **凌晨配送**：便利店/生鲜店凌晨配送需求大但供给极少\n\n"
        f"## 三、目标客户 Top 3\n\n{opps_text}\n\n"
        f"## 四、利润分析\n\n### 成本结构\n"
        f"- 油费/电费：25-30%\n- 司机人工：35-40%\n- 车辆折旧：10-15%\n- 净利润空间：5-10%\n\n"
        f"### 提升利润的关键\n"
        f"1. 拼车配送：装载率40%->70%\n2. 新能源车替换：油费降低60%\n3. 回程带货：空载率35%->15%\n\n"
        f"## 五、风险与挑战\n\n### 季节性风险\n"
        f"- 樱桃季(6-7月)：冷链运力缺口30-40%\n"
        f"- 冬季暴雪(12-2月)：运力下降40-60%\n"
        f"- 春节(1-2月)：司机返乡，运力不足50-70%\n\n"
        f"### 竞争风险\n- 货拉拉/快狗可能通过补贴压低价格\n- 大平台可能切入B端定制化市场\n\n"
        f"## 六、行动建议\n\n"
        f"1. **第1-2周**：锁定3-5家高紧迫度目标企业，提供免费试用\n"
        f"2. **第3-6周**：整合10-15台本地运力，上线调度系统MVP\n"
        f"3. **第7-12周**：以标杆案例撬动同行业5-10家客户\n\n"
        f"> 当前使用规则引擎生成。设置 DEEPSEEK_API_KEY 可启用 AI 实时深度分析，生成更精准的差异化报告。"
    )
