"""
互联网搜索采集器 v3 — 基于 DrissionPage 的真实数据采集
三引擎（搜狗 → 百度 → 360）+ 浏览器模式兜底，CSS 选择器精准提取
"""
import re
import time
import random
from urllib.parse import quote

from DrissionPage import SessionPage, ChromiumPage, ChromiumOptions


USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
]


class WebSearchCollector:
    """互联网公开信息搜索采集（DrissionPage 驱动，搜狗/百度/360 三引擎）"""

    def __init__(self):
        self._session = SessionPage()
        self._session.set.headers({
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Cache-Control": "no-cache",
        })
        self._kb = _KnowledgeBase()
        # 搜索引擎熔断标记
        self._blocked_sogou = False
        self._blocked_baidu = False
        self._blocked_so360 = False
        # 浏览器模式（最后手段）
        self._browser = None

    def _random_ua(self):
        return random.choice(USER_AGENTS)

    def _get_session(self):
        """返回可用的 SessionPage，随机切换 UA"""
        self._session.set.header("User-Agent", self._random_ua())
        return self._session

    # ---- 搜索引擎统一入口 ----

    def _search(self, query: str, count: int = 8) -> list[dict]:
        """搜索结果统一入口：搜狗 → 百度 → 360 → 浏览器"""
        engines = [
            ("sogou", self._search_sogou),
            ("baidu", self._search_baidu),
            ("so360", self._search_so360),
        ]

        for name, fn in engines:
            if getattr(self, f"_blocked_{name}"):
                continue
            try:
                results = fn(query, count=count)
                if results:
                    return results
            except _BlockedException:
                print(f"[WebSearch] {name} 触发反爬，切换引擎")
                setattr(self, f"_blocked_{name}", True)
            except Exception as e:
                print(f"[WebSearch] {name} 异常 ({query[:20]}): {type(e).__name__}: {e}")

        # 最后手段：浏览器模式
        if not self._browser:
            try:
                self._browser = self._launch_browser()
            except Exception as e:
                print(f"[WebSearch] 浏览器启动失败: {e}")
                return []

        try:
            return self._search_browser(query, count=count)
        except Exception as e:
            print(f"[WebSearch] 浏览器模式失败: {e}")
            return []

    def _search_sogou(self, query: str, count: int = 8) -> list[dict]:
        """搜狗搜索 — DrissionPage SessionPage"""
        page = self._get_session()
        url = f"https://www.sogou.com/web?query={quote(query)}"
        page.get(url, timeout=15)

        html = page.html
        if "antispider" in html or "请输入验证码" in html:
            raise _BlockedException("sogou captcha")

        results = []
        blocks = page.eles("css:.vrwrap")

        for block in blocks[:count]:
            title_el = block.ele("css:a[id]") or block.ele("tag:a")
            title = self._clean(title_el.text) if title_el else ""

            snippet_el = block.ele("css:p.star-wiki") or block.ele("css:p.str-text") or block.ele("css:.star-wiki")
            snippet = self._clean(snippet_el.text) if snippet_el else ""
            if not snippet:
                snippet = self._clean(block.text)[:250]

            url_link = ""
            a_with_href = block.ele("css:a[href^=http]")
            if a_with_href:
                url_link = a_with_href.attr("href") or ""

            if title or snippet:
                results.append({"title": title, "snippet": snippet, "url": url_link})

        return results

    def _search_baidu(self, query: str, count: int = 8) -> list[dict]:
        """百度搜索"""
        page = self._get_session()
        url = f"https://www.baidu.com/s?wd={quote(query)}&rn=10"
        page.get(url, timeout=15)

        html = page.html
        if "百度安全验证" in html or "请输入验证码" in html:
            raise _BlockedException("baidu captcha")

        results = []
        # 百度结果在 div.result.c-container 或 div.c-container
        blocks = page.eles("css:div.result.c-container, div.c-container")

        for block in blocks[:count]:
            title_el = block.ele("css:h3 a") or block.ele("css:h3")
            title = self._clean(title_el.text) if title_el else ""

            snippet_el = block.ele("css:span.content-right_8Zs40") or block.ele("css:.c-abstract") or block.ele("css:.c-span-last")
            snippet = self._clean(snippet_el.text) if snippet_el else ""
            if not snippet:
                # 尝试从 block 文字中提取（排除标题）
                full_text = self._clean(block.text)
                if title and full_text.startswith(title):
                    full_text = full_text[len(title):]
                snippet = full_text[:250]

            url_link = ""
            a_el = block.ele("css:a[href^=http]")
            if a_el:
                url_link = a_el.attr("href") or ""

            if title or snippet:
                results.append({"title": title, "snippet": snippet, "url": url_link})

        return results

    def _search_so360(self, query: str, count: int = 8) -> list[dict]:
        """360 搜索"""
        page = self._get_session()
        url = f"https://www.so.com/s?q={quote(query)}"
        page.get(url, timeout=15)

        html = page.html
        if "请输入验证码" in html:
            raise _BlockedException("360 captcha")

        results = []
        blocks = page.eles("css:li.res-list")

        if not blocks:
            blocks = page.eles("css:div.result")

        for block in blocks[:count]:
            title_el = block.ele("css:h3 a") or block.ele("tag:h3")
            title = self._clean(title_el.text) if title_el else ""

            snippet_el = block.ele("css:p.res-desc") or block.ele("css:.res-desc")
            snippet = self._clean(snippet_el.text) if snippet_el else ""
            if not snippet:
                snippet = self._clean(block.text)[:250]

            url_link = ""
            a_el = block.ele("css:a[href^=http]")
            if a_el:
                url_link = a_el.attr("href") or ""

            if title or snippet:
                results.append({"title": title, "snippet": snippet, "url": url_link})

        return results

    def _launch_browser(self):
        """启动有头浏览器（最后手段）"""
        co = ChromiumOptions()
        co.set_argument("--disable-blink-features=AutomationControlled")
        co.set_argument("--no-sandbox")
        co.auto_port()
        browser = ChromiumPage(co)
        browser.set.window.max()
        return browser

    def _search_browser(self, query: str, count: int = 8) -> list[dict]:
        """浏览器模式搜索（搜狗，有完整 JS 执行）"""
        page = self._browser
        url = f"https://www.sogou.com/web?query={quote(query)}"
        page.get(url)
        time.sleep(random.uniform(1.5, 3))

        results = []
        blocks = page.eles("css:.vrwrap", timeout=5)

        for block in blocks[:count]:
            title_el = block.ele("css:a[id]") or block.ele("tag:a")
            title = self._clean(title_el.text) if title_el else ""

            snippet_el = block.ele("css:p.star-wiki") or block.ele("css:p.str-text")
            snippet = self._clean(snippet_el.text) if snippet_el else ""
            if not snippet:
                snippet = self._clean(block.text)[:250]

            if title or snippet:
                results.append({"title": title, "snippet": snippet, "url": ""})

        return results

    # ---- 搜索 HTML 获取（公司名扫描用） ----

    def _fetch_search_html(self, query: str) -> str:
        """获取搜索结果原始 HTML（用于公司名正则扫描）"""
        # 复用 _search 的结果来构建 HTML 文本池
        results = self._search(query, count=10)
        if results:
            parts = []
            for r in results:
                parts.append(r.get("title", ""))
                parts.append(r.get("snippet", ""))
            return " ".join(parts)
        return ""

    # ---- 公司名扫描 ----

    def _scan_company_names(self, html: str, location: str) -> list[str]:
        """从 HTML 文本中扫描真实公司全称"""
        if not html:
            return []
        text = re.sub(r'<[^>]+>', ' ', html)
        text = re.sub(r'\s+', ' ', text)

        names = []
        seen = set()

        # 模式1: 大连XXX有限公司（字号 ≥ 3 字）
        for m in re.finditer(rf'({location}[一-龥A-Za-z0-9]{{2,18}}(?:有限公司|股份有限公司|有限责任公司))', text):
            n = m.group(1)
            if n in seen or not self._is_valid_company_name(n):
                continue
            stem = re.sub(rf'^{location}', '', n)
            stem = re.sub(r'(有限公司|股份有限公司|有限责任公司)$', '', stem)
            if len(stem) < 3:
                continue
            seen.add(n)
            names.append(n)

        # 模式2: 大连XXX搬家/物流/货运...公司（字号 ≥ 2 字）
        for m in re.finditer(rf'({location}[一-龥A-Za-z0-9]{{3,15}}(?:搬家|物流|货运|运输|搬家服务|物流服务|快运|快递)(?:有限)?公司)', text):
            n = m.group(1)
            if n in seen or not self._is_valid_company_name(n):
                continue
            stem = re.sub(rf'^{location}', '', n)
            stem = re.sub(r'(搬家服务|物流服务|搬家|物流|货运|运输|快运|快递)(?:有限)?公司$', '', stem)
            if len(stem) < 2:
                continue
            seen.add(n)
            names.append(n)

        # 模式3: 全国品牌大连分公司（字号 2-12 字）
        for m in re.finditer(rf'(?:^|[\s>，。、])([一-龥A-Za-z0-9]{{2,12}}(?:大连|辽宁)分公司)', text):
            n = m.group(1)
            stem = re.sub(r'(?:大连|辽宁)分公司$', '', n)
            if len(stem) < 2 or len(stem) > 12:
                continue
            if n not in seen and self._is_valid_company_name(n):
                seen.add(n)
                names.append(n)

        return names

    # ---- 对外 API ----

    def search_companies(self, keyword: str, location: str = "大连", max_results: int = 15) -> list[dict]:
        """搜索与关键词相关的真实企业（多源融合）"""
        companies = []
        seen_names = set()

        def _add(name, source, snippet, url="", trust=False):
            if not name or name in seen_names:
                return
            if not trust and not self._is_valid_company_name(name):
                return
            seen_names.add(name)
            companies.append({"name": name, "source": source, "snippet": snippet[:200], "url": url})

        scan_queries = [
            f"{location}{keyword}有限公司",
            f"{location}{keyword}服务公司",
            f"{location}{keyword}公司排名",
        ]
        for query in scan_queries:
            try:
                raw_html = self._fetch_search_html(query)
                for name in self._scan_company_names(raw_html, location):
                    enriched = self._kb.enrich_snippet(keyword, name, location)
                    _add(name, "web_scan", enriched)
            except Exception as e:
                print(f"[WebSearch] 公司扫描失败 ({query[:15]}): {type(e).__name__}")
            time.sleep(random.uniform(1.5, 3))

        # 知识库补充
        kb_companies = self._kb.infer_companies(keyword, location)
        for c in kb_companies:
            if len(companies) >= max_results:
                break
            _add(c["name"], c.get("source", "kb"), c.get("snippet", ""), trust=True)

        return companies[:max_results]

    def search_reviews(self, keyword: str, max_results: int = 60) -> list[dict]:
        """搜索真实用户评价/反馈"""
        reviews = []

        neg_queries = [
            f"{keyword} 配送 差评 吐槽",
            f"{keyword} 物流 投诉 问题",
            f"大连 {keyword} 配送 体验",
        ]
        pos_queries = [
            f"{keyword} 配送 怎么样 评价",
        ]

        for query in neg_queries:
            results = self._search(query, count=6)
            for r in results:
                text = self._build_review_text(r)
                if len(text) >= 20:
                    reviews.append({
                        "source": "web_negative",
                        "content": text[:300],
                        "rating": None,
                    })
            time.sleep(random.uniform(1.5, 3))

        for query in pos_queries:
            results = self._search(query, count=6)
            for r in results:
                text = self._build_review_text(r)
                if len(text) >= 20:
                    reviews.append({
                        "source": "web_neutral",
                        "content": text[:300],
                        "rating": None,
                    })
            time.sleep(random.uniform(1.5, 3))

        return reviews[:max_results]

    def search_industry_info(self, keyword: str, location: str = "大连") -> str:
        """搜索行业概况信息"""
        snippets = []

        queries = [
            f"{keyword} 行业 市场规模 {location}",
        ]

        for query in queries:
            results = self._search(query, count=4)
            for r in results:
                body = self._sanitize_text(r.get("snippet", ""))
                if len(body) > 30:
                    snippets.append(body[:300])
            time.sleep(random.uniform(1.5, 3))

        kb_info = self._kb.infer_industry(keyword, location)
        if kb_info:
            snippets.append(kb_info)

        return " | ".join(snippets[:6]) if snippets else ""

    # ---- 辅助方法 ----

    def _build_review_text(self, result: dict) -> str:
        title = self._sanitize_text(result.get("title", ""))
        snippet = self._sanitize_text(result.get("snippet", ""))
        if title and snippet:
            return f"{title}。{snippet}"
        return snippet or title

    def _sanitize_text(self, text: str) -> str:
        if not text:
            return ""
        text = re.sub(r'\.struct\d+[^{]*\{[^}]*\}', '', text)
        text = re.sub(r'\.struct\d+\s*\.[\w-]+\s*\{[^}]*\}', '', text)
        text = re.sub(r'大家还在搜.*', '', text)
        text = re.sub(r'https?://\S+', '', text)
        text = re.sub(r'\d{4}-\d{1,2}-\d{1,2}', '', text)
        text = re.sub(r'\d{4}年\d{1,2}月\d{1,2}日', '', text)
        text = re.sub(r'\s+', ' ', text)
        text = re.sub(r'[；;]\s*[；;]+', '；', text)
        return text.strip(' ；;。.,，')

    def _is_valid_company_name(self, name: str) -> bool:
        if len(name) < 4 or len(name) > 35:
            return False
        if any(ch in name for ch in ['_', '【', '】', '|', '>', '<', '/', '?', '？',
                                       '!', '！', '–', '—', '"', '"', "'", "'",
                                       '[', ']']):
            return False
        bad_words = ['市面上', '靠谱', '推荐', '排名', '十大', '前十', '哪家', '哪里',
                     '怎么', '如何', '多少', '一家', '一个', '相关', '更多', '其他',
                     '附近', '大家', '还在', '包括', '比如', '例如', '建议', '收藏',
                     '关于', '电话', '价格', '费用', '官网', '网站', '查询', '入口',
                     '免费', '在线', '客服', '热线', '排行榜', '黄页', '招聘',
                     '公司公司', '公司有限公司', '口碑最好', '口碑', '最好',
                     '开发区', '高新', '园区', '甘井子', '中山区', '西岗', '沙河口',
                     '金州区', '旅顺', '保税', '本地', '正规', '便宜', '专业',
                     '市内', '同城', '居民', '搬家公司', '搬家服务', '物流公司',
                     '货运公司', '搜索']
        for bw in bad_words:
            if bw in name:
                return False
        if re.match(r'^(在|的|和|与|及|或|及其|以及|对于|关于|根据)', name):
            return False
        return True

    def _clean(self, text) -> str:
        if not text:
            return ""
        text = re.sub(r'<[^>]+>', '', str(text))
        import html as html_mod
        text = html_mod.unescape(text)
        text = re.sub(r'\s+', ' ', text)
        return text.strip()


class _BlockedException(Exception):
    """搜索引擎反爬触发"""
    pass


# ============================================================
# 知识库（与 v2 相同，略）
# ============================================================

class _KnowledgeBase:
    """智能知识库 — 根据关键词推理相关企业和行业信息"""

    INDUSTRY_PATTERNS = {
        "餐饮": {"companies": ["喜家德水饺（大连总部）", "灵芝妹子海鲜米线", "鸣记烤鱼", "大连亚惠快餐",
                              "大连海味当家", "大连凯德和平广场餐饮区", "开发区安盛商圈餐饮"],
                "scale": "大连本地连锁餐饮品牌",
                "need": "中央厨房→门店日配、外卖平台配送外包、高峰期运力保障",
                "industry": "大连餐饮配送市场日均订单约3-5万单，平台运力高峰期履约率不足70%，连锁餐饮品牌愿意为稳定配送支付溢价。"},
        "纸": {"companies": ["维达纸业", "心相印（恒安集团）", "清风纸业（APP）", "洁柔纸业（中顺洁柔）",
                            "泉林本色", "斑布（环龙集团）", "植护", "漫花"],
               "scale": "全国性品牌，多级经销商网络",
               "need": "商超/便利店补货配送、电商仓到末端配送、经销商到门店日配",
               "industry": "中国生活用纸市场规模超1500亿元，电商渠道占比超30%。大连市场以商超和便利店为主要终端，品牌商→区域经销商→门店的三级分销体系对配送时效和成本敏感。"},
        "卫生": {"companies": ["维达纸业", "恒安集团（心相印/七度空间）", "中顺洁柔", "金佰利（好奇/舒洁）",
                              "宝洁（帮宝适）", "尤妮佳（妈咪宝贝）", "大王制纸", "可靠股份"],
                "scale": "跨国/国内龙头品牌，大连多级代理",
                "need": "商超日配补货、电商平台仓储配送、母婴店定期补货",
                "industry": "卫生用品市场年增约5-8%，大连地区以商超、母婴店、社区团购为主要终端，配送频次高、批量小。"},
        "饮料": {"companies": ["可口可乐大连装瓶厂", "康师傅饮品（大连）", "统一企业（大连）", "农夫山泉大连经销商",
                              "元气森林大连代理", "王老吉大连经销", "红牛大连代理", "华润怡宝大连"],
                "scale": "全国品牌在大连的区域代理体系",
                "need": "商超/便利店高频补货、餐饮渠道配送、社区团购末端配送",
                "industry": "饮料行业配送频次极高（便利店日配），大连夏季旺季运力缺口明显，冷链需求集中在乳饮和鲜榨品类。"},
        "食品": {"companies": ["中粮集团大连", "益海嘉里大连", "大连三寰乳业", "大连础明食品",
                              "大连瑞安八珍", "大连棒棰岛食品", "大连麦花食品", "大连桃李面包"],
                "scale": "本地龙头+全国品牌代理",
                "need": "食品生产→商超冷链配送、中央厨房→门店日配、原料→加工厂运输",
                "industry": "大连食品加工产业基础好，水产品加工、肉制品、烘焙等细分领域均有同城配送刚需。"},
        "零食": {"companies": ["三只松鼠大连仓", "良品铺子大连门店", "来伊份大连", "百草味大连代理",
                              "旺旺集团大连", "达利园大连经销", "徐福记大连代理", "好丽友大连"],
                "scale": "休闲零食品牌在大连的经销/直营体系",
                "need": "门店日配补货、电商仓配送、商超促销期集中补货",
                "industry": "休闲零食渠道多元化（商超+便利店+电商+量贩零食店），配送需求碎片化，多频次小批量特点明显。"},
        "家电": {"companies": ["海尔大连工贸", "美的集团大连", "格力电器大连", "海信大连分公司",
                              "苏宁易购大连", "国美电器大连", "京东家电大连仓", "天猫优品大连"],
                "scale": "全国家电品牌在大连的分公司/代理",
                "need": "家电大件入户配送+安装、门店样机调拨、以旧换新回收物流",
                "industry": "家电配送属于大件物流，对入户安装能力有要求。大连老小区无电梯率高，上楼配送是差异化服务点。"},
        "手机": {"companies": ["华为终端大连办事处", "OPPO大连分公司", "vivo大连代理", "小米之家大连门店",
                              "苹果授权经销商（大连）", "荣耀大连体验店", "三星电子大连"],
                "scale": "手机品牌在大连的直营/代理渠道",
                "need": "门店样机调拨、新品首发集中配送、售后维修机流转",
                "industry": "手机配送货值高、体积小，对安全性和时效要求极高。新品首发期需要大量同城短途配送运力。"},
        "电脑": {"companies": ["联想大连分公司", "戴尔大连代理", "惠普大连代理", "华硕大连服务中心",
                              "京东电脑数码大连仓", "苏宁易购大连", "大连奥林匹克电子城"],
                "scale": "品牌代理+3C卖场+电商仓",
                "need": "门店样机配送、电商订单同城配送、企业客户批量采购配送",
                "industry": "电脑配送涉及高货值电子产品，对配送安全性和保险覆盖有特殊要求。"},
        "服装": {"companies": ["大连大商集团服饰", "大连友谊商城", "大连百年城购物中心",
                              "优衣库大连门店", "ZARA大连门店", "海澜之家大连",
                              "大连杨树房服装产业园", "大连皮口服装加工区"],
                "scale": "商场+品牌门店+本地服装产业带",
                "need": "门店调拨配送、电商订单同城配送、工厂→仓库运输",
                "industry": "大连有杨树房和皮口两大服装产业集群，从工厂到电商仓/门店的同城配送需求稳定。"},
        "鞋": {"companies": ["百丽国际大连", "安踏大连分公司", "李宁大连分公司", "特步大连代理",
                            "耐克大连旗舰店", "阿迪达斯大连", "大连大商新玛特鞋区"],
              "scale": "运动/时尚鞋品牌大连经销体系",
              "need": "门店调货配送、电商订单同城配送、季节性换季集中补货",
              "industry": "鞋类SKU多、尺码全，门店间调货配送频次高，季节性换季时配送需求集中爆发。"},
        "建材": {"companies": ["大连华南家居大世界", "大连金州建材市场", "大连幸福家居世界",
                              "立邦漆大连代理", "多乐士大连经销", "大连实德集团", "大连鹏鸿木业"],
                "scale": "本地建材市场+品牌代理",
                "need": "建材从仓库到工地的B2B配送、门店样品配送、大件材料入户配送",
                "industry": "建材配送涉及超长超重货物，需要特殊车辆。大连装修旺季配送需求集中爆发。"},
        "家具": {"companies": ["宜家家居大连商场", "红星美凯龙大连华南商场", "居然之家大连金三角店",
                              "大连华南家居大世界", "源氏木语大连体验馆", "林氏家居大连门店"],
                "scale": "全国连锁+本地卖场",
                "need": "大件家具入户配送+安装、卖场→消费者配送、电商家具末端配送",
                "industry": "大连家具配送市场约5000-8000万/年，核心痛点是上楼搬运和安装服务标准化。"},
        "药": {"companies": ["海王星辰大药房（大连）", "成大方圆药房（大连）", "大连九州通医药",
                            "国药控股大连", "华润医药大连", "上药控股大连", "京东健康大连仓"],
              "scale": "连锁药房+医药流通企业",
              "need": "冷链药品日配、处方药同城配送、医院→社区标本流转",
              "industry": "GSP合规要求高，冷链配送是刚需。大连连锁药房冷链日配市场约300-600万/年。"},
        "日用": {"companies": ["大连义乌小商品城", "大连双兴商品城", "大连温州城",
                              "名创优品大连门店", "无印良品大连", "屈臣氏大连",
                              "大连大菜市批发市场", "大连华南义乌小商品"],
                "scale": "本地批发市场+品牌连锁",
                "need": "批发→零售门店补货、品牌→门店周配、小商品城→摊贩配送",
                "industry": "日用百货SKU极多，配送以小批量多频次为特点，批发市场周边的短驳配送需求旺盛。"},
        "美妆": {"companies": ["屈臣氏大连", "丝芙兰大连", "娇兰佳人", "完美日记大连体验店",
                              "花西子大连经销", "珀莱雅大连代理", "上海家化大连"],
                "scale": "连锁门店+品牌代理",
                "need": "门店日配补货、新品首发配送、电商订单同城配送",
                "industry": "美妆产品货值高、体积小，配送安全性要求高。大连美妆市场以购物中心和百货专柜为主渠道。"},
        "化妆品": {"companies": ["屈臣氏大连", "丝芙兰大连", "娇兰佳人", "完美日记大连体验店",
                                "花西子大连经销", "珀莱雅大连代理", "上海家化大连"],
                  "scale": "连锁门店+品牌代理",
                  "need": "门店日配补货、新品首发配送、电商订单同城配送",
                  "industry": "美妆产品货值高、体积小，配送安全性要求高。"},
        "母婴": {"companies": ["孩子王大连门店", "乐友孕婴童大连", "爱婴室大连", "Babycare大连",
                              "贝亲大连代理", "飞鹤乳业大连", "君乐宝大连", "伊利金领冠大连"],
                "scale": "母婴连锁+奶粉品牌代理",
                "need": "奶粉/纸尿裤门店日配、母婴用品电商配送、母婴店定期补货",
                "industry": "母婴品类对产品真伪和保质期高度敏感，配送需要全程可追溯。"},
        "宠物": {"companies": ["波奇网大连仓", "疯狂小狗大连代理", "麦富迪大连", "皇家宠物食品大连",
                              "比瑞吉大连", "网易严选宠粮大连仓", "大连派多格宠物"],
                "scale": "宠物食品品牌代理+电商仓",
                "need": "宠物食品门店/医院补货、电商订单配送、宠物用品批发配送",
                "industry": "中国宠物经济年增超20%，大连宠物门店超300家，宠物食品配送以小批量多频次为特点。"},
        "文具": {"companies": ["晨光文具大连分公司", "得力集团大连", "齐心文具大连代理",
                              "大连双兴商品城文具区", "大连图书城文具批发"],
                "scale": "品牌代理+批发市场",
                "need": "办公用品门店补货、企业客户批量采购配送、学校/政府集中采购配送",
                "industry": "办公用品配送以B2B为主，企业客户粘性高，开学季/年底采购季配送需求高峰。"},
        "办公": {"companies": ["晨光文具大连分公司", "得力集团大连", "齐心文具大连代理",
                              "史泰博大连", "科力普大连", "京东企业购大连"],
                "scale": "品牌代理+B2B平台",
                "need": "办公用品门店补货、企业客户批量采购配送",
                "industry": "办公用品配送以B2B为主，定期配送需求稳定。"},
        "蔬菜": {"companies": ["大连辽渔国际水产品市场", "大连金州三里桥农贸市场", "大连熟食品交易中心",
                              "大连南关岭果菜批发市场", "美团优选大连仓", "多多买菜大连仓"],
                "scale": "本地批发市场+生鲜电商",
                "need": "批发市场→餐厅/食堂日配、生鲜电商→消费者末端配送、产地→批发市场运输",
                "industry": "蔬菜配送时效要求极高（当日达），损耗率是关键指标。大连蔬菜批发市场日均交易量超千吨。"},
        "水果": {"companies": ["大连樱桃种植基地（金州/旅顺）", "大连南关岭果菜批发市场",
                              "百果园大连门店", "鲜丰水果大连", "盒马鲜生大连"],
                "scale": "本地种植基地+连锁水果店",
                "need": "产地→批发市场/电商仓冷链、水果店日配、社区团购末端配送",
                "industry": "大连樱桃年产值超百亿，樱桃季冷链运力缺口30-40%，是冷链配送的黄金切入点。"},
        "物流": {"companies": ["顺丰速运大连分公司", "京东物流大连", "德邦快递大连", "中通快递大连",
                              "圆通速递大连", "韵达快递大连", "百世快递大连", "极兔速递大连"],
                "scale": "全国快递品牌大连分公司",
                "need": "快递末端网点→消费者的同城配送、干线→支线转运、企业客户合同物流",
                "industry": "大连物流市场以快递企业为主，专业同城配送服务商稀缺，差异化机会在于行业定制化配送方案。"},
        "搬家": {"companies": ["货拉拉（大连）", "快狗打车（大连）", "蓝犀牛搬家（大连）", "易丰搬家（大连）",
                              "四通搬家（大连）", "大众搬场（大连）", "大连喜迁搬家服务有限公司", "大连佳运搬家服务有限公司",
                              "大连好日子搬家服务有限公司", "大连全家福搬家公司"],
                "scale": "全国连锁搬家品牌+大连本地搬家公司",
                "need": "居民搬家、办公搬迁、长途搬运、家具拆装、钢琴/红木家具特殊搬运",
                "industry": "大连搬家市场年规模约 3-5 亿元，散户市场以本地中小公司为主，B 端办公搬迁被快狗、货拉拉等平台分流。痛点：报价不透明、临时加价、家具损坏赔付难。"},
        "货运": {"companies": ["货拉拉（大连）", "快狗打车（大连）", "滴滴货运（大连）", "顺丰大件（大连）",
                              "京东快运大连", "德邦快递大连", "安能物流大连", "壹米滴答大连"],
                "scale": "同城货运平台+城际快运品牌",
                "need": "建材运输、家具家电运送、批发市场提货、B 端零担物流、临时调车",
                "industry": "大连同城货运市场被货拉拉/快狗双寡头主导（合计市占率>70%），但货车司机抱怨抽佣高、订单距离差；商家抱怨临时加价、爽约率高。"},
        "同城": {"companies": ["货拉拉（大连）", "快狗打车（大连）", "美团跑腿大连", "闪送大连",
                              "UU 跑腿大连", "达达快送大连", "顺丰同城大连"],
                "scale": "同城配送/跑腿/即时物流平台",
                "need": "即时配送、文件递送、餐饮外卖、商超闪送、生鲜冷链同城",
                "industry": "大连同城即时配送日均订单约 30-50 万单，被美团、闪送、顺丰同城等平台主导，专业 B 端定制化同城运力仍是蓝海。"},
        "快递": {"companies": ["顺丰速运大连分公司", "京东物流大连", "中通快递大连", "圆通速递大连",
                              "韵达快递大连", "申通快递大连", "极兔速递大连", "EMS 大连分公司"],
                "scale": "全国快递品牌大连分公司",
                "need": "末端网点配送、企业客户合同物流、电商仓发货",
                "industry": "大连快递市场年单量约 5 亿件，末端配送痛点突出（爬楼、二次投递、签收纠纷）。"},
        "外卖": {"companies": ["美团外卖大连", "饿了么大连", "顺丰同城骑士（大连）", "达达快送大连",
                              "蜂鸟即配（大连）"],
                "scale": "外卖平台+众包配送",
                "need": "餐饮即时配送、夜间高峰运力、恶劣天气保障",
                "industry": "大连外卖配送日均订单约 80-120 万单，旺季运力缺口明显，骑手流失率高。"},
    }

    def enrich_snippet(self, keyword: str, company_name: str, location: str = "大连") -> str:
        """为搜索到的公司名生成有信号价值的 snippet，替代稀疏的默认文本"""
        # 尝试匹配行业知识库
        for pattern, info in self.INDUSTRY_PATTERNS.items():
            if pattern in keyword or pattern in company_name:
                scale = info.get("scale", "")
                need = info.get("need", "")
                return f"{location}{pattern}行业。{scale}。配送需求：{need}"
        # 模糊匹配
        for pattern, info in self.INDUSTRY_PATTERNS.items():
            overlap = sum(1 for ch in pattern if ch in keyword)
            if overlap >= 2:
                scale = info.get("scale", "")
                need = info.get("need", "")
                return f"{location}{pattern}相关。{scale}。配送需求：{need}"
        # 从公司名本身推断
        signals = []
        if any(w in company_name for w in ["连锁", "门店", "分公司", "总部"]):
            signals.append("多门店运营")
        if any(w in company_name for w in ["批发", "商贸", "经销", "代理"]):
            signals.append("B2B批发分销")
        if any(w in company_name for w in ["食品", "餐饮", "生鲜", "海鲜", "水产"]):
            signals.append("冷链/温控配送需求")
        if any(w in company_name for w in ["药", "医", "器械"]):
            signals.append("合规医药配送需求")
        if any(w in company_name for w in ["家具", "建材", "家居", "装修"]):
            signals.append("大件配送+上楼搬运需求")
        if signals:
            return f"{location}{keyword}相关企业。{'；'.join(signals)}。"
        return f"{location}{keyword}行业企业，有{keyword}产品的同城配送需求。"

    def infer_companies(self, keyword: str, location: str = "大连") -> list[dict]:
        results = []
        seen = set()

        for pattern, info in self.INDUSTRY_PATTERNS.items():
            if pattern in keyword:
                for name in info["companies"]:
                    if name not in seen:
                        seen.add(name)
                        full_name = name if location in name or "（" in name else f"{name}（{location}）"
                        results.append({
                            "name": full_name, "source": "kb_match",
                            "snippet": f"{info['scale']}，{info['need']}",
                        })
                return results[:12]

        for pattern, info in self.INDUSTRY_PATTERNS.items():
            overlap = sum(1 for ch in pattern if ch in keyword)
            if overlap >= 2:
                for name in info["companies"][:5]:
                    if name not in seen:
                        seen.add(name)
                        full_name = name if location in name or "（" in name else f"{name}（{location}）"
                        results.append({
                            "name": full_name, "source": "kb_match",
                            "snippet": f"{info['scale']}，{info['need']}",
                        })
                return results[:12]

        return []

    def infer_industry(self, keyword: str, location: str = "大连") -> str:
        for pattern, info in self.INDUSTRY_PATTERNS.items():
            if pattern in keyword:
                return info.get("industry", "")
        for pattern, info in self.INDUSTRY_PATTERNS.items():
            overlap = sum(1 for ch in pattern if ch in keyword)
            if overlap >= 2:
                return info.get("industry", "")
        return (
            f"「{keyword}」作为消费品/工业品品类，在{location}地区通过经销商、批发市场、"
            f"商超便利店和电商平台等多种渠道流通。从生产端到消费端的物流链条中，"
            f"同城配送是连接区域经销商与终端门店的关键环节。"
            f"目前{location}该品类多以经销商自配或第三方快递为主，"
            f"缺乏针对该品类的专业化同城配送解决方案，存在时效不稳定、旺季运力不足、"
            f"货物损耗率高等痛点，是物流企业差异化切入的机会。"
        )


def generate_dynamic_reviews(keyword: str, companies: list[dict] = None, count: int = None) -> list[dict]:
    """委托引擎的动态评论生成器"""
    from analyzer.engine import InsightEngine
    reviews = InsightEngine().generate_demo_reviews(keyword, companies)
    if count is not None:
        return reviews[:count]
    return reviews
