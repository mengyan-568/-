"""
电商评论采集器
仅采集公开可访问的页面内容
"""
import re
import time
import requests
from bs4 import BeautifulSoup


class EcommerceCollector:

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                          "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept-Language": "zh-CN,zh;q=0.9",
        })

    def search(self, keyword: str, max_results: int = 100) -> list[dict]:
        """从公开来源采集评论数据"""
        reviews = []
        reviews.extend(self._fetch_from_zhihu(keyword, max(10, max_results // 3)))
        time.sleep(1)
        reviews.extend(self._fetch_from_tieba(keyword, max(10, max_results // 3)))
        time.sleep(1)
        reviews.extend(self._fetch_from_douban(keyword, max(10, max_results // 3)))
        return reviews

    def _fetch_from_zhihu(self, keyword: str, limit: int) -> list[dict]:
        """知乎搜索 — 公开问题摘要"""
        reviews = []
        try:
            url = "https://www.zhihu.com/search"
            params = {"type": "content", "q": f"{keyword} 差评 体验 怎么样"}
            resp = self.session.get(url, params=params, timeout=15)
            soup = BeautifulSoup(resp.text, "lxml")
            for item in soup.find_all(["div", "span"], class_=re.compile(r"RichText|ContentItem|summary", re.I))[:limit]:
                text = item.get_text(strip=True)
                if len(text) > 15:
                    reviews.append({"source": "知乎", "content": text, "rating": None})
        except Exception as e:
            print(f"[Ecommerce] 知乎采集失败: {e}")
        return reviews

    def _fetch_from_tieba(self, keyword: str, limit: int) -> list[dict]:
        """百度贴吧搜索 — 公开帖子摘要"""
        reviews = []
        try:
            url = "https://tieba.baidu.com/f"
            params = {"kw": keyword, "ie": "utf-8"}
            resp = self.session.get(url, params=params, timeout=15)
            soup = BeautifulSoup(resp.text, "lxml")
            for item in soup.find_all("div", class_=re.compile(r"threadlist_title|threadlist_text", re.I))[:limit]:
                text = item.get_text(strip=True)
                if len(text) > 8:
                    reviews.append({"source": "百度贴吧", "content": text, "rating": None})
        except Exception as e:
            print(f"[Ecommerce] 贴吧采集失败: {e}")
        return reviews

    def _fetch_from_douban(self, keyword: str, limit: int) -> list[dict]:
        """豆瓣搜索 — 公开评论摘要"""
        reviews = []
        try:
            url = "https://www.douban.com/search"
            params = {"q": f"{keyword} 差评"}
            resp = self.session.get(url, params=params, timeout=15,
                                    headers={"Referer": "https://www.douban.com"})
            soup = BeautifulSoup(resp.text, "lxml")
            for item in soup.find_all("div", class_=re.compile(r"result|content|comment", re.I))[:limit]:
                text = item.get_text(strip=True)
                if len(text) > 15:
                    reviews.append({"source": "豆瓣", "content": text, "rating": None})
        except Exception as e:
            print(f"[Ecommerce] 豆瓣采集失败: {e}")
        return reviews
