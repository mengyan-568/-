"""
官方商机渠道爬虫 — 定向抓取大连同城配送招标/货源信息

数据源（8个平台）:
  一、大连本地官方招标平台:
    1. 大连市公共资源交易平台 — ggzyjy.dl.gov.cn
    2. 大连国企阳光采购服务平台 — www.dlygcg.com
    3. 辽宁政府采购网 — www.ccgp-liaoning.gov.cn
  二、全国物流货源/同城配送商机平台:
    4. 锦程物流网 — www.jctrans.com
    5. 必德物流招标网 — www.56bid.com
    6. 九州物流网 — www.wl890.com
    7. 物通网 — www.chinawutong.com
  三、国家级权威招标总平台:
    8. 中国招标投标公共服务平台 — www.cebpubservice.com
"""
import json
import logging
import re
import time
import random
from datetime import datetime
from urllib.parse import quote

logger = logging.getLogger("official_channels")

# 五大行业关键词映射
INDUSTRY_KEYWORDS = {
    "餐饮配送": ["食堂", "餐饮", "食材", "厨房", "餐厅", "饭店", "配餐", "团餐", "午晚餐", "中央厨房"],
    "生鲜冷链": ["生鲜", "冷链", "冷藏", "冷冻", "海鲜", "水产", "果蔬", "冷鲜", "温控", "冰鲜", "樱桃", "农产品"],
    "医药配送": ["医药", "药品", "医疗", "器械", "试剂", "疫苗", "GSP", "药房", "医院", "中药", "冷链药品"],
    "家具配送": ["家具", "家居", "搬家", "安装", "大件", "沙发", "床垫", "衣柜", "办公家具", "宜家"],
    "商超补货": ["商超", "超市", "便利店", "补货", "日配", "鲜食", "百货", "零售", "门店", "连锁"],
}

# 大连区域关键词
DALIAN_KEYWORDS = ["大连", "中山区", "西岗区", "沙河口区", "甘井子", "金州", "旅顺", "开发区", "高新园区", "瓦房店", "庄河", "普兰店", "长海"]


class OfficialChannelCrawler:
    """官方商机渠道定向爬虫"""

    def __init__(self, city: str = "大连"):
        self.city = city
        self._session = None

    def _get_session(self):
        if self._session is None:
            try:
                import requests
                self._session = requests.Session()
                self._session.headers.update({
                    "User-Agent": (
                        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
                    ),
                    "Accept-Language": "zh-CN,zh;q=0.9",
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                })
            except ImportError:
                self._session = None
        return self._session

    def _search_web(self, query: str, count: int = 8) -> list[dict]:
        """通过 DuckDuckGo 搜索"""
        results = []
        try:
            from duckduckgo_search import DDGS
            with DDGS() as ddgs:
                for r in ddgs.text(query, max_results=count):
                    results.append({
                        "title": r.get("title", ""),
                        "snippet": r.get("body", ""),
                        "url": r.get("href", ""),
                    })
        except ImportError:
            pass
        except Exception as e:
            logger.debug(f"DuckDuckGo search failed: {e}")

        if not results:
            try:
                session = self._get_session()
                if session:
                    url = f"https://www.sogou.com/web?query={quote(query)}"
                    resp = session.get(url, timeout=10)
                    html = resp.text
                    titles = re.findall(r'<a[^>]*id="[^"]*"[^>]*>(.*?)</a>', html)
                    snippets = re.findall(r'<p[^>]*class="[^"]*str[^"]*"[^>]*>(.*?)</p>', html)
                    for i in range(min(len(titles), len(snippets), count)):
                        title = re.sub(r'<[^>]+>', '', titles[i]).strip()
                        snippet = re.sub(r'<[^>]+>', '', snippets[i]).strip()
                        if title and snippet:
                            results.append({"title": title, "snippet": snippet, "url": ""})
            except Exception as e:
                logger.debug(f"Sogou search failed: {e}")

        return results

    def _classify_industry(self, text: str) -> list[str]:
        """根据文本内容分类到五大行业"""
        matched = []
        for industry, keywords in INDUSTRY_KEYWORDS.items():
            score = sum(1 for kw in keywords if kw in text)
            if score >= 2:
                matched.append(industry)
        return matched if matched else ["餐饮配送"]

    def _is_dalian_related(self, text: str) -> bool:
        """检查是否与大连相关"""
        return any(kw in text for kw in DALIAN_KEYWORDS)

    def _is_delivery_related(self, text: str) -> bool:
        """检查是否与同城配送相关"""
        delivery_kw = ["配送", "运输", "物流", "货运", "送货", "搬运", "补货", "冷链",
                       "招标", "采购", "承运", "运力", "车辆", "司机", "同城"]
        return any(kw in text for kw in delivery_kw)

    # ================================================================
    # 定向抓取
    # ================================================================

    def crawl_platform(self, platform: dict) -> list[dict]:
        """抓取单个平台的大连同城配送商机"""
        name = platform["name"]
        site = platform.get("site", "")
        queries = platform.get("search_queries", [])

        logger.info("抓取 %s ...", name)
        results = []

        for query in queries:
            try:
                items = self._search_web(query, count=5)
                for item in items:
                    text = item.get("title", "") + " " + item.get("snippet", "")
                    if not self._is_delivery_related(text):
                        continue
                    if not self._is_dalian_related(text):
                        continue

                    industries = self._classify_industry(text)
                    results.append({
                        "platform": name,
                        "platform_url": platform["url"],
                        "platform_type": platform["type"],
                        "title": item.get("title", "")[:150],
                        "snippet": item.get("snippet", "")[:300],
                        "url": item.get("url", ""),
                        "industries": industries,
                        "crawled_at": datetime.now().isoformat(),
                    })
                time.sleep(random.uniform(0.8, 1.5))
            except Exception as e:
                logger.debug(f"  {name} query '{query[:30]}' failed: {e}")

        logger.info("  %s: 找到 %d 条商机", name, len(results))
        return results

    def crawl_all(self) -> dict:
        """全量抓取所有平台"""
        platforms = get_all_platforms()
        all_results = []
        platform_stats = {}

        for p in platforms:
            items = self.crawl_platform(p)
            all_results.extend(items)
            platform_stats[p["name"]] = len(items)

        # 按行业分类
        by_industry = {"餐饮配送": [], "生鲜冷链": [], "医药配送": [], "家具配送": [], "商超补货": []}
        for item in all_results:
            for ind in item.get("industries", []):
                if ind in by_industry:
                    by_industry[ind].append(item)

        # If no results from real crawl, use demo data
        if len(all_results) == 0:
            all_results = _generate_demo_opportunities(self.city)
            for item in all_results:
                platform_stats[item["platform"]] = platform_stats.get(item["platform"], 0) + 1
                for ind in item.get("industries", []):
                    if ind in by_industry:
                        by_industry[ind].append(item)

        return {
            "city": self.city,
            "crawled_at": datetime.now().isoformat(),
            "total_opportunities": len(all_results),
            "platform_stats": platform_stats,
            "by_industry": {k: len(v) for k, v in by_industry.items()},
            "opportunities": all_results,
            "by_industry_detail": by_industry,
            "data_source": "demo" if len(all_results) > 0 and all_results[0].get("_demo") else "realtime",
        }


# ================================================================
# 8个平台配置
# ================================================================

def get_all_platforms() -> list[dict]:
    """获取所有官方商机平台配置"""
    return [
        # ===== 一、大连本地官方招标平台 =====
        {
            "name": "大连市公共资源交易平台",
            "url": "https://ggzyjy.dl.gov.cn",
            "type": "官方招标",
            "site": "ggzyjy.dl.gov.cn",
            "description": "大连政府采购、食堂/商超/医药配送招标公告",
            "authority": "大连市公共资源交易中心",
            "source_category": "政府招标",
            "adapt_industries": ["餐饮配送", "生鲜冷链", "医药配送", "商超补货"],
            "search_queries": [
                "大连市公共资源交易平台 配送 招标公告",
                "大连 政府采购 食堂食材 配送 招标",
                "大连 公共资源 冷链 运输 采购",
                "ggzyjy.dl.gov.cn 大连 招标",
            ],
        },
        {
            "name": "大连国企阳光采购服务平台",
            "url": "https://www.dlygcg.com",
            "type": "官方招标",
            "site": "dlygcg.com",
            "description": "大连本地国企采购需求集中发布",
            "authority": "大连市国资委",
            "source_category": "政府招标",
            "adapt_industries": ["餐饮配送", "家具配送", "生鲜冷链", "商超补货"],
            "search_queries": [
                "大连国企阳光采购 配送 物流 招标",
                "dlygcg 大连 食堂食材 采购公告",
                "大连国资委 国企采购 运输配送",
            ],
        },
        {
            "name": "辽宁政府采购网",
            "url": "http://www.ccgp-liaoning.gov.cn",
            "type": "官方招标",
            "site": "ccgp-liaoning.gov.cn",
            "description": "省级大连区域配送项目，医药冷链/生鲜/机关后勤大单",
            "authority": "辽宁省财政厅",
            "source_category": "政府招标",
            "adapt_industries": ["医药配送", "生鲜冷链", "餐饮配送", "商超补货"],
            "search_queries": [
                "辽宁政府采购网 大连 配送 招标公告",
                "大连 政府采购 冷链 医药 运输",
                "ccgp-liaoning 大连 食堂食材 配送",
            ],
        },
        # ===== 二、全国物流货源/同城配送商机平台 =====
        {
            "name": "锦程物流网",
            "url": "https://www.jctrans.com",
            "type": "物流货源",
            "site": "jctrans.com",
            "description": "大连本土老牌物流B2B平台，海量同城货运/冷链/家具运输商机",
            "authority": "锦程国际物流集团",
            "source_category": "企业货源",
            "adapt_industries": ["餐饮配送", "生鲜冷链", "家具配送", "商超补货"],
            "search_queries": [
                "锦程物流网 大连 同城配送 货源",
                "jctrans 大连 冷链货运 需求",
                "大连 锦程物流 同城运输 商机",
            ],
        },
        {
            "name": "必德物流招标网",
            "url": "http://www.56bid.com",
            "type": "物流货源",
            "site": "56bid.com",
            "description": "专业物流招投标聚合站，可定位大连城市筛选商机",
            "authority": "必德物流招标网",
            "source_category": "企业货源",
            "adapt_industries": ["餐饮配送", "生鲜冷链", "医药配送", "家具配送", "商超补货"],
            "search_queries": [
                "必德物流招标网 大连 配送 招标公告",
                "56bid 大连 冷链运输 招标",
                "大连 物流招标 同城配送 56bid",
            ],
        },
        {
            "name": "九州物流网",
            "url": "http://www.wl890.com",
            "type": "物流货源",
            "site": "wl890.com",
            "description": "个人商家、小店、批发市场实时发布同城拉货/补货/搬家需求",
            "authority": "九州物流网",
            "source_category": "个人商家需求",
            "adapt_industries": ["餐饮配送", "家具配送", "商超补货"],
            "search_queries": [
                "九州物流网 大连 同城货运 需求",
                "wl890 大连 搬家配送 货源",
                "大连 九州物流 补货 拉货 商机",
            ],
        },
        {
            "name": "物通网",
            "url": "https://www.chinawutong.com",
            "type": "物流货源",
            "site": "chinawutong.com",
            "description": "生鲜、商超短途补货、冷链同城即时货源，可筛选大连区域",
            "authority": "物通网",
            "source_category": "企业货源",
            "adapt_industries": ["生鲜冷链", "商超补货", "餐饮配送"],
            "search_queries": [
                "物通网 大连 冷链配送 货源",
                "chinawutong 大连 生鲜货运 需求",
                "大连 物通 同城配送 商超补货",
            ],
        },
        # ===== 三、国家级权威招标总平台 =====
        {
            "name": "中国招标投标公共服务平台",
            "url": "https://www.cebpubservice.com",
            "type": "官方招标",
            "site": "cebpubservice.com",
            "description": "国家级权威招标平台，所有大额同城配送政府采购项目同步公示",
            "authority": "国家发展改革委",
            "source_category": "政府招标",
            "adapt_industries": ["餐饮配送", "生鲜冷链", "医药配送", "家具配送", "商超补货"],
            "search_queries": [
                "中国招标投标公共服务平台 大连 配送 招标",
                "cebpubservice 大连 冷链采购 公告",
                "大连 国家级招标 同城物流 配送项目",
            ],
        },
    ]



def _generate_demo_opportunities(city: str) -> list[dict]:
    """生成演示商机数据（当真实爬虫无结果时使用）"""
    import random
    now_iso = datetime.now().isoformat()
    today_str = datetime.now().strftime("%Y-%m-%d")
    yesterday = (datetime.now() - __import__('datetime').timedelta(days=1)).strftime("%Y-%m-%d")
    three_days_ago = (datetime.now() - __import__('datetime').timedelta(days=3)).strftime("%Y-%m-%d")
    five_days_ago = (datetime.now() - __import__('datetime').timedelta(days=5)).strftime("%Y-%m-%d")
    last_week = (datetime.now() - __import__('datetime').timedelta(days=7)).strftime("%Y-%m-%d")
    older = (datetime.now() - __import__('datetime').timedelta(days=14)).strftime("%Y-%m-%d")

    # Time distribution: 3 today, 5 this week, 5 last week, 3 older
    times = (
        [today_str] * 3 +
        [yesterday] * 1 + [three_days_ago] * 2 + [five_days_ago] * 2 +
        [last_week] * 3 + [last_week] * 2 +
        [older] * 2 + [older]
    )

    return [
        {"platform": "大连市公共资源交易平台", "platform_url": "https://ggzyjy.dl.gov.cn", "platform_type": "官方招标", "title": "大连市XX中学食堂食材配送服务采购项目招标公告", "snippet": "大连市XX中学2024-2025年度食堂食材（含粮油、蔬菜、肉禽、调料）同城配送服务采购，预算金额约120万元/年，要求每日凌晨5:30前配送到位，需具备食品经营许可证及冷链配送能力。", "url": "https://ggzyjy.dl.gov.cn", "industries": ["餐饮配送", "生鲜冷链"], "crawled_at": now_iso, "published_at": times[15], "_demo": True},
        {"platform": "大连市公共资源交易平台", "platform_url": "https://ggzyjy.dl.gov.cn", "platform_type": "官方招标", "title": "大连市XX区机关事务服务中心食堂食材同城配送项目", "snippet": "为XX区5个机关食堂提供工作日早、午餐食材同城配送服务，包括生鲜蔬菜、冷鲜肉、冻品、调味品等，合同期2年，预算约200万元/年。要求配送车辆配备温控设备。", "url": "https://ggzyjy.dl.gov.cn", "industries": ["餐饮配送", "生鲜冷链"], "crawled_at": now_iso, "published_at": times[14], "_demo": True},
        {"platform": "大连国企阳光采购服务平台", "platform_url": "https://www.dlygcg.com", "platform_type": "官方招标", "title": "大连XX集团职工食堂食材及配送服务采购公告", "snippet": "大连市属国企XX集团职工食堂（3个厂区）食材同城配送服务招标，含蔬菜、肉禽蛋、粮油、调味品等品类，要求每日7:00前送达各厂区食堂，年采购额约150万元。", "url": "https://www.dlygcg.com", "industries": ["餐饮配送", "商超补货"], "crawled_at": now_iso, "published_at": times[13], "_demo": True},
        {"platform": "大连国企阳光采购服务平台", "platform_url": "https://www.dlygcg.com", "platform_type": "官方招标", "title": "大连XX集团办公家具采购及同城配送安装服务项目", "snippet": "大连国企XX集团新办公楼办公家具采购项目，含办公桌椅、文件柜、会议桌等同城配送及上门安装服务，预算约80万元。要求配送方具备家具搬运安装经验。", "url": "https://www.dlygcg.com", "industries": ["家具配送"], "crawled_at": now_iso, "published_at": times[12], "_demo": True},
        {"platform": "辽宁政府采购网", "platform_url": "http://www.ccgp-liaoning.gov.cn", "platform_type": "官方招标", "title": "大连市XX医院药品冷链配送服务采购项目", "snippet": "大连市XX医院药品（含冷链药品）从医药公司仓库到医院的同城配送服务，要求GSP认证、全程温控记录（2-8°C）、每日配送+夜间急送2小时必达，年预算约60万元。", "url": "http://www.ccgp-liaoning.gov.cn", "industries": ["医药配送"], "crawled_at": now_iso, "published_at": times[11], "_demo": True},
        {"platform": "辽宁政府采购网", "platform_url": "http://www.ccgp-liaoning.gov.cn", "platform_type": "官方招标", "title": "大连市XX区中小学营养餐食材同城配送服务", "snippet": "为XX区15所中小学提供营养餐食材（含冷链鲜奶、冷鲜肉、蔬菜水果）同城日配服务，要求凌晨5:00前配送到各校食堂，合同期1年，预算约300万元。", "url": "http://www.ccgp-liaoning.gov.cn", "industries": ["餐饮配送", "生鲜冷链"], "crawled_at": now_iso, "published_at": times[10], "_demo": True},
        {"platform": "锦程物流网", "platform_url": "https://www.jctrans.com", "platform_type": "物流货源", "title": "大连甘井子→中山区 冷链食材日配运力需求", "snippet": "大连本地生鲜配送企业长期需求：甘井子仓储中心→中山区/西岗区各餐厅冷链食材日配，需要4.2m冷藏车2-3台，每日凌晨4:00发车，月结运费约2-3万元/车。", "url": "https://www.jctrans.com", "industries": ["生鲜冷链", "餐饮配送"], "crawled_at": now_iso, "published_at": times[9], "_demo": True},
        {"platform": "锦程物流网", "platform_url": "https://www.jctrans.com", "platform_type": "物流货源", "title": "大连湾海鲜市场→市区餐厅 冷链配送运力招募", "snippet": "大连湾辽渔市场海鲜批发商长期招募：大连湾→市区各餐厅/酒店的海鲜冷链配送运力，需要冷藏车（含增氧设备），每日凌晨3:00-7:00配送，单趟300-500元。", "url": "https://www.jctrans.com", "industries": ["生鲜冷链"], "crawled_at": now_iso, "published_at": times[8], "_demo": True},
        {"platform": "必德物流招标网", "platform_url": "http://www.56bid.com", "platform_type": "物流货源", "title": "大连XX连锁便利店2024年度同城配送承运商招标", "snippet": "大连本地连锁便利店品牌（50+门店）招标同城配送承运商：鲜食日配（凌晨4:00-6:00）+常温商品周配，要求系统对接、SLA保障（准时率>95%），年运费预算200-400万元。", "url": "http://www.56bid.com", "industries": ["商超补货"], "crawled_at": now_iso, "published_at": times[7], "_demo": True},
        {"platform": "必德物流招标网", "platform_url": "http://www.56bid.com", "platform_type": "物流货源", "title": "大连XX生鲜电商平台前置仓→消费者末端配送承运商招募", "snippet": "大连本地生鲜电商平台招募同城配送承运商：前置仓（甘井子/中山/高新区）→消费者末端配送，日均300-800单，需要面包车/冷藏车，按单结算。", "url": "http://www.56bid.com", "industries": ["生鲜冷链", "商超补货"], "crawled_at": now_iso, "published_at": times[6], "_demo": True},
        {"platform": "九州物流网", "platform_url": "http://www.wl890.com", "platform_type": "物流货源", "title": "大连中山区→甘井子 家具配送安装 长期找车", "snippet": "大连家具城→客户家家具配送+安装，需要4.2m厢货（带尾板）或平板车，周末配送为主，单趟200-400元+上楼费另计，长期合作月结。", "url": "http://www.wl890.com", "industries": ["家具配送"], "crawled_at": now_iso, "published_at": times[5], "_demo": True},
        {"platform": "九州物流网", "platform_url": "http://www.wl890.com", "platform_type": "物流货源", "title": "大连开发区→金州 建材配送 找4.2m/6.8m车", "snippet": "大连开发区建材市场→金州各工地建材同城配送，需要4.2m厢货或6.8m高栏车，日均2-3趟，长期有货，月运费约1.5-2.5万/车。", "url": "http://www.wl890.com", "industries": ["家具配送"], "crawled_at": now_iso, "published_at": times[4], "_demo": True},
        {"platform": "物通网", "platform_url": "https://www.chinawutong.com", "platform_type": "物流货源", "title": "大连旅顺樱桃产地→市区 冷链运力紧急招募（樱桃季）", "snippet": "大连旅顺樱桃种植基地紧急招募冷藏车：旅顺→大连市区冷链配送，6-7月樱桃季日均50-100单，单趟500-800元，需要0-4°C恒温冷藏车，产季包车优先。", "url": "https://www.chinawutong.com", "industries": ["生鲜冷链"], "crawled_at": now_iso, "published_at": times[3], "_demo": True},
        {"platform": "物通网", "platform_url": "https://www.chinawutong.com", "platform_type": "物流货源", "title": "大连南关岭果菜批发市场→市区 生鲜短途补货运力需求", "snippet": "大连南关岭果菜批发市场批发商长期需求：市场→市区各生鲜超市/水果店的短途补货配送，需要面包车/小型冷藏车，每日凌晨3:00-6:00配送，月运费约1-1.5万/车。", "url": "https://www.chinawutong.com", "industries": ["生鲜冷链", "商超补货"], "crawled_at": now_iso, "published_at": times[2], "_demo": True},
        {"platform": "中国招标投标公共服务平台", "platform_url": "https://www.cebpubservice.com", "platform_type": "官方招标", "title": "大连市XX区城市配送服务体系建设项目招标公告", "snippet": "大连市XX区商务局城市配送服务体系建设项目，含同城配送车辆购置、调度系统建设、冷链配送网络搭建，总投资约800万元，面向具备物流运营经验的企业招标。", "url": "https://www.cebpubservice.com", "industries": ["餐饮配送", "生鲜冷链", "医药配送", "商超补货"], "crawled_at": now_iso, "published_at": times[1], "_demo": True},
        {"platform": "中国招标投标公共服务平台", "platform_url": "https://www.cebpubservice.com", "platform_type": "官方招标", "title": "大连XX医药有限公司冷链药品同城配送服务采购", "snippet": "大连XX医药有限公司招标冷链药品同城配送服务商：从总仓到全市200+药房的冷链药品日配+夜间急送，要求GSP认证、全程温湿度监控、药品追溯码系统对接，年预算约300万元。", "url": "https://www.cebpubservice.com", "industries": ["医药配送"], "crawled_at": now_iso, "published_at": times[0], "_demo": True},
    ]


def crawl_official_channels(city: str = "大连") -> dict:
    """便捷函数：全量抓取官方商机渠道"""
    return OfficialChannelCrawler(city=city).crawl_all()
