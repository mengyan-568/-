"""
数据采集器模块

采集器:
  - web_search: 搜索引擎采集（DuckDuckGo）
  - app_store: App Store 评论采集
  - ecommerce: 电商评论采集
  - public_sources: 公开数据源采集（货拉拉/58同城/天眼查/招标/POI）
  - semi_public_sources: 半公开数据源采集（招聘/抖音/加油站/违章）
  - products: 商机挖掘产物生成（运力地图/需求热力图/竞品对标/商机清单）
"""
from .public_sources import PublicSourceCollector, collect_public_sources
from .semi_public_sources import SemiPublicSourceCollector, collect_semi_public_sources
from .products import ProductGenerator, generate_products

try:
    from .web_search import WebSearchCollector, collect_web_reviews
except ImportError:
    WebSearchCollector = None
    collect_web_reviews = None

try:
    from .app_store import AppStoreCollector
except ImportError:
    AppStoreCollector = None

try:
    from .ecommerce import EcommerceCollector
except ImportError:
    EcommerceCollector = None
