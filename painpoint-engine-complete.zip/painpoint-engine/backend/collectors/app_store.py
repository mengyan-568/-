"""
App Store 评论采集器
"""
import time
import requests


class AppStoreCollector:
    """App Store 公开评论采集"""

    BASE_URL = "https://itunes.apple.com/cn/search"
    REVIEW_URL = "https://itunes.apple.com/cn/rss/customerreviews"

    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                          "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept-Language": "zh-CN,zh;q=0.9",
        })

    def search(self, keyword: str, max_results: int = 100) -> list[dict]:
        """搜索 App Store 应用并采集评论"""
        reviews = []

        # 搜索应用
        try:
            params = {"term": keyword, "country": "cn", "entity": "software", "limit": 10}
            resp = self.session.get(self.BASE_URL, params=params, timeout=15)
            data = resp.json()

            if data.get("resultCount", 0) == 0:
                return reviews

            for app in data["results"][:3]:
                app_id = app.get("trackId")
                app_name = app.get("trackName", keyword)
                if app_id:
                    per_app = max(1, max_results // 3)
                    app_reviews = self._fetch_app_reviews(app_id, app_name, per_app)
                    reviews.extend(app_reviews)
                    time.sleep(1)
        except Exception as e:
            print(f"[AppStore] 搜索失败: {e}")

        return reviews

    def _fetch_app_reviews(self, app_id: int, app_name: str, limit: int) -> list[dict]:
        """获取单个应用的评论"""
        reviews = []
        try:
            url = f"{self.REVIEW_URL}/page=1/id={app_id}/sortby=mostrecent/json"
            resp = self.session.get(url, timeout=15)
            data = resp.json()

            entries = data.get("feed", {}).get("entry", [])
            # 第一个 entry 是应用信息，跳过
            for entry in entries[1:limit + 1] if len(entries) > 1 else []:
                content = entry.get("content", {}).get("label", "")
                rating = entry.get("im:rating", {}).get("label", "0")
                if content:
                    reviews.append({
                        "source": f"App Store - {app_name}",
                        "content": content,
                        "rating": float(rating),
                    })
        except Exception as e:
            print(f"[AppStore] 评论获取失败 (app_id={app_id}): {e}")

        return reviews
