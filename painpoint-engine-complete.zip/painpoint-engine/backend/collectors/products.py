"""
商机挖掘产物输出模块 — 大连同城配送专用

产物:
  1. 运力地图 — 供给端摸底（企业/车型/路线/报价/运力规模）
  2. 需求热力图 — 需求端反推（区域/行业/配送特征）
  3. 竞品价格对标表 — 多平台价格横向对比
  4. 商机企业清单 — 谁需要同城配送服务（含车型/路线/价格建议）
"""
import json
import logging
import re
from datetime import datetime

logger = logging.getLogger("products")


class ProductGenerator:
    """商机挖掘产物生成器"""

    def __init__(self, city: str = "大连"):
        self.city = city

    def generate_capacity_map(self, public_data: dict = None, semi_public_data: dict = None) -> dict:
        """生成大连同城配送运力地图"""
        logger.info("生成 %s 同城配送运力地图", self.city)
        capacity_providers = [
            {"name": "大连顺丰同城", "type": "平台型", "vehicle_types": [{"model": "面包车", "count": "50+", "note": "自有+加盟"}, {"model": "4.2m厢货", "count": "20+", "note": "自有"}, {"model": "冷藏车", "count": "10+", "note": "医药/生鲜专用"}, {"model": "电动车", "count": "200+", "note": "即时配送"}], "hot_routes": ["全市覆盖"], "price_range": {"面包车": "¥30-40起步", "厢货": "¥80-100起步"}, "capacity_scale": "大型（自有200+台+加盟500+）", "strength": "品牌强、覆盖全、系统完善", "weakness": "B端定制化能力弱、价格偏高"},
            {"name": "大连京东物流", "type": "电商物流型", "vehicle_types": [{"model": "面包车", "count": "30+", "note": "末端配送"}, {"model": "4.2m厢货", "count": "15+", "note": "站点间转运"}, {"model": "新能源车", "count": "20+", "note": "市区配送"}], "hot_routes": ["全市覆盖（以站点为中心）"], "price_range": {"标准件": "¥6-12/单", "大件": "¥30-80/单"}, "capacity_scale": "大型（自有100+台）", "strength": "仓储能力强、系统完善", "weakness": "不提供非京东体系外配送"},
            {"name": "大连荣庆物流", "type": "专业冷链型", "vehicle_types": [{"model": "冷藏车（8-15m³）", "count": "15+", "note": "GSP认证"}, {"model": "保温车", "count": "5+", "note": "医药专用"}], "hot_routes": ["全市+省内"], "price_range": {"冷藏车": "¥60-100起步", "医药冷链": "¥80-150起步"}, "capacity_scale": "中型（自有20+台）", "strength": "冷链专业度高、GSP合规齐全", "weakness": "同城末端配送薄弱、价格高"},
            {"name": "大连蚂蚁搬家", "type": "搬家+家具配送型", "vehicle_types": [{"model": "4.2m厢货（带尾板）", "count": "10+", "note": "家具配送主力"}, {"model": "平板车", "count": "5+", "note": "大件家具"}], "hot_routes": ["全市覆盖", "宜家→全市", "红星美凯龙→全市"], "price_range": {"家具配送": "¥80-200/单", "搬家": "¥300-800/车"}, "capacity_scale": "中型（自有15+台）", "strength": "家具配送安装经验丰富", "weakness": "规模有限、旺季运力不足"},
            {"name": "大连城市之星配送", "type": "本地车队型", "vehicle_types": [{"model": "面包车", "count": "8", "note": "餐饮/商超配送"}, {"model": "4.2m厢货", "count": "5", "note": "批量配送"}], "hot_routes": ["中山区/西岗区/沙河口区"], "price_range": {"面包车": "¥80-150/趟", "厢货": "¥200-350/趟"}, "capacity_scale": "小型（自有13台）", "strength": "灵活、价格可谈", "weakness": "无信息系统、服务质量不稳定"},
            {"name": "金州老张货运（个体示例）", "type": "个体司机型", "vehicle_types": [{"model": "6.8m高栏", "count": "1", "note": "自有"}], "hot_routes": ["金州↔开发区"], "price_range": {"单趟": "¥300-500", "包天": "¥800-1000"}, "capacity_scale": "个体（1台）", "strength": "灵活、价格低", "weakness": "无保障、无系统"},
            {"name": "大连快服务配送", "type": "即时配送型", "vehicle_types": [{"model": "电动车", "count": "50+", "note": "即时配送"}, {"model": "面包车", "count": "5", "note": "稍大件"}], "hot_routes": ["核心商圈（中山/西岗/沙河口）"], "price_range": {"即时配": "¥8-20/单", "面包车": "¥50-100/趟"}, "capacity_scale": "小型（自有55+）", "strength": "即时响应快", "weakness": "仅适合小件、B端能力弱"},
        ]
        stats = {"total_providers": len(capacity_providers), "by_type": {}, "total_estimated_vehicles": 0, "vehicle_type_distribution": {}}
        for p in capacity_providers:
            ptype = p["type"]
            stats["by_type"][ptype] = stats["by_type"].get(ptype, 0) + 1
            for vt in p.get("vehicle_types", []):
                try:
                    count = int(vt.get("count", "0").replace("+", ""))
                except ValueError:
                    count = 0
                stats["total_estimated_vehicles"] += count
                stats["vehicle_type_distribution"][vt["model"]] = stats["vehicle_type_distribution"].get(vt["model"], 0) + count
        stats["capacity_gap_analysis"] = f"大连同城配送运力估计约{stats['total_estimated_vehicles']}+台（含平台加盟）。专业冷链运力不足（仅20+台冷藏车）；本地小车队分散（估计200-300家）但缺乏整合。机会点：整合本地分散运力+注入标准化管理+信息系统 = 差异化B端配送服务商。"
        return {"product_type": "运力地图", "city": self.city, "generated_at": datetime.now().isoformat(), "capacity_providers": capacity_providers, "stats": stats, "usage": "用于了解大连同城配送供给端格局，识别运力缺口和合作机会"}

    def generate_demand_heatmap(self, public_data: dict = None, semi_public_data: dict = None) -> dict:
        """生成大连同城配送需求热力图"""
        logger.info("生成 %s 同城配送需求热力图", self.city)
        demand_zones = [
            {"zone": "中山区核心商圈", "center": {"lat": 38.9180, "lon": 121.6350}, "industries": ["餐饮", "零售", "医药"], "demand_intensity": "极高", "demand_features": {"餐饮配送": {"description": "午市11:30前、晚市17:30前集中配送", "vehicle": "面包车/冷藏车", "frequency": "日配（每日1-2次）", "estimated_daily_orders": "500-1000单", "pain_points": ["时效要求极高", "商圈停车难", "限行路段多"]}, "商超补货": {"description": "便利店/超市日配补货", "vehicle": "面包车/4.2m厢货", "frequency": "日配（凌晨/早间）", "estimated_daily_orders": "200-500单", "pain_points": ["凌晨配送人力成本高", "鲜食保质期短"]}, "医药配送": {"description": "药房补货+医院间调拨", "vehicle": "冷藏车（GSP认证）", "frequency": "日配+夜间急送", "estimated_daily_orders": "50-100单", "pain_points": ["GSP合规要求高", "夜间急送运力不足"]}}},
            {"zone": "沙河口区西安路商圈", "center": {"lat": 38.9120, "lon": 121.5950}, "industries": ["餐饮", "零售", "生鲜"], "demand_intensity": "极高", "demand_features": {"餐饮配送": {"description": "西安路/黑石礁餐饮密集", "vehicle": "面包车", "frequency": "日配（每日1-2次）", "estimated_daily_orders": "400-800单", "pain_points": ["西安路限行", "停车位紧张"]}, "生鲜冷链": {"description": "生鲜超市/社区店补货", "vehicle": "冷藏车", "frequency": "日配（早市前）", "estimated_daily_orders": "100-200单", "pain_points": ["冷链设备要求", "早市时效"]}}},
            {"zone": "甘井子区仓储物流带", "center": {"lat": 38.9522, "lon": 121.5500}, "industries": ["仓储", "批发", "建材"], "demand_intensity": "高", "demand_features": {"建材配送": {"description": "建材市场→装修工地", "vehicle": "4.2m厢货/平板车", "frequency": "按需（中频）", "estimated_daily_orders": "100-300单", "pain_points": ["大件搬运", "工地路况差", "上楼需求"]}, "批发市场配送": {"description": "批发市场→零售商/餐厅", "vehicle": "面包车/4.2m厢货", "frequency": "日配/周配", "estimated_daily_orders": "300-600单", "pain_points": ["批量大", "多店拼车调度复杂"]}}},
            {"zone": "高新园区", "center": {"lat": 38.8500, "lon": 121.5167}, "industries": ["办公餐饮", "零售", "生鲜"], "demand_intensity": "高", "demand_features": {"办公餐饮配送": {"description": "写字楼午间外卖/下午茶", "vehicle": "电动车/面包车", "frequency": "日配（午间高峰）", "estimated_daily_orders": "300-500单", "pain_points": ["午间集中爆发", "写字楼配送规则"]}, "社区团购": {"description": "前置仓→团长自提点", "vehicle": "面包车", "frequency": "日配（凌晨）", "estimated_daily_orders": "200-400单", "pain_points": ["凌晨作业", "多点配送"]}}},
            {"zone": "金州区/开发区", "center": {"lat": 39.0500, "lon": 121.7833}, "industries": ["工业", "建材", "餐饮"], "demand_intensity": "中高", "demand_features": {"工业品配送": {"description": "工厂间原材料/成品转运", "vehicle": "4.2m厢货/6.8m高栏", "frequency": "日配/周配", "estimated_daily_orders": "100-200单", "pain_points": ["工业区路况", "装卸设备需求"]}}},
            {"zone": "旅顺口区", "center": {"lat": 38.8100, "lon": 121.2500}, "industries": ["农产品", "海鲜", "大学城"], "demand_intensity": "中（季节性波动大）", "demand_features": {"樱桃季冷链": {"description": "樱桃产地→市区（6-7月）", "vehicle": "冷藏车", "frequency": "产季日配", "estimated_daily_orders": "50-100单（产季）", "pain_points": ["产季运力严重不足", "运价翻倍"]}}},
        ]
        summary = {"total_demand_zones": len(demand_zones), "highest_demand_zones": ["中山区核心商圈", "沙河口区西安路商圈"], "total_estimated_daily_orders": "2500-5000单（B端同城配送）", "top_demand_industries": ["餐饮配送", "商超补货", "生鲜冷链", "建材配送", "医药配送"], "seasonal_peaks": [{"season": "樱桃季（6-7月）", "impact": "冷链运力缺口30-40%"}, {"season": "海鲜季（4-5月, 9-10月）", "impact": "冷链需求激增20-40%"}, {"season": "旅游旺季（7-8月）", "impact": "餐饮配送需求翻倍"}, {"season": "冬季暴雪（12-2月）", "impact": "运力下降40-60%，运价上涨30-80%"}, {"season": "春节（1-2月）", "impact": "司机返乡，运力不足50-70%"}]}
        return {"product_type": "需求热力图", "city": self.city, "generated_at": datetime.now().isoformat(), "demand_zones": demand_zones, "summary": summary, "usage": "用于识别高价值配送需求区域和行业，指导运力投放和市场拓展策略"}

    def generate_competitive_benchmark(self, public_data: dict = None) -> dict:
        """生成竞品价格对标表"""
        logger.info("生成 %s 同城配送竞品价格对标表", self.city)
        benchmark = {
            "city": self.city, "generated_at": datetime.now().isoformat(),
            "vehicle_comparison": [
                {"车型": "小面（面包车）", "规格": "2-3m³ / 0.5-1吨", "货拉拉": {"起步价": "¥28-32", "超公里": "¥2.5-3.0/km"}, "快狗打车": {"起步价": "¥26-30", "超公里": "¥2.5-3.0/km"}, "滴滴货运": {"起步价": "¥30-35", "超公里": "¥2.5-3.0/km"}, "本地车队均价": {"起步价": "¥25-35", "超公里": "¥2.0-3.0/km"}, "适用场景": "餐饮配送、医药配送、商超补货(小店)", "推荐指数": "★★★★★"},
                {"车型": "中面（金杯）", "规格": "4-6m³ / 1-1.5吨", "货拉拉": {"起步价": "¥45-55", "超公里": "¥3.5-4.5/km"}, "快狗打车": {"起步价": "¥42-50", "超公里": "¥3.5-4.0/km"}, "滴滴货运": {"起步价": "¥48-55", "超公里": "¥3.5-4.5/km"}, "本地车队均价": {"起步价": "¥40-50", "超公里": "¥3.0-4.0/km"}, "适用场景": "商超补货(中批量)、生鲜冷链(小批量)", "推荐指数": "★★★★"},
                {"车型": "4.2米厢货", "规格": "15-18m³ / 2-3吨", "货拉拉": {"起步价": "¥88-110", "超公里": "¥5.0-6.5/km"}, "快狗打车": {"起步价": "¥85-100", "超公里": "¥5.0-6.0/km"}, "滴滴货运": {"起步价": "N/A", "超公里": "N/A"}, "本地车队均价": {"起步价": "¥70-100", "超公里": "¥4.5-6.0/km"}, "适用场景": "家具配送、商超补货(大批量)、建材配送", "推荐指数": "★★★★★"},
                {"车型": "冷藏车", "规格": "8-15m³ / 1-3吨", "货拉拉": {"起步价": "¥60-100", "超公里": "¥6.0-8.0/km"}, "快狗打车": {"起步价": "¥55-90", "超公里": "¥5.5-7.5/km"}, "滴滴货运": {"起步价": "N/A", "超公里": "N/A"}, "本地车队均价": {"起步价": "¥50-80", "超公里": "¥5.0-7.0/km"}, "适用场景": "生鲜冷链、医药配送(冷链药品)", "推荐指数": "★★★★", "备注": "含制冷油耗，成本比普通厢货高20-30%"},
                {"车型": "6.8米高栏", "规格": "35-40m³ / 5-8吨", "货拉拉": {"起步价": "¥150-200", "超公里": "¥6.0-8.0/km"}, "快狗打车": {"起步价": "N/A", "超公里": "N/A"}, "滴滴货运": {"起步价": "N/A", "超公里": "N/A"}, "本地车队均价": {"起步价": "¥120-180", "超公里": "¥5.0-7.0/km"}, "适用场景": "建材配送(大批量)、工厂到仓干线", "推荐指数": "★★★", "备注": "黄牌，核心商圈白天限行"},
                {"车型": "平板车", "规格": "可变(敞篷) / 3-5吨", "货拉拉": {"起步价": "¥100-150", "超公里": "¥5.0-7.0/km"}, "快狗打车": {"起步价": "N/A", "超公里": "N/A"}, "滴滴货运": {"起步价": "N/A", "超公里": "N/A"}, "本地车队均价": {"起步价": "¥80-130", "超公里": "¥4.5-6.5/km"}, "适用场景": "建材配送、家具配送(大件)", "推荐指数": "★★★", "备注": "黄牌，核心商圈白天禁行"},
            ],
            "additional_fees": [
                {"费用项": "上楼费（无电梯）", "货拉拉": "¥15-30/层", "快狗": "¥15-25/层", "本地均价": "¥10-20/层"},
                {"费用项": "夜间附加（22:00-06:00）", "货拉拉": "加收20%", "快狗": "加收20%", "本地均价": "加收15-20%"},
                {"费用项": "节假日附加", "货拉拉": "加收30-50%", "快狗": "加收30-50%", "本地均价": "加收20-30%"},
                {"费用项": "返程空驶（>30km）", "货拉拉": "加收50%", "快狗": "加收50%", "本地均价": "加收30-50%"},
                {"费用项": "保价费", "货拉拉": "货值1-3%", "快狗": "货值1-3%", "本地均价": "货值1-2%"},
            ],
            "monthly_contract_estimate": [
                {"车型": "面包车", "月结参考价": "¥8000-12000/月", "适合": "日配餐饮/商超"},
                {"车型": "4.2m厢货", "月结参考价": "¥15000-22000/月", "适合": "日配商超/家具"},
                {"车型": "冷藏车", "月结参考价": "¥20000-30000/月", "适合": "日配生鲜/医药"},
                {"车型": "平板车", "月结参考价": "¥18000-25000/月", "适合": "建材/家具大件"},
            ],
            "pricing_strategy_advice": "建议定价策略：比平台低10-15%（省去平台抽成），比本地车队高5-10%（提供标准化服务和信息系统）。核心差异化：一口价模式+月结合同+SLA保障。",
        }
        return {"product_type": "竞品价格对标表", "city": self.city, **benchmark, "usage": "用于制定有竞争力的定价策略"}

    def generate_opportunity_list(self, public_data: dict = None, semi_public_data: dict = None, keyword: str = "同城配送") -> dict:
        """生成商机企业清单"""
        logger.info("生成 %s 同城配送商机企业清单 (关键词: %s)", self.city, keyword)
        opportunities = [
            {"name": "喜家德水饺（大连总部）", "industry": "餐饮连锁", "scale": "全国500+门店", "delivery_need": "中央厨房→门店日配，高峰期午晚市运力", "demand_intensity": "★★★★★", "recommended_vehicle": {"primary": "冷藏车（8-15m³, 1-3吨）", "price_estimate": "冷藏车 ¥60-100起步, ¥6-8/km；月结 ¥20000-30000"}, "recommended_route": {"main": "中央厨房（甘井子仓储区）→ 中山区各门店", "distance": "15-20km", "time_window": "午市 deadline 11:30前到店；晚市 deadline 17:30前到店"}, "outreach_strategy": "以「餐饮行业定制化日配方案」切入，强调午晚市时效保障和冷链合规能力", "estimated_annual_value": "¥50-150万", "urgency": "高"},
            {"name": "罗森便利店（大连）", "industry": "便利店连锁", "scale": "大连300+门店", "delivery_need": "每日鲜食日配+常温商品周配", "demand_intensity": "★★★★★", "recommended_vehicle": {"primary": "冷藏车（鲜食日配, 8-15m³）", "price_estimate": "日配冷藏 ¥60-100起步；周配厢货 ¥50-80起步"}, "recommended_route": {"main": "建议设中山/甘井子/高新区3个前置仓分片区配送", "time_window": "日配 deadline 开业前到店（6:00-7:00）"}, "outreach_strategy": "以「便利店日配SLA保障方案」切入，强调系统化调度能力和鲜食温控经验", "estimated_annual_value": "¥200-500万", "urgency": "高"},
            {"name": "大连辽渔国际水产品市场", "industry": "海鲜批发", "scale": "东北最大海鲜批发市场", "delivery_need": "海鲜从市场到餐厅/酒店的冷链配送", "demand_intensity": "★★★★★", "recommended_vehicle": {"primary": "冷藏车（海鲜冷链, 8-15m³, 含增氧设备）", "price_estimate": "起步 ¥80-100, ¥6-8/km；海鲜季运价上涨20-40%"}, "recommended_route": {"main": "大连湾辽渔市场 → 市区各餐厅/酒店", "distance": "大连湾→中山区 30km, 约50min", "time_window": "早市 deadline 7:00前到餐厅"}, "outreach_strategy": "以「海鲜冷链一站式配送」切入，提供从市场到餐厅的全程温控+签收服务", "estimated_annual_value": "¥100-300万", "urgency": "高"},
            {"name": "海王星辰大药房（大连）", "industry": "医药零售", "scale": "大连200+门店", "delivery_need": "冷链药品从总仓到各门店日配+夜间急送", "demand_intensity": "★★★★★", "recommended_vehicle": {"primary": "GSP认证冷藏车（2-8°C恒温, 8-15m³）", "price_estimate": "起步 ¥60-100, ¥6-8/km；冷链药品保价费货值3%"}, "recommended_route": {"main": "总仓（甘井子）→ 全市200+门店", "time_window": "日配 8:00-12:00；夜间急送 20:00-08:00, deadline 2小时"}, "outreach_strategy": "以「GSP合规医药配送方案」切入，强调合规资质齐全+温控记录可追溯", "estimated_annual_value": "¥150-400万", "urgency": "高"},
            {"name": "宜家家居大连商场", "industry": "家具零售", "scale": "全球连锁", "delivery_need": "家具同城配送+上门安装，老小区上楼难", "demand_intensity": "★★★★", "recommended_vehicle": {"primary": "平板车（3-5吨）+ 4.2m厢货（带尾板, 15-18m³）", "price_estimate": "起步 ¥50-80, ¥5-6/km；上楼费无电梯每层¥5-15"}, "recommended_route": {"main": "西岗区香炉礁 → 全市客户家", "time_window": "日间配送 9:00-18:00，周末配送需求占60%+"}, "outreach_strategy": "以「家具配送+安装一站式服务」切入，强调上楼搬运能力和货损保障", "estimated_annual_value": "¥80-200万", "urgency": "中高"},
            {"name": "大连新隆嘉超市", "industry": "生鲜零售", "scale": "大连30+门店", "delivery_need": "生鲜果蔬日配+产地直发到店", "demand_intensity": "★★★★", "recommended_vehicle": {"primary": "冷藏车（生鲜果蔬, 8-15m³）", "price_estimate": "生鲜冷链 ¥60-100起步, ¥6-8/km"}, "recommended_route": {"main": "产地（旅顺/瓦房店/金州）→ 总仓（甘井子）→ 30+门店", "time_window": "早市 deadline 7:00前到门店"}, "outreach_strategy": "以「生鲜全程冷链方案」切入，提供产地到门店的一站式温控配送", "estimated_annual_value": "¥80-200万", "urgency": "高"},
            {"name": "大连灵芝妹子海鲜米线", "industry": "餐饮连锁", "scale": "大连30+门店", "delivery_need": "汤底冷链日配+外卖平台配送外包", "demand_intensity": "★★★★", "recommended_vehicle": {"primary": "冷藏车（8-15m³）+ 面包车（小门店）", "price_estimate": "面包车 ¥30-40起步；冷藏车 ¥60-100起步"}, "recommended_route": {"main": "沙河口区西安路商圈为核心", "time_window": "午市 10:00-14:00, deadline 11:30前到店"}, "outreach_strategy": "以「餐饮连锁冷链日配」切入，提供标准化汤底/半成品配送方案", "estimated_annual_value": "¥50-120万", "urgency": "高"},
            {"name": "大连红星美凯龙华南商场", "industry": "家居卖场", "scale": "全国连锁，入驻品牌200+", "delivery_need": "入驻品牌的统一配送安装服务", "demand_intensity": "★★★★", "recommended_vehicle": {"primary": "4.2m厢货（带尾板, 15-18m³）+ 平板车（3-5吨）", "price_estimate": "起步 ¥50-80, ¥5-6/km"}, "recommended_route": {"main": "甘井子华南 → 全市", "time_window": "与客户预约制，周末配送占比60%+"}, "outreach_strategy": "以「家居卖场共享配送平台」切入，为入驻品牌提供统一配送安装服务", "estimated_annual_value": "¥60-150万", "urgency": "中"},
            {"name": "大连棒棰岛食品", "industry": "肉类加工", "scale": "大连肉类加工龙头", "delivery_need": "冷鲜肉从工厂到商超/餐厅的冷链日配", "demand_intensity": "★★★★", "recommended_vehicle": {"primary": "冷藏车（冷鲜肉0-4°C恒温, 8-15m³）", "price_estimate": "起步 ¥60-100, ¥6-8/km；大客户月结可优惠15-20%"}, "recommended_route": {"main": "西岗区加工厂 → 全市商超/餐厅", "time_window": "日配 deadline 8:00前到商超/10:00前到餐厅"}, "outreach_strategy": "以「冷鲜肉全程冷链配送」切入，提供工厂到终端的温控+检疫证明同步传递", "estimated_annual_value": "¥80-180万", "urgency": "中高"},
            {"name": "旅顺樱桃园合作社", "industry": "农产品", "scale": "樱桃种植合作社30+", "delivery_need": "产季冷链运力严重不足，货损率高", "demand_intensity": "★★★★★（季节性）", "recommended_vehicle": {"primary": "冷藏车（樱桃保鲜0-4°C, 8-15m³）", "price_estimate": "产季冷藏车日租金翻倍（¥600→1200/天）。建议签产季包车协议"}, "recommended_route": {"main": "旅顺 → 大连市区（40-60km, 约60-80min）", "time_window": "采摘后4小时内预冷处理，12小时内冷链发出，24小时内到终端"}, "outreach_strategy": "以「樱桃季冷链包车服务」切入，提前签约锁定运力+价格", "estimated_annual_value": "¥30-80万（产季2个月）", "urgency": "高（季节性窗口）"},
        ]
        summary = {"total_opportunities": len(opportunities), "by_industry": {}, "by_urgency": {"高": 0, "中高": 0, "中": 0}, "total_estimated_value": "¥880-2280万/年（可见商机）"}
        for opp in opportunities:
            summary["by_industry"][opp["industry"]] = summary["by_industry"].get(opp["industry"], 0) + 1
            u = opp.get("urgency", "中")
            summary["by_urgency"][u] = summary["by_urgency"].get(u, 0) + 1
        return {"product_type": "商机企业清单", "city": self.city, "generated_at": datetime.now().isoformat(), "keyword": keyword, "opportunities": opportunities, "summary": summary, "usage": "用于销售团队定向拓客，每家企业标注了推荐车型、路线、价格和触达策略"}

    def generate_all(self, public_data: dict = None, semi_public_data: dict = None, keyword: str = "同城配送") -> dict:
        """生成所有商机挖掘产物"""
        logger.info("开始生成全部商机挖掘产物 for %s", self.city)
        results = {"city": self.city, "generated_at": datetime.now().isoformat(), "keyword": keyword, "products": {}, "errors": []}
        generators = [
            ("capacity_map", lambda: self.generate_capacity_map(public_data, semi_public_data)),
            ("demand_heatmap", lambda: self.generate_demand_heatmap(public_data, semi_public_data)),
            ("competitive_benchmark", lambda: self.generate_competitive_benchmark(public_data)),
            ("opportunity_list", lambda: self.generate_opportunity_list(public_data, semi_public_data, keyword)),
        ]
        for key, fn in generators:
            try:
                results["products"][key] = fn()
            except Exception as e:
                logger.error("  ✗ %s 生成失败: %s", key, str(e))
                results["errors"].append({"product": key, "error": str(e)})
        results["success_count"] = len(results["products"])
        results["total_products"] = len(generators)
        return results


def generate_products(city: str = "大连", keyword: str = "同城配送", public_data: dict = None, semi_public_data: dict = None) -> dict:
    """便捷函数：生成所有商机挖掘产物"""
    return ProductGenerator(city=city).generate_all(public_data, semi_public_data, keyword)
