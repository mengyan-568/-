"""
公开数据源采集模块 — 同城配送商机挖掘专用

数据源:
  1. 货拉拉/快狗/运满满 — 车型报价、起步价、里程计价
  2. 58同城/赶集网 — 个体司机/小车队信息、常跑路线
  3. 天眼查/企查查 — 本地注册物流/配送企业清单
  4. 招标网站 — 企业配送需求招标信息
  5. 高德/百度地图 POI — 批发市场、物流园、仓储聚集区
"""
import json
import logging
import re
from datetime import datetime
from typing import Optional

logger = logging.getLogger("public_sources")


class PublicSourceCollector:
    """公开数据源统一采集器"""

    def __init__(self, city: str = "大连", timeout: int = 15):
        self.city = city
        self.timeout = timeout

    VEHICLE_CATEGORIES = {
        "小面": {"alias": ["微面", "面包车", "小面包"], "capacity": "2-3m³", "load": "0.5-1吨"},
        "中面": {"alias": ["中面包", "金杯"], "capacity": "4-6m³", "load": "1-1.5吨"},
        "小货车": {"alias": ["微货", "平板"], "capacity": "4-6m³", "load": "1-2吨"},
        "4.2米厢货": {"alias": ["4.2m", "厢式货车", "箱货"], "capacity": "15-18m³", "load": "2-3吨"},
        "6.8米高栏": {"alias": ["6.8m", "高栏车", "高栏"], "capacity": "35-40m³", "load": "5-8吨"},
    }

    def collect_platform_pricing(self) -> dict:
        """采集货拉拉/快狗/滴滴货运在大连的公开报价"""
        logger.info("开始采集 %s 同城配送平台报价", self.city)
        pricing = {
            "city": self.city,
            "collected_at": datetime.now().isoformat(),
            "platforms": {
                "货拉拉": {
                    "小面": {"起步价": "¥28-32（含5公里）", "超公里单价": "¥2.5-3.0/公里", "等候费": "¥30/小时", "适合场景": ["餐饮配送", "医药配送", "商超补货(小店)"]},
                    "中面": {"起步价": "¥45-55（含5公里）", "超公里单价": "¥3.5-4.5/公里", "等候费": "¥40/小时", "适合场景": ["商超补货(中批量)", "生鲜冷链(小批量)"]},
                    "小货车": {"起步价": "¥55-70（含5公里）", "超公里单价": "¥4.0-5.0/公里", "等候费": "¥50/小时", "适合场景": ["建材配送", "家具配送(小件)"]},
                    "4.2米厢货": {"起步价": "¥88-110（含5公里）", "超公里单价": "¥5.0-6.5/公里", "等候费": "¥60/小时", "适合场景": ["家具配送", "商超补货(大批量)", "建材配送"]},
                    "6.8米高栏": {"起步价": "¥150-200（含10公里）", "超公里单价": "¥6.0-8.0/公里", "等候费": "¥80/小时", "适合场景": ["建材配送(大批量)", "工厂到仓干线"]},
                },
                "快狗打车": {
                    "小面": {"起步价": "¥26-30（含5公里）", "超公里单价": "¥2.5-3.0/公里", "等候费": "¥30/小时"},
                    "中面": {"起步价": "¥42-50（含5公里）", "超公里单价": "¥3.5-4.0/公里", "等候费": "¥40/小时"},
                    "4.2米厢货": {"起步价": "¥85-100（含5公里）", "超公里单价": "¥5.0-6.0/公里", "等候费": "¥55/小时"},
                },
                "滴滴货运": {
                    "小面": {"起步价": "¥30-35（含5公里）", "超公里单价": "¥2.5-3.0/公里", "等候费": "¥30/小时"},
                    "中面": {"起步价": "¥48-55（含5公里）", "超公里单价": "¥3.5-4.5/公里", "等候费": "¥40/小时"},
                },
            },
            "data_quality": "estimated",
            "disclaimer": "价格为公开渠道估算区间，实际价格以平台实时报价为准。",
        }
        pricing["price_gradient"] = self._build_price_gradient(pricing["platforms"])
        return pricing

    def _build_price_gradient(self, platforms: dict) -> list:
        gradient = []
        for vt in ["小面", "中面", "4.2米厢货"]:
            row = {"车型": vt}
            for pname, pdata in platforms.items():
                if vt in pdata:
                    row[pname] = pdata[vt].get("起步价", "N/A")
            gradient.append(row)
        return gradient

    def collect_local_freight_listings(self) -> dict:
        """采集58同城/赶集网本地货运版块信息"""
        logger.info("开始采集 %s 本地货运版块信息", self.city)
        return {
            "city": self.city,
            "collected_at": datetime.now().isoformat(),
            "hot_routes": [
                {"route": "甘井子 → 中山区", "frequency": "高频", "cargo_type": "餐饮食材/商超补货"},
                {"route": "甘井子 → 沙河口区", "frequency": "高频", "cargo_type": "生鲜/日用品"},
                {"route": "金州 → 开发区", "frequency": "高频", "cargo_type": "工业品/建材"},
                {"route": "大连湾 → 市区", "frequency": "中频", "cargo_type": "海鲜冷链"},
                {"route": "旅顺 → 市区", "frequency": "中频", "cargo_type": "樱桃/农产品(季节性)"},
                {"route": "甘井子 → 高新园区", "frequency": "中频", "cargo_type": "办公用品/餐饮"},
                {"route": "中山区 ↔ 西岗区", "frequency": "高频", "cargo_type": "短驳/即时配送"},
                {"route": "开发区 → 金州", "frequency": "中频", "cargo_type": "工厂原料/成品"},
            ],
            "price_range": {
                "面包车": {"单趟": "¥80-200", "包天": "¥400-600", "月结": "¥8000-12000"},
                "4.2m厢货": {"单趟": "¥200-500", "包天": "¥800-1200", "月结": "¥15000-22000"},
                "冷藏车": {"单趟": "¥300-600", "包天": "¥1000-1500", "月结": "¥20000-30000"},
                "平板车": {"单趟": "¥250-500", "包天": "¥900-1300", "月结": "¥18000-25000"},
            },
            "data_quality": "estimated",
            "disclaimer": "58同城/赶集网数据需通过爬虫实时采集。当前为行业经验估算。",
        }

    def collect_company_registry(self, keywords: list = None) -> dict:
        """采集大连本地注册的物流/配送企业信息"""
        logger.info("开始采集 %s 物流配送企业注册信息", self.city)
        companies = [
            {"name": "大连顺丰速运有限公司", "type": "快递+同城配送", "registered_capital": "5000万", "established": "2003年", "employee_count": "2000+", "main_business": "快递、同城急送、冷链", "vehicle_types": ["面包车", "4.2m厢货", "冷藏车"], "service_area": "全市覆盖"},
            {"name": "大连京东物流有限公司", "type": "电商物流+同城配送", "registered_capital": "3000万", "established": "2010年", "employee_count": "1500+", "main_business": "电商仓储配送、211限时达", "vehicle_types": ["面包车", "4.2m厢货", "新能源车"], "service_area": "全市覆盖"},
            {"name": "大连中通快递有限公司", "type": "快递", "registered_capital": "1000万", "established": "2005年", "employee_count": "800+", "main_business": "快递、快运", "vehicle_types": ["面包车", "4.2m厢货", "9.6m货车"], "service_area": "全市覆盖"},
            {"name": "大连德邦物流有限公司", "type": "快运+大件配送", "registered_capital": "2000万", "established": "2008年", "employee_count": "600+", "main_business": "大件快递、物流", "vehicle_types": ["4.2m厢货", "6.8m高栏", "9.6m货车"], "service_area": "全市覆盖"},
            {"name": "大连荣庆物流有限公司", "type": "专业冷链", "registered_capital": "1500万", "established": "2007年", "employee_count": "300+", "main_business": "冷链运输、医药配送", "vehicle_types": ["冷藏车", "保温车"], "service_area": "全市+省内"},
            {"name": "大连双汇物流有限公司", "type": "食品冷链", "registered_capital": "1000万", "established": "2009年", "employee_count": "200+", "main_business": "冷鲜肉配送、食品冷链", "vehicle_types": ["冷藏车"], "service_area": "全市"},
            {"name": "大连郑明现代物流有限公司", "type": "专业冷链", "registered_capital": "2000万", "established": "2011年", "employee_count": "250+", "main_business": "冷链仓储配送", "vehicle_types": ["冷藏车", "4.2m厢货"], "service_area": "全市"},
            {"name": "大连蚂蚁搬家有限公司", "type": "搬家+家具配送", "registered_capital": "500万", "established": "2012年", "employee_count": "150+", "main_business": "搬家、家具配送安装", "vehicle_types": ["4.2m厢货", "平板车"], "service_area": "全市"},
            {"name": "大连快服务配送有限公司", "type": "即时配送", "registered_capital": "300万", "established": "2016年", "employee_count": "100+", "main_business": "即时配送、跑腿", "vehicle_types": ["电动车", "面包车"], "service_area": "核心商圈"},
            {"name": "大连城市之星配送有限公司", "type": "同城配送", "registered_capital": "500万", "established": "2015年", "employee_count": "80+", "main_business": "商超补货、餐饮配送", "vehicle_types": ["面包车", "4.2m厢货"], "service_area": "中山/西岗/沙河口"},
        ]
        industry_dist = {}
        for c in companies:
            industry_dist[c["type"]] = industry_dist.get(c["type"], 0) + 1
        return {
            "city": self.city, "collected_at": datetime.now().isoformat(),
            "total_found": len(companies), "companies": companies,
            "industry_distribution": industry_dist,
            "data_quality": "estimated",
            "disclaimer": "企业信息基于公开渠道估算。实际部署时对接天眼查/企查查API获取实时数据。大连本地注册的物流配送企业估计约500-800家（含个体户）。",
        }

    def collect_bidding_info(self) -> dict:
        """采集招标网站上的同城配送需求信息"""
        logger.info("开始采集 %s 同城配送招标信息", self.city)
        bids = [
            {"title": "大连XX连锁超市2024年度同城配送服务招标", "publisher": "大连XX连锁超市有限公司", "industry": "商超零售", "demand": "日配补货，覆盖全市50+门店", "vehicle_requirement": "4.2m厢货/冷藏车", "budget_range": "面议（预计年200-500万）", "source": "中国采购与招标网"},
            {"title": "大连XX医药有限公司药品同城配送服务采购", "publisher": "大连XX医药有限公司", "industry": "医药流通", "demand": "冷链药品从总仓到药房/医院日配", "vehicle_requirement": "GSP认证冷藏车", "budget_range": "面议（预计年150-300万）", "source": "中国招标投标公共服务平台"},
            {"title": "大连XX生鲜电商平台城市配送承运商招募", "publisher": "大连XX生鲜电商", "industry": "生鲜电商", "demand": "前置仓到消费者末端配送", "vehicle_requirement": "面包车/冷藏车", "budget_range": "按单结算（预计月50-100万）", "source": "企业官网"},
            {"title": "大连XX餐饮集团中央厨房配送服务招标", "publisher": "大连XX餐饮管理有限公司", "industry": "餐饮", "demand": "中央厨房→30+门店日配", "vehicle_requirement": "冷藏车/保温车", "budget_range": "面议（预计年100-200万）", "source": "中国采购与招标网"},
            {"title": "大连XX家具城配送安装服务外包招标", "publisher": "大连XX家居有限公司", "industry": "家具家居", "demand": "家具同城配送+上门安装", "vehicle_requirement": "4.2m厢货/平板车（带尾板）", "budget_range": "按单结算", "source": "企业官网"},
        ]
        return {
            "city": self.city, "collected_at": datetime.now().isoformat(),
            "bids": bids, "data_quality": "estimated",
            "disclaimer": "招标信息为行业典型示例。实际部署时对接招标网站API或RSS实时监控。",
        }

    def collect_poi_data(self) -> dict:
        """采集大连关键物流相关POI数据"""
        logger.info("开始采集 %s 物流相关POI数据", self.city)
        pois = {
            "wholesale_markets": [
                {"name": "双兴商品城（大菜市）", "lat": 38.9220, "lon": 121.6250, "type": "综合批发", "scale": "大型", "inferred_demand": "日用品/食品全市配送"},
                {"name": "辽渔国际水产品市场", "lat": 38.9900, "lon": 121.6900, "type": "海鲜批发", "scale": "东北最大", "inferred_demand": "海鲜冷链全市+跨市配送"},
                {"name": "南关岭果菜批发市场", "lat": 38.9700, "lon": 121.5800, "type": "果蔬批发", "scale": "大型", "inferred_demand": "果蔬全市配送"},
                {"name": "金州农产品批发市场", "lat": 39.1000, "lon": 121.7200, "type": "农产品批发", "scale": "中型", "inferred_demand": "金州/开发区农产品配送"},
            ],
            "logistics_parks": [
                {"name": "大连湾物流园", "lat": 38.9833, "lon": 121.6833, "type": "综合物流园", "scale": "大型"},
                {"name": "甘井子仓储中心", "lat": 38.9522, "lon": 121.5500, "type": "仓储配送", "scale": "大型"},
                {"name": "开发区配送站", "lat": 39.0500, "lon": 121.7833, "type": "区域配送中心", "scale": "中型"},
                {"name": "高新园区前置仓", "lat": 38.8500, "lon": 121.5167, "type": "前置仓", "scale": "中型"},
            ],
            "building_materials": [
                {"name": "金州建材市场", "lat": 39.1000, "lon": 121.7200, "type": "建材批发", "scale": "大型", "inferred_demand": "建材全市配送"},
                {"name": "华南家居大世界", "lat": 38.9880, "lon": 121.5720, "type": "家居建材", "scale": "大型", "inferred_demand": "家具建材全市配送"},
                {"name": "宜家家居（香炉礁）", "lat": 38.9280, "lon": 121.6050, "type": "家居零售", "scale": "大型", "inferred_demand": "家具同城配送+安装"},
                {"name": "红星美凯龙（华南）", "lat": 38.9880, "lon": 121.5720, "type": "家居卖场", "scale": "大型", "inferred_demand": "家具同城配送+安装"},
            ],
            "commercial_clusters": [
                {"name": "青泥洼桥商圈", "lat": 38.9180, "lon": 121.6350, "type": "核心商圈", "store_count": "500+", "inferred_demand": "餐饮/零售高频补货"},
                {"name": "西安路商圈", "lat": 38.9120, "lon": 121.5950, "type": "核心商圈", "store_count": "400+", "inferred_demand": "餐饮/零售高频补货"},
                {"name": "华南广场商圈", "lat": 38.9850, "lon": 121.5700, "type": "区域商圈", "store_count": "200+", "inferred_demand": "餐饮/零售补货"},
                {"name": "高新万达商圈", "lat": 38.8550, "lon": 121.5200, "type": "区域商圈", "store_count": "150+", "inferred_demand": "餐饮/零售补货"},
            ],
        }
        return {
            "city": self.city, "collected_at": datetime.now().isoformat(),
            "pois": pois, "data_quality": "estimated",
            "disclaimer": "POI数据基于公开地图信息。实际部署时对接高德/百度地图API获取实时POI。",
        }

    def collect_all(self) -> dict:
        """采集所有公开数据源"""
        logger.info("开始全量采集公开数据源 for %s", self.city)
        results = {"city": self.city, "collected_at": datetime.now().isoformat(), "errors": []}
        collectors = [
            ("platform_pricing", self.collect_platform_pricing),
            ("local_freight", self.collect_local_freight_listings),
            ("company_registry", self.collect_company_registry),
            ("bidding_info", self.collect_bidding_info),
            ("poi_data", self.collect_poi_data),
        ]
        for key, fn in collectors:
            try:
                results[key] = fn()
            except Exception as e:
                logger.error("  ✗ %s 采集失败: %s", key, str(e))
                results["errors"].append({"source": key, "error": str(e)})
        results["success_count"] = sum(1 for k, v in results.items() if k not in ("errors", "success_count", "city", "collected_at") and v is not None)
        results["total_sources"] = len(collectors)
        return results


def collect_public_sources(city: str = "大连") -> dict:
    """便捷函数：采集所有公开数据源"""
    return PublicSourceCollector(city=city).collect_all()
