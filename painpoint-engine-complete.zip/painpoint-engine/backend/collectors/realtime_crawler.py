"""
实时公开数据爬虫 — 抓取大连同城配送相关真实需求信息

数据源:
  1. 招标/采购信息 — 中国招标投标公共服务平台、中国采购与招标网
  2. 企业发货需求 — 58同城/赶集网货运版块、货拉拉需求端
  3. 竞品价格 — 货拉拉/快狗/滴滴货运公开报价
  4. 缺口线路/空载热点 — 基于搜索数据推断
"""
import json
import logging
import re
import time
import random
from datetime import datetime
from urllib.parse import quote

logger = logging.getLogger("realtime_crawler")


class RealtimeCrawler:
    """实时公开数据爬虫"""

    def __init__(self, city: str = "大连"):
        self.city = city
        self._session = None

    def _get_session(self):
        if self._session is None:
            try:
                import requests
                self._session = requests.Session()
                self._session.headers.update({
                    "User-Agent": (
                        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                        "AppleWebKit/537.36 (KHTML, like Gecko) "
                        "Chrome/120.0.0.0 Safari/537.36"
                    ),
                    "Accept-Language": "zh-CN,zh;q=0.9",
                })
            except ImportError:
                self._session = None
        return self._session

    def _safe_fetch(self, url: str, timeout: int = 10) -> str:
        session = self._get_session()
        if not session:
            return ""
        try:
            resp = session.get(url, timeout=timeout)
            resp.raise_for_status()
            return resp.text
        except Exception as e:
            logger.debug(f"Fetch failed {url[:60]}: {e}")
            return ""

    # ================================================================
    # 1. 招标/采购信息抓取
    # ================================================================

    def crawl_bidding(self) -> dict:
        """
        抓取大连同城配送相关招标信息。
        数据源: 中国招标投标公共服务平台、中国采购与招标网
        """
        logger.info("抓取 %s 同城配送招标信息...", self.city)

        queries = [
            f"{self.city} 同城配送 招标",
            f"{self.city} 冷链配送 采购",
            f"{self.city} 物流配送 招标公告",
            f"{self.city} 城市配送 承运商 招募",
        ]

        bids = []
        for query in queries:
            try:
                # 通过搜索引擎获取招标信息摘要
                results = self._search_web(query, count=5)
                for r in results:
                    snippet = r.get("snippet", "")
                    title = r.get("title", "")
                    if any(kw in title + snippet for kw in ["招标", "采购", "公告", "招募", "承运"]):
                        bids.append({
                            "title": title[:120],
                            "snippet": snippet[:300],
                            "url": r.get("url", ""),
                            "source": "web_search",
                            "crawled_at": datetime.now().isoformat(),
                        })
            except Exception as e:
                logger.debug(f"招标搜索失败 ({query[:20]}): {e}")
            time.sleep(random.uniform(1, 2))

        return {
            "city": self.city,
            "crawled_at": datetime.now().isoformat(),
            "total_found": len(bids),
            "bids": bids,
            "data_quality": "realtime_web" if bids else "no_results",
        }

    # ================================================================
    # 2. 企业发货需求抓取
    # ================================================================

    def crawl_demand_signals(self) -> dict:
        """
        抓取企业发货需求信号。
        数据源: 58同城货运版块、搜索引擎
        """
        logger.info("抓取 %s 企业发货需求信号...", self.city)

        queries = [
            f"{self.city} 同城配送 需求 发货",
            f"{self.city} 冷链配送 找车",
            f"{self.city} 货运 急送 同城",
            f"{self.city} 物流 外包 配送",
        ]

        signals = []
        for query in queries:
            try:
                results = self._search_web(query, count=5)
                for r in results:
                    snippet = r.get("snippet", "")
                    title = r.get("title", "")
                    if len(snippet) > 20:
                        signals.append({
                            "title": title[:120],
                            "snippet": snippet[:300],
                            "url": r.get("url", ""),
                            "source": "web_search",
                        })
            except Exception as e:
                logger.debug(f"需求搜索失败 ({query[:20]}): {e}")
            time.sleep(random.uniform(1, 2))

        return {
            "city": self.city,
            "crawled_at": datetime.now().isoformat(),
            "total_signals": len(signals),
            "signals": signals,
            "data_quality": "realtime_web" if signals else "no_results",
        }

    # ================================================================
    # 3. 竞品价格抓取
    # ================================================================

    def crawl_competitor_pricing(self) -> dict:
        """
        抓取竞品平台公开报价。
        数据源: 搜索引擎中的货拉拉/快狗/滴滴货运报价信息
        """
        logger.info("抓取 %s 竞品配送价格...", self.city)

        queries = [
            f"{self.city} 货拉拉 收费标准 价格表",
            f"{self.city} 快狗打车 价格 收费标准",
            f"{self.city} 同城货运 价格 多少钱一公里",
        ]

        pricing_data = []
        for query in queries:
            try:
                results = self._search_web(query, count=5)
                for r in results:
                    snippet = r.get("snippet", "")
                    if any(kw in snippet for kw in ["元", "起步", "公里", "收费", "价格"]):
                        pricing_data.append({
                            "title": r.get("title", "")[:120],
                            "snippet": snippet[:300],
                            "url": r.get("url", ""),
                        })
            except Exception as e:
                logger.debug(f"价格搜索失败 ({query[:20]}): {e}")
            time.sleep(random.uniform(1, 2))

        return {
            "city": self.city,
            "crawled_at": datetime.now().isoformat(),
            "total_entries": len(pricing_data),
            "pricing_data": pricing_data,
            "data_quality": "realtime_web" if pricing_data else "no_results",
        }

    # ================================================================
    # 4. 缺口线路/空载热点
    # ================================================================

    def crawl_route_gaps(self) -> dict:
        """
        抓取配送缺口线路和空载热点信息。
        数据源: 搜索引擎 + 货运论坛
        """
        logger.info("抓取 %s 配送缺口线路...", self.city)

        queries = [
            f"{self.city} 货运 回程车 空车 配货",
            f"{self.city} 物流 运力不足 配送难",
            f"{self.city} 找车难 配送 高峰期",
        ]

        gaps = []
        for query in queries:
            try:
                results = self._search_web(query, count=5)
                for r in results:
                    snippet = r.get("snippet", "")
                    if len(snippet) > 20:
                        gaps.append({
                            "title": r.get("title", "")[:120],
                            "snippet": snippet[:300],
                            "url": r.get("url", ""),
                        })
            except Exception as e:
                logger.debug(f"缺口搜索失败 ({query[:20]}): {e}")
            time.sleep(random.uniform(1, 2))

        return {
            "city": self.city,
            "crawled_at": datetime.now().isoformat(),
            "total_gaps": len(gaps),
            "gaps": gaps,
            "data_quality": "realtime_web" if gaps else "no_results",
        }

    # ================================================================
    # 5. 区域订单密度/淡旺季
    # ================================================================

    def crawl_seasonal_patterns(self) -> dict:
        """
        抓取区域订单密度和淡旺季规律。
        """
        logger.info("抓取 %s 配送淡旺季规律...", self.city)

        queries = [
            f"{self.city} 配送 旺季 运力紧张",
            f"{self.city} 物流 淡季 车辆闲置",
            f"{self.city} 樱桃季 冷链 运力",
            f"{self.city} 海鲜季 配送 高峰",
        ]

        patterns = []
        for query in queries:
            try:
                results = self._search_web(query, count=3)
                for r in results:
                    snippet = r.get("snippet", "")
                    if len(snippet) > 20:
                        patterns.append({
                            "title": r.get("title", "")[:120],
                            "snippet": snippet[:300],
                            "url": r.get("url", ""),
                        })
            except Exception as e:
                logger.debug(f"季节搜索失败 ({query[:20]}): {e}")
            time.sleep(random.uniform(1, 2))

        return {
            "city": self.city,
            "crawled_at": datetime.now().isoformat(),
            "total_patterns": len(patterns),
            "patterns": patterns,
            "data_quality": "realtime_web" if patterns else "no_results",
        }

    # ================================================================
    # 搜索引擎封装
    # ================================================================

    def _search_web(self, query: str, count: int = 5) -> list[dict]:
        """通过搜索引擎获取结果"""
        results = []

        # 尝试使用 DuckDuckGo (无需 API key)
        try:
            from duckduckgo_search import DDGS
            with DDGS() as ddgs:
                for r in ddgs.text(query, max_results=count):
                    results.append({
                        "title": r.get("title", ""),
                        "snippet": r.get("body", ""),
                        "url": r.get("href", ""),
                    })
            if results:
                return results
        except ImportError:
            pass
        except Exception as e:
            logger.debug(f"DuckDuckGo search failed: {e}")

        # 尝试使用 requests + 搜狗
        try:
            session = self._get_session()
            if session:
                url = f"https://www.sogou.com/web?query={quote(query)}"
                resp = session.get(url, timeout=10, headers={
                    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
                })
                html = resp.text
                # 简单正则提取
                titles = re.findall(r'<a[^>]*id="[^"]*"[^>]*>(.*?)</a>', html)
                snippets = re.findall(r'<p[^>]*class="[^"]*str[^"]*"[^>]*>(.*?)</p>', html)
                for i in range(min(len(titles), len(snippets), count)):
                    title = re.sub(r'<[^>]+>', '', titles[i]).strip()
                    snippet = re.sub(r'<[^>]+>', '', snippets[i]).strip()
                    if title and snippet:
                        results.append({"title": title, "snippet": snippet, "url": ""})
        except Exception as e:
            logger.debug(f"Sogou search failed: {e}")

        return results

    # ================================================================
    # 全量抓取
    # ================================================================

    def crawl_all(self) -> dict:
        """全量抓取所有公开数据"""
        logger.info("开始全量抓取 %s 同城配送公开数据...", self.city)

        result = {
            "city": self.city,
            "crawled_at": datetime.now().isoformat(),
            "bidding": None,
            "demand_signals": None,
            "competitor_pricing": None,
            "route_gaps": None,
            "seasonal_patterns": None,
            "errors": [],
        }

        crawlers = [
            ("bidding", self.crawl_bidding),
            ("demand_signals", self.crawl_demand_signals),
            ("competitor_pricing", self.crawl_competitor_pricing),
            ("route_gaps", self.crawl_route_gaps),
            ("seasonal_patterns", self.crawl_seasonal_patterns),
        ]

        for key, fn in crawlers:
            try:
                result[key] = fn()
                logger.info("  ✓ %s 抓取完成", key)
            except Exception as e:
                logger.error("  ✗ %s 抓取失败: %s", key, str(e))
                result["errors"].append({"source": key, "error": str(e)})

        result["success_count"] = sum(
            1 for k, v in result.items()
            if k not in ("errors", "success_count", "city", "crawled_at")
            and v is not None
        )

        return result


def crawl_realtime_data(city: str = "大连") -> dict:
    """便捷函数：全量抓取"""
    return RealtimeCrawler(city=city).crawl_all()
