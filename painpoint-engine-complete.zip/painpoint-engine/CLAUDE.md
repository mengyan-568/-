# painpoint-engine 项目

## 项目路径
- 主项目: D:\Desktop\painpoint-engine
- 后端分析器: D:\Desktop\painpoint-engine\backend\analyzer

## 持续执行约束（与 /goal 配合）
- 任务未完成时不允许停止
- 错误必须至少尝试 2 种替代方案
- 每轮对话必须包含工具调用
- 上下文压缩后必须回顾原始目标
