"""
痛点挖掘引擎 — 独立测试脚本（动态搜索版）
直接调用分析引擎，验证完整流程（含互联网搜索）
"""
import sys
import json
import os
import io

# 强制 UTF-8 输出
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'backend'))

from analyzer.engine import InsightEngine
from collectors.web_search import WebSearchCollector, generate_dynamic_reviews
from nlp.analyzer import NLPAnalyzer


def test_pipeline(keyword="冷链物流", use_search=True):
    print(f"\n{'='*60}")
    print(f"  痛点挖掘引擎 — 测试分析: {keyword}")
    print(f"  搜索模式: {'开启' if use_search else '关闭'}")
    print(f"{'='*60}\n")

    engine = InsightEngine()
    companies = []
    industry_info = ""

    if use_search:
        try:
            print("[0/4] 正在搜索互联网...")
            searcher = WebSearchCollector()
            companies = searcher.search_companies(keyword)
            print(f"  -> 发现 {len(companies)} 家企业: {', '.join(c['name'] for c in companies[:5])}")

            industry_info = searcher.search_industry_info(keyword)
            print(f"  -> 行业信息 {len(industry_info)} 字符")

            web_reviews = searcher.search_reviews(keyword)
            print(f"  -> 搜索评论 {len(web_reviews)} 条")
        except Exception as e:
            print(f"  -> 搜索异常: {e}")
            web_reviews = []

    # 使用搜索到的企业生成模拟评论
    reviews = generate_dynamic_reviews(keyword, companies, count=200)
    if use_search and web_reviews:
        reviews = web_reviews + reviews[:200 - len(web_reviews)]

    print(f"\n[1/3] 数据采集完成: {len(reviews)} 条评论")

    nlp = NLPAnalyzer()
    analyzed = nlp.analyze_reviews(reviews)
    neg_count = sum(1 for r in analyzed if r.get("is_negative"))
    print(f"[2/3] NLP分析完成: {neg_count} 条负面 / {len(analyzed)} 条总计")

    report = engine.generate_report(keyword, analyzed, companies, industry_info)
    print(f"[3/3] 商机报告生成完成\n")

    print("-" * 50)
    print("[报告摘要]")
    print("-" * 50)
    print(report["summary"])
    print()

    print("-" * 50)
    print("[统计概览]")
    print("-" * 50)
    stats = report["stats"]
    print(f"  总评论数: {stats['total_reviews']}")
    print(f"  负面评论: {stats['total_negative']}")
    print(f"  负面率:   {stats['negativity_rate']*100:.1f}%")
    print()

    print("-" * 50)
    print("[行业分析]")
    print("-" * 50)
    print(report.get("industry_analysis", "N/A"))
    print()

    print("-" * 50)
    print("[目标商家]")
    print("-" * 50)
    for m in report.get("target_merchants", [])[:8]:
        print(f"  {m['name']} | {m['area']} | {m['scale']} | 匹配: {m['match']}")
        print(f"    -> {m['need']}")
    print()

    print("-" * 50)
    print("[痛点热度分布]")
    print("-" * 50)
    for item in report["pain_heatmap"][:5]:
        bar = "#" * min(40, item["count"])
        print(f"  {item['category']:<10s} {bar} {item['count']}条 (痛感: {item['avg_pain_score']:.2f})")
    print()

    print("-" * 50)
    print("[痛点深度分析]")
    print("-" * 50)
    print(report.get("pain_deepdive", "N/A"))
    print()

    print("-" * 50)
    print("[商机排序]")
    print("-" * 50)
    for i, opp in enumerate(report["opportunities"][:5], 1):
        flag = "HIGH" if opp["score"] > 30 else "MID " if opp["score"] > 15 else "LOW "
        print(f"  #{i} [{flag}] {opp['category']:<10s} score={opp['score']:>5.1f}  pay={opp['willingness_to_pay']}")
        print(f"      -> {opp['suggestion']}")
    print()

    print("-" * 50)
    print("[行动建议]")
    print("-" * 50)
    print(report.get("action_plan", "N/A"))
    print()

    print("-" * 50)
    print("[高频关键词 Top 15]")
    print("-" * 50)
    words = [w["word"] for w in report["wordcloud"][:15]]
    print(f"  {', '.join(words)}")
    print()

    print("[OK] 测试通过!")
    return report


if __name__ == "__main__":
    for kw in ["卫生纸", "餐饮配送"]:
        test_pipeline(kw, use_search=True)
