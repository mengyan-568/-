# 商机跟踪面板 — Bug 修复 + 企业级优化方案

## Context

**根因**：后端 ID 是 UUID 字符串（`3f207c9d-96de-4e3d-a671-6a44ac0db4e1`），前端用 `parseInt(btn.dataset.id)` 解析只得到 `3`，导致 `oppCache[id]` 永远查不到数据，`showDetail()` / `editOpp()` 静默失败。**已修复** `app.js` 中 3 处 `parseInt`。

**辅助修复**：SortableJS 缺少 `filter` 选项会拦截卡片内按钮的 mousedown 事件。**已添加** `filter: '.kanban-card-actions, .kanban-card-name'` 和 `preventOnFilter: false`。

## 企业级优化清单

### Phase 1：基础工具（app.js）
- [ ] **Toast 通知系统**：`showToast(message, type, duration)` — 替代所有静默失败，支持 success/error/info/warning
- [ ] **Debounce 工具**：搜索输入用 `debounce(fn, 300)` 防抖，避免每次按键都发 API 请求
- [ ] **Modal 动画**：`openModal(id)` / `closeModal(id)` 替换所有 `display = 'none'/'flex'`

### Phase 2：CSS 增强（style.css）
- [ ] **Toast 样式**：固定右上角，滑入动画，4 种颜色方案
- [ ] **Modal 动画**：opacity 淡入 + transform scale 弹入
- [ ] **按钮加载态**：`.is-loading` 显示旋转 spinner，禁用点击
- [ ] **空列拖放提示**：`::after` 伪元素显示"拖拽商机卡片到此处"
- [ ] **自定义确认框**：替代浏览器原生 `confirm()`，带动画
- [ ] **看板骨架屏**：`.kanban-skeleton` 数据加载前的占位效果
- [ ] **统计数据脉冲动画**：数字更新时短暂缩放
- [ ] **卡片下次跟进日期**：`.kanban-card-due` 超期红色高亮
- [ ] **详情时间线样式**：`.timeline-entry` 活动记录布局

### Phase 3：错误处理 & UX 加固（app.js）
- [ ] **所有 API 调用加 try/catch**：`apiDelete`/`apiRestore`/`apiPurge`/`apiArchive`/`apiUnarchive`/`saveOpportunity`/`confirmClose`/`addFollowUp`
- [ ] **表单校验反馈**：空商家名称时 toast 提示 + 输入框红色高亮 + 聚焦
- [ ] **按钮 loading 态**：保存/确认按钮在请求期间显示 spinner
- [ ] **修复 SortableJS 拖拽 bug**：`onEnd` 不再发送 `deal_amount: 0`，只传 `status` + `note`
- [ ] **自定义确认框**：`showConfirm(message, onConfirm)` 替代 `confirm()`
- [ ] **看板加载骨架屏**：`loadTrackingBoard()` 先渲染骨架再请求数据

### Phase 4：功能增强（app.js + index.html）
- [ ] **CSV 导出**：列表视图增加导出按钮，BOM 头保证 Excel 兼容
- [ ] **看板卡片显示下次跟进日期**：后端已返回 `next_follow` 字段
- [ ] **详情弹窗加载活动时间线**：调用 `GET /api/track/opportunities/{id}/timeline`
- [ ] **键盘快捷键**：Escape 关闭弹窗、Ctrl+N 新建商机
- [ ] **统计数字脉冲动画**：数据更新时触发 `counting` 动画类

### Phase 5：HTML 微调（index.html）
- [ ] 顶部栏增加 CSV 导出按钮（`data-action="export-csv"`，默认隐藏）
- [ ] 事件代理新增 `export-csv` case

## 修改文件

| 文件 | 改动类型 |
|---|---|
| `frontend/js/app.js` | 大量：Toast/debounce/API 包装/确认框/动画/导出/快捷键/时间线/骨架屏 |
| `frontend/css/style.css` | 新增约 200 行 CSS |
| `frontend/index.html` | 微小：1 个导出按钮 |

## 验证方式

1. 点击看板卡片"详情"/"编辑"按钮 → 弹窗正常弹出
2. 保存空商家名称 → 红色 toast 提示 + 输入框高亮
3. 快速输入搜索词 → 只发 1 次 API 请求
4. 拖拽卡片到其他列 → deal_amount 不被清零
5. 删除商机 → 自定义确认框弹出
6. 全部商机页 → CSV 导出按钮出现，点击下载
7. Escape → 关闭所有弹窗
8. 详情弹窗 → 底部显示活动时间线
