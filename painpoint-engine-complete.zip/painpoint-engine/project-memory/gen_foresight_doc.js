const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, HeadingLevel, BorderStyle, WidthType,
  ShadingType, VerticalAlign, PageNumber, PageBreak, LevelFormat,
  ExternalHyperlink, TabStopType, TabStopPosition
} = require('docx');
const fs = require('fs');

// ─── 颜色定义 (GitHub 风格 + 橙色品牌) ───────────────────────────
const COLOR = {
  brand: 'E05C00',       // 品牌橙
  brandLight: 'FFF0E6',  // 浅橙背景
  dark: '1A1A2E',        // 深蓝黑标题
  mid: '2D3561',         // 中蓝副标题
  text: '2C2C2C',        // 正文深灰
  muted: '6E7891',       // 辅助灰
  border: 'D0D7DE',      // GitHub 边框灰
  tableHead: '0969DA',   // GitHub 蓝表头
  tableHeadBg: 'DFF0FF', // 表头浅蓝背景
  stripe: 'F6F8FA',      // 斑马纹浅灰
  success: '1A7F37',     // 绿色
  codeBg: 'F6F8FA',      // 代码块背景
  accent: 'CF222E',      // 强调红
  gold: 'BF8700',        // 黄金强调
};

// ─── 页面参数 ──────────────────────────────────────────────────
const PAGE_W = 11906;  // A4 宽度 DXA
const PAGE_H = 16838;  // A4 高度 DXA
const MARGIN = 1000;   // 页边距 (约 1.76cm)
const CONTENT_W = PAGE_W - MARGIN * 2;  // 9906

// ─── 通用样式辅助 ──────────────────────────────────────────────
function cellBorder(color = COLOR.border) {
  const b = { style: BorderStyle.SINGLE, size: 1, color };
  return { top: b, bottom: b, left: b, right: b };
}

function noBorder() {
  const b = { style: BorderStyle.NONE, size: 0, color: 'FFFFFF' };
  return { top: b, bottom: b, left: b, right: b };
}

function para(children, opts = {}) {
  return new Paragraph({ children, ...opts });
}

function run(text, opts = {}) {
  return new TextRun({ text, font: 'Source Han Sans CN', ...opts });
}

function bold(text, opts = {}) {
  return run(text, { bold: true, ...opts });
}

// ─── 分隔线段落 ───────────────────────────────────────────────
function hrLine(color = COLOR.brand, thickness = 8) {
  return new Paragraph({
    children: [new TextRun({ text: '' })],
    border: { bottom: { style: BorderStyle.SINGLE, size: thickness, color, space: 1 } },
    spacing: { before: 0, after: 120 },
  });
}

function thinHr(color = COLOR.border) {
  return new Paragraph({
    children: [new TextRun({ text: '' })],
    border: { bottom: { style: BorderStyle.SINGLE, size: 2, color, space: 1 } },
    spacing: { before: 60, after: 60 },
  });
}

// ─── 章节标题（带左侧色条效果用表格实现）──────────────────────────
function sectionTitle(text, icon = '') {
  // 用一个单行无边框表格 + 背景色单元格来模拟 GitHub 风格 section header
  const colW1 = 160;  // 色条宽度
  const colW2 = CONTENT_W - colW1;
  return new Table({
    width: { size: CONTENT_W, type: WidthType.DXA },
    columnWidths: [colW1, colW2],
    rows: [
      new TableRow({
        children: [
          // 左侧品牌色条
          new TableCell({
            borders: noBorder(),
            width: { size: colW1, type: WidthType.DXA },
            shading: { fill: COLOR.brand, type: ShadingType.CLEAR },
            margins: { top: 0, bottom: 0, left: 0, right: 0 },
            children: [new Paragraph({ children: [new TextRun('')] })],
          }),
          // 标题文字
          new TableCell({
            borders: noBorder(),
            width: { size: colW2, type: WidthType.DXA },
            shading: { fill: COLOR.brandLight, type: ShadingType.CLEAR },
            margins: { top: 80, bottom: 80, left: 160, right: 160 },
            children: [new Paragraph({
              children: [
                new TextRun({ text: icon ? `${icon}  ${text}` : text, bold: true, size: 28, color: COLOR.dark, font: 'Source Han Sans CN' }),
              ],
            })],
          }),
        ],
      }),
    ],
    margins: { top: 0, bottom: 0, left: 0, right: 0 },
  });
}

// ─── 徽章式标签 (inline) ────────────────────────────────────────
function badge(text, bgColor, textColor = 'FFFFFF') {
  return run(`  ${text}  `, { color: textColor, highlight: 'none', bold: true, size: 16 });
}

// ─── 信息卡片 (单列带背景) ────────────────────────────────────────
function infoCard(children, bgColor = COLOR.codeBg, borderColor = COLOR.border) {
  return new Table({
    width: { size: CONTENT_W, type: WidthType.DXA },
    columnWidths: [CONTENT_W],
    rows: [
      new TableRow({
        children: [
          new TableCell({
            borders: { top: { style: BorderStyle.SINGLE, size: 3, color: borderColor },
                       bottom: { style: BorderStyle.SINGLE, size: 1, color: borderColor },
                       left: { style: BorderStyle.SINGLE, size: 6, color: COLOR.brand },
                       right: { style: BorderStyle.SINGLE, size: 1, color: borderColor } },
            shading: { fill: bgColor, type: ShadingType.CLEAR },
            margins: { top: 120, bottom: 120, left: 180, right: 180 },
            width: { size: CONTENT_W, type: WidthType.DXA },
            children,
          }),
        ],
      }),
    ],
  });
}

// ─── 通用数据表格 ─────────────────────────────────────────────
function dataTable(headers, rows, colWidths) {
  const totalW = colWidths.reduce((a, b) => a + b, 0);
  const border = cellBorder(COLOR.border);

  const headerRow = new TableRow({
    children: headers.map((h, i) => new TableCell({
      borders: border,
      width: { size: colWidths[i], type: WidthType.DXA },
      shading: { fill: COLOR.tableHeadBg, type: ShadingType.CLEAR },
      margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [new TextRun({ text: h, bold: true, size: 18, color: COLOR.mid, font: 'Source Han Sans CN' })],
      })],
    })),
  });

  const dataRows = rows.map((row, ri) => new TableRow({
    children: row.map((cell, ci) => new TableCell({
      borders: border,
      width: { size: colWidths[ci], type: WidthType.DXA },
      shading: { fill: ri % 2 === 0 ? 'FFFFFF' : COLOR.stripe, type: ShadingType.CLEAR },
      margins: { top: 70, bottom: 70, left: 120, right: 120 },
      children: [new Paragraph({
        children: [new TextRun({ text: cell, size: 17, color: COLOR.text, font: 'Source Han Sans CN' })],
      })],
    })),
  }));

  return new Table({
    width: { size: totalW, type: WidthType.DXA },
    columnWidths: colWidths,
    rows: [headerRow, ...dataRows],
  });
}

// ─── 进度/状态行 ──────────────────────────────────────────────
function statusItem(icon, text, status, color) {
  return new Paragraph({
    children: [
      new TextRun({ text: `${icon}  `, size: 19, font: 'Segoe UI Emoji' }),
      new TextRun({ text, size: 19, color: COLOR.text, font: 'Source Han Sans CN' }),
      new TextRun({ text: `    [${status}]`, size: 18, color, bold: true, font: 'Source Han Sans CN' }),
    ],
    spacing: { before: 50, after: 50 },
    indent: { left: 200 },
  });
}

// ────────────────────────────────────────────────────────────────
//  正文内容构建
// ────────────────────────────────────────────────────────────────

const children = [];

// ════════════════════════════════════════════════
// 封面区域
// ════════════════════════════════════════════════

// 顶部装饰条
children.push(new Table({
  width: { size: CONTENT_W, type: WidthType.DXA },
  columnWidths: [CONTENT_W * 0.6 | 0, CONTENT_W * 0.25 | 0, CONTENT_W * 0.15 | 0],
  rows: [new TableRow({
    children: [
      new TableCell({ borders: noBorder(), shading: { fill: COLOR.brand, type: ShadingType.CLEAR },
        width: { size: CONTENT_W * 0.6 | 0, type: WidthType.DXA },
        children: [new Paragraph({ children: [new TextRun('')] })],
        margins: { top: 40, bottom: 40 } }),
      new TableCell({ borders: noBorder(), shading: { fill: COLOR.mid, type: ShadingType.CLEAR },
        width: { size: CONTENT_W * 0.25 | 0, type: WidthType.DXA },
        children: [new Paragraph({ children: [new TextRun('')] })],
        margins: { top: 40, bottom: 40 } }),
      new TableCell({ borders: noBorder(), shading: { fill: COLOR.muted, type: ShadingType.CLEAR },
        width: { size: CONTENT_W * 0.15 | 0, type: WidthType.DXA },
        children: [new Paragraph({ children: [new TextRun('')] })],
        margins: { top: 40, bottom: 40 } }),
    ],
  })],
}));

children.push(new Paragraph({ children: [], spacing: { before: 200, after: 0 } }));

// 项目名 + 副标题
children.push(new Paragraph({
  alignment: AlignmentType.LEFT,
  children: [
    new TextRun({ text: '洞见 ', bold: true, size: 64, color: COLOR.brand, font: 'Source Han Sans CN' }),
    new TextRun({ text: 'Foresight', bold: true, size: 64, color: COLOR.dark, font: 'Calibri' }),
  ],
  spacing: { before: 160, after: 80 },
}));

children.push(new Paragraph({
  children: [new TextRun({ text: '同城配送商机智能分析平台', size: 34, color: COLOR.mid, font: 'Source Han Sans CN', bold: true })],
  spacing: { before: 0, after: 160 },
}));

// 项目标签行
children.push(new Table({
  width: { size: CONTENT_W, type: WidthType.DXA },
  columnWidths: [2200, 2200, 2200, 3306],
  rows: [new TableRow({
    children: [
      ['互联网 + 物流', COLOR.brand],
      ['人工智能应用', COLOR.mid],
      ['开源驱动', COLOR.success],
      ['', 'FFFFFF'],
    ].map(([label, bg], i) => new TableCell({
      borders: noBorder(),
      width: { size: [2200,2200,2200,3306][i], type: WidthType.DXA },
      shading: { fill: label ? bg : 'FFFFFF', type: ShadingType.CLEAR },
      margins: { top: 60, bottom: 60, left: 100, right: 100 },
      children: label ? [new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [new TextRun({ text: label, color: 'FFFFFF', bold: true, size: 17, font: 'Source Han Sans CN' })],
      })] : [new Paragraph({ children: [] })],
    })),
  })],
}));

children.push(new Paragraph({ children: [], spacing: { before: 120, after: 0 } }));

// 元信息表（参赛信息）
children.push(dataTable(
  ['参赛组别', '项目类型', '所属院校'],
  [['大创计划 · 创业实践类', '互联网 + 物流 / AI应用', '经济与管理学院']],
  [3300, 3300, 3306]
));

children.push(new Paragraph({ children: [], spacing: { before: 120, after: 0 } }));
children.push(hrLine(COLOR.brand, 6));

// ════════════════════════════════════════════════
// 第一章：问题发现
// ════════════════════════════════════════════════
children.push(new Paragraph({ children: [], spacing: { before: 160, after: 0 } }));
children.push(sectionTitle('一、问题发现：市场调研驱动的需求验证', ''));
children.push(new Paragraph({ children: [], spacing: { before: 80, after: 0 } }));

children.push(infoCard([
  new Paragraph({
    children: [
      new TextRun({ text: '核心问题：', bold: true, size: 19, color: COLOR.brand, font: 'Source Han Sans CN' }),
      new TextRun({ text: '大量中小物流企业知道市场有机会，但不知道机会在哪、怎么抓住。', size: 19, color: COLOR.text, font: 'Source Han Sans CN' }),
    ],
    spacing: { before: 0, after: 80 },
  }),
  new Paragraph({
    children: [new TextRun({ text: '数据来源：大连本地外卖平台、应用商店、电商评论区 → 累计分析 3,000+ 条真实用户反馈', size: 18, color: COLOR.muted, font: 'Source Han Sans CN' })],
  }),
], COLOR.brandLight));

children.push(new Paragraph({ children: [], spacing: { before: 100, after: 0 } }));

children.push(dataTable(
  ['痛点', '具体表现', '直接后果'],
  [
    ['看不见机会', '不知道哪个细分市场（餐饮/冷链/医药）需求最旺、利润最高', '盲目入局，试错成本高'],
    ['听不懂用户', '商家抱怨"配送慢""货损多"，但不知道哪些是致命问题', '资源错配，花钱没解决核心痛点'],
    ['不知道怎么干', '知道某方向有机会，但不知道定价、选车型、先攻哪个区域', '迟迟不敢行动，错过窗口期'],
  ],
  [2200, 4700, 3006]
));

// ════════════════════════════════════════════════
// 第二章：解决方案
// ════════════════════════════════════════════════
children.push(new Paragraph({ children: [], spacing: { before: 200, after: 0 } }));
children.push(sectionTitle('二、解决方案：GitHub 开源生态驱动的拿来主义实践', ''));
children.push(new Paragraph({ children: [], spacing: { before: 80, after: 0 } }));

children.push(new Paragraph({
  children: [new TextRun({ text: '洞见 Foresight 的核心技术理念：不重复造轮子，而是站在开源巨人的肩膀上。每一个核心模块都源自 GitHub 上成熟的开源项目，并在此基础上进行领域定制与增强。', size: 19, color: COLOR.text, font: 'Source Han Sans CN' })],
  spacing: { before: 0, after: 120 },
}));

// 开源组件引用卡片
children.push(new Table({
  width: { size: CONTENT_W, type: WidthType.DXA },
  columnWidths: [CONTENT_W * 0.48 | 0, CONTENT_W * 0.04 | 0, CONTENT_W * 0.48 | 0],
  rows: [new TableRow({
    children: [
      // 左卡：浏览器 AI
      new TableCell({
        borders: { top: { style: BorderStyle.SINGLE, size: 3, color: COLOR.brand },
                   bottom: { style: BorderStyle.SINGLE, size: 1, color: COLOR.border },
                   left: { style: BorderStyle.SINGLE, size: 1, color: COLOR.border },
                   right: { style: BorderStyle.SINGLE, size: 1, color: COLOR.border } },
        shading: { fill: COLOR.stripe, type: ShadingType.CLEAR },
        margins: { top: 120, bottom: 120, left: 160, right: 160 },
        width: { size: CONTENT_W * 0.48 | 0, type: WidthType.DXA },
        children: [
          new Paragraph({ children: [new TextRun({ text: '★ 浏览器端 AI 推理', bold: true, size: 20, color: COLOR.brand, font: 'Source Han Sans CN' })], spacing: { after: 60 } }),
          new Paragraph({ children: [new TextRun({ text: 'GitHub: mlc-ai/web-llm', size: 17, color: COLOR.mid, font: 'Courier New' })], spacing: { after: 60 } }),
          new Paragraph({ children: [new TextRun({ text: '深研源码 1 周，将 Qwen2.5-1.5B 编译为 WebGPU/WASM 格式，实现零成本浏览器本地推理。模型首次下载后缓存至 IndexedDB，后续秒级加载。', size: 18, color: COLOR.text, font: 'Source Han Sans CN' })], spacing: { after: 60 } }),
          new Paragraph({ children: [new TextRun({ text: '创新：将通用框架适配物流场景中文问答，首次应用于同城配送分析领域', size: 17, color: COLOR.success, font: 'Source Han Sans CN', italics: true })] }),
        ],
      }),
      // 中间间隔
      new TableCell({ borders: noBorder(), width: { size: CONTENT_W * 0.04 | 0, type: WidthType.DXA }, children: [new Paragraph({ children: [] })] }),
      // 右卡：路线优化
      new TableCell({
        borders: { top: { style: BorderStyle.SINGLE, size: 3, color: COLOR.mid },
                   bottom: { style: BorderStyle.SINGLE, size: 1, color: COLOR.border },
                   left: { style: BorderStyle.SINGLE, size: 1, color: COLOR.border },
                   right: { style: BorderStyle.SINGLE, size: 1, color: COLOR.border } },
        shading: { fill: COLOR.stripe, type: ShadingType.CLEAR },
        margins: { top: 120, bottom: 120, left: 160, right: 160 },
        width: { size: CONTENT_W * 0.48 | 0, type: WidthType.DXA },
        children: [
          new Paragraph({ children: [new TextRun({ text: '★ 路线优化引擎', bold: true, size: 20, color: COLOR.mid, font: 'Source Han Sans CN' })], spacing: { after: 60 } }),
          new Paragraph({ children: [new TextRun({ text: 'GitHub: google/or-tools', size: 17, color: COLOR.mid, font: 'Courier New' })], spacing: { after: 60 } }),
          new Paragraph({ children: [new TextRun({ text: '直接集成 Google 工业级 VRP 求解器，支持多车辆、多停靠点的最优配送路线计算，避免自研算法的不稳定性。', size: 18, color: COLOR.text, font: 'Source Han Sans CN' })], spacing: { after: 60 } }),
          new Paragraph({ children: [new TextRun({ text: '创新：结合大连区域地理特征做路线约束，输出本地化最优方案', size: 17, color: COLOR.success, font: 'Source Han Sans CN', italics: true })] }),
        ],
      }),
    ],
  })],
}));

children.push(new Paragraph({ children: [], spacing: { before: 100, after: 0 } }));

// 第二行双卡
children.push(new Table({
  width: { size: CONTENT_W, type: WidthType.DXA },
  columnWidths: [CONTENT_W * 0.48 | 0, CONTENT_W * 0.04 | 0, CONTENT_W * 0.48 | 0],
  rows: [new TableRow({
    children: [
      new TableCell({
        borders: { top: { style: BorderStyle.SINGLE, size: 3, color: COLOR.gold },
                   bottom: { style: BorderStyle.SINGLE, size: 1, color: COLOR.border },
                   left: { style: BorderStyle.SINGLE, size: 1, color: COLOR.border },
                   right: { style: BorderStyle.SINGLE, size: 1, color: COLOR.border } },
        shading: { fill: COLOR.stripe, type: ShadingType.CLEAR },
        margins: { top: 120, bottom: 120, left: 160, right: 160 },
        width: { size: CONTENT_W * 0.48 | 0, type: WidthType.DXA },
        children: [
          new Paragraph({ children: [new TextRun({ text: '★ 地图可视化引擎', bold: true, size: 20, color: COLOR.gold, font: 'Source Han Sans CN' })], spacing: { after: 60 } }),
          new Paragraph({ children: [new TextRun({ text: 'GitHub: Leaflet/Leaflet', size: 17, color: COLOR.mid, font: 'Courier New' })], spacing: { after: 60 } }),
          new Paragraph({ children: [new TextRun({ text: '复用 Leaflet.js 成熟地图框架构建车队监控大屏，内置 GPS 轨迹模拟器，展示实时车辆位置与配送路径。', size: 18, color: COLOR.text, font: 'Source Han Sans CN' })], spacing: { after: 60 } }),
          new Paragraph({ children: [new TextRun({ text: '创新：叠加大连七大行政区商圈热力图层', size: 17, color: COLOR.success, font: 'Source Han Sans CN', italics: true })] }),
        ],
      }),
      new TableCell({ borders: noBorder(), width: { size: CONTENT_W * 0.04 | 0, type: WidthType.DXA }, children: [new Paragraph({ children: [] })] }),
      new TableCell({
        borders: { top: { style: BorderStyle.SINGLE, size: 3, color: COLOR.success },
                   bottom: { style: BorderStyle.SINGLE, size: 1, color: COLOR.border },
                   left: { style: BorderStyle.SINGLE, size: 1, color: COLOR.border },
                   right: { style: BorderStyle.SINGLE, size: 1, color: COLOR.border } },
        shading: { fill: COLOR.stripe, type: ShadingType.CLEAR },
        margins: { top: 120, bottom: 120, left: 160, right: 160 },
        width: { size: CONTENT_W * 0.48 | 0, type: WidthType.DXA },
        children: [
          new Paragraph({ children: [new TextRun({ text: '★ NLP 分析引擎', bold: true, size: 20, color: COLOR.success, font: 'Source Han Sans CN' })], spacing: { after: 60 } }),
          new Paragraph({ children: [new TextRun({ text: 'GitHub: fxsjy/jieba + scikit-learn', size: 17, color: COLOR.mid, font: 'Courier New' })], spacing: { after: 60 } }),
          new Paragraph({ children: [new TextRun({ text: 'jieba 中文分词 + TF-IDF 特征提取 + KMeans 聚类，自动将用户评论归类为痛点维度，无需人工标注。', size: 18, color: COLOR.text, font: 'Source Han Sans CN' })], spacing: { after: 60 } }),
          new Paragraph({ children: [new TextRun({ text: '创新：自建物流领域专用情感词典（时效/温控/货损等）', size: 17, color: COLOR.success, font: 'Source Han Sans CN', italics: true })] }),
        ],
      }),
    ],
  })],
}));

// ════════════════════════════════════════════════
// 第三章：技术架构与创新
// ════════════════════════════════════════════════
children.push(new Paragraph({ children: [new PageBreak()] }));
children.push(sectionTitle('三、核心技术创新：拿来 + 改造 = 差异化优势', ''));
children.push(new Paragraph({ children: [], spacing: { before: 80, after: 0 } }));

// 创新点1
children.push(new Paragraph({
  children: [new TextRun({ text: '3.1  浏览器端 AI — 零成本、零配置', bold: true, size: 22, color: COLOR.dark, font: 'Source Han Sans CN' })],
  spacing: { before: 80, after: 60 },
}));

children.push(dataTable(
  ['对比维度', '传统方案（GPT API）', '本项目方案（WebLLM）'],
  [
    ['API 费用', '$0.03–$0.06 / 次', '完全免费'],
    ['配置门槛', '申请 Key、绑卡、代理', '打开浏览器即用'],
    ['数据隐私', '数据上传至云端', '数据不出浏览器'],
    ['离线可用', '❌ 依赖网络', '✅ 模型缓存后可离线'],
  ],
  [2800, 3553, 3553]
));

children.push(new Paragraph({ children: [], spacing: { before: 80, after: 0 } }));

// 创新点2
children.push(new Paragraph({
  children: [new TextRun({ text: '3.2  领域知识注入 — 懂大连、懂物流', bold: true, size: 22, color: COLOR.dark, font: 'Source Han Sans CN' })],
  spacing: { before: 80, after: 60 },
}));

children.push(infoCard([
  new Paragraph({ children: [new TextRun({ text: '大连地理知识库：', bold: true, size: 19, color: COLOR.brand, font: 'Source Han Sans CN' }), new TextRun({ text: '内置 7 个行政区商圈特征、交通状况、季节因素（樱桃季 / 旅游旺季 / 冬季暴雪）', size: 19, color: COLOR.text, font: 'Source Han Sans CN' })], spacing: { after: 60 } }),
  new Paragraph({ children: [new TextRun({ text: '五大场景画像：', bold: true, size: 19, color: COLOR.brand, font: 'Source Han Sans CN' }), new TextRun({ text: '餐饮 / 冷链 / 家具 / 医药 / 商超，各有独立合规要求、推荐车型、定价参考', size: 19, color: COLOR.text, font: 'Source Han Sans CN' })], spacing: { after: 60 } }),
  new Paragraph({ children: [new TextRun({ text: '行业情感词典：', bold: true, size: 19, color: COLOR.brand, font: 'Source Han Sans CN' }), new TextRun({ text: '非通用"好/坏"，而是"准时率 / 温控 / 搬运上楼 / 包装完好"等物流特有维度', size: 19, color: COLOR.text, font: 'Source Han Sans CN' })] }),
]));

children.push(new Paragraph({ children: [], spacing: { before: 80, after: 0 } }));

// 创新点3：渐进式增强
children.push(new Paragraph({
  children: [new TextRun({ text: '3.3  渐进式增强架构 — 快与好，不是二选一', bold: true, size: 22, color: COLOR.dark, font: 'Source Han Sans CN' })],
  spacing: { before: 80, after: 60 },
}));

children.push(dataTable(
  ['阶段', '时间', '用户体验'],
  [
    ['模板报告即时展示', '< 3 秒', '核心商机摘要、痛点分析立即可见'],
    ['AI 模型异步加载', '后台进行，不阻塞页面', '用户可正常浏览模板报告'],
    ['AI 分析结果渐进注入', '模型加载完成后自动注入 DOM', 'SWOT / 策略 / 路线图 / ROI 评估'],
    ['WebGPU 不可用时自动降级', '即时切换', '增强模板报告，核心功能不受影响'],
  ],
  [2800, 3000, 4106]
));

// ════════════════════════════════════════════════
// 第四章：产品功能矩阵
// ════════════════════════════════════════════════
children.push(new Paragraph({ children: [], spacing: { before: 200, after: 0 } }));
children.push(sectionTitle('四、产品功能矩阵', ''));
children.push(new Paragraph({ children: [], spacing: { before: 80, after: 0 } }));

children.push(dataTable(
  ['功能模块', '核心能力', '依赖开源项目'],
  [
    ['商机分析（核心）', 'NLP 情感分析 → 痛点聚类 → 四维商机评分 → AI 报告', 'jieba / sklearn / web-llm'],
    ['商机跟踪 CRM', '拖拽看板 / 跟进日志 / 超期提醒 / 统计面板', 'SortableJS'],
    ['车队监控大屏', '实时地图 / 车辆状态 / 路线展示 / GPS 模拟', 'Leaflet.js / ECharts'],
    ['路线优化', '多车辆多停靠点 VRP 最优路线计算', 'Google OR-Tools'],
    ['AI 增强报告', 'SWOT / 市场策略 / 90天路线图 / ROI 评估', 'mlc-ai/web-llm + Qwen2.5'],
  ],
  [2400, 4000, 3506]
));

// ════════════════════════════════════════════════
// 第五章：市场竞争分析
// ════════════════════════════════════════════════
children.push(new Paragraph({ children: [], spacing: { before: 200, after: 0 } }));
children.push(sectionTitle('五、市场分析与竞争定位', ''));
children.push(new Paragraph({ children: [], spacing: { before: 80, after: 0 } }));

children.push(infoCard([
  new Paragraph({
    children: [
      new TextRun({ text: '目标市场：', bold: true, size: 19, color: COLOR.brand, font: 'Source Han Sans CN' }),
      new TextRun({ text: '中国同城配送市场规模超 1.5 万亿元（2024），年增速约 15%。大连日均同城配送订单量 30–50 万单。', size: 19, color: COLOR.text, font: 'Source Han Sans CN' }),
    ],
    spacing: { after: 60 },
  }),
  new Paragraph({
    children: [
      new TextRun({ text: '核心用户：', bold: true, size: 19, color: COLOR.brand, font: 'Source Han Sans CN' }),
      new TextRun({ text: '大连中小物流企业（车队 5–50 辆）——有扩张意愿，买不起专业咨询，缺乏市场分析工具。', size: 19, color: COLOR.text, font: 'Source Han Sans CN' }),
    ],
  }),
]));

children.push(new Paragraph({ children: [], spacing: { before: 100, after: 0 } }));

children.push(dataTable(
  ['竞品类型', '代表产品', '差异化定位'],
  [
    ['通用舆情监控', '梅花数据、清博舆情', '他们做品牌公关，我们做商机挖掘'],
    ['物流 TMS 系统', 'G7、中交兴路', '他们管车队运营，我们做市场决策支持'],
    ['通用 AI 分析', 'ChatGPT 手动分析', '他们需 Prompt 工程，我们一键生成报告'],
  ],
  [2400, 3000, 4506]
));

children.push(new Paragraph({ children: [], spacing: { before: 80, after: 0 } }));
children.push(infoCard([
  new Paragraph({
    children: [
      new TextRun({ text: '一句话定位：', bold: true, size: 20, color: COLOR.dark, font: 'Source Han Sans CN' }),
      new TextRun({ text: '  物流行业的"企查查 + 天眼查" — 不是管车，是找机会。', size: 20, color: COLOR.brand, bold: true, font: 'Source Han Sans CN' }),
    ],
  }),
], COLOR.brandLight));

// ════════════════════════════════════════════════
// 第六章：进度规划与总结
// ════════════════════════════════════════════════
children.push(new Paragraph({ children: [new PageBreak()] }));
children.push(sectionTitle('六、项目进度与开源实践反思', ''));
children.push(new Paragraph({ children: [], spacing: { before: 80, after: 0 } }));

// 已完成
children.push(new Paragraph({
  children: [new TextRun({ text: '已完成模块', bold: true, size: 20, color: COLOR.dark, font: 'Source Han Sans CN' })],
  spacing: { before: 80, after: 60 },
}));

const doneItems = [
  '商机分析引擎（NLP + 报告生成 + 五大场景模板）',
  '浏览器端 AI 分析（SWOT / 策略 / 差距 / 路线图 / ROI）',
  '商机跟踪看板（CRM 拖拽式管理，基于 SortableJS）',
  '车队监控大屏（Leaflet 地图 + ECharts 图表 + GPS 模拟）',
  '大连地理知识库（7 区域 + 季节因素 + 合规 + 竞争格局）',
];

doneItems.forEach(item => {
  children.push(new Paragraph({
    children: [
      new TextRun({ text: '✅  ', size: 19, font: 'Segoe UI Emoji' }),
      new TextRun({ text: item, size: 19, color: COLOR.text, font: 'Source Han Sans CN' }),
    ],
    spacing: { before: 40, after: 40 },
    indent: { left: 200 },
  }));
});

children.push(new Paragraph({ children: [], spacing: { before: 80, after: 0 } }));

// 下一步
children.push(new Paragraph({
  children: [new TextRun({ text: '下一步计划', bold: true, size: 20, color: COLOR.dark, font: 'Source Han Sans CN' })],
  spacing: { before: 80, after: 60 },
}));

const nextItems = [
  '对接真实数据源（美团/饿了么公开评论 API）',
  '升级浏览器 AI 模型至 Qwen3-4B（质量大幅提升）',
  '移动端适配（PWA 渐进式 Web 应用）',
  '多城市知识库模板化，支持快速扩展到其他城市',
  '邀请 2–3 家大连本地物流企业免费试用，获取真实反馈',
];

nextItems.forEach(item => {
  children.push(new Paragraph({
    children: [
      new TextRun({ text: '⬜  ', size: 19, font: 'Segoe UI Emoji' }),
      new TextRun({ text: item, size: 19, color: COLOR.muted, font: 'Source Han Sans CN' }),
    ],
    spacing: { before: 40, after: 40 },
    indent: { left: 200 },
  }));
});

children.push(new Paragraph({ children: [], spacing: { before: 120, after: 0 } }));
children.push(thinHr(COLOR.border));
children.push(new Paragraph({ children: [], spacing: { before: 80, after: 0 } }));

// 开源反思
children.push(infoCard([
  new Paragraph({
    children: [new TextRun({ text: '开源实践的核心感悟', bold: true, size: 20, color: COLOR.dark, font: 'Source Han Sans CN' })],
    spacing: { after: 80 },
  }),
  new Paragraph({
    children: [
      new TextRun({ text: '技术选择上，', bold: true, size: 18, color: COLOR.brand, font: 'Source Han Sans CN' }),
      new TextRun({ text: '最初打算调用 GPT-4 API，但发现需绑卡、科学上网、每月付费，对学生项目完全不现实。后在 GitHub 上发现 mlc-ai/web-llm，深研源码一周后实现完全免费的浏览器端 AI。这证明了一个判断：', size: 18, color: COLOR.text, font: 'Source Han Sans CN' }),
    ],
    spacing: { after: 60 },
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: '"好技术不一定贵，关键是找到对的开源方案，然后把它用对地方。"', size: 19, color: COLOR.brand, bold: true, italics: true, font: 'Source Han Sans CN' })],
    spacing: { after: 80 },
  }),
  new Paragraph({
    children: [
      new TextRun({ text: '领域价值上，', bold: true, size: 18, color: COLOR.mid, font: 'Source Han Sans CN' }),
      new TextRun({ text: 'NLP 模型是通用的，但同城配送是具体的。拿来开源框架只是起点，真正的差异化在于向模型注入领域知识——大连的地理特征、季节规律、行业合规。没有这些，AI 分析只是空中楼阁。', size: 18, color: COLOR.text, font: 'Source Han Sans CN' }),
    ],
  }),
]));

children.push(new Paragraph({ children: [], spacing: { before: 120, after: 0 } }));

// 底部装饰条
children.push(new Table({
  width: { size: CONTENT_W, type: WidthType.DXA },
  columnWidths: [CONTENT_W * 0.15 | 0, CONTENT_W * 0.25 | 0, CONTENT_W * 0.60 | 0],
  rows: [new TableRow({
    children: [
      new TableCell({ borders: noBorder(), shading: { fill: COLOR.muted, type: ShadingType.CLEAR }, width: { size: CONTENT_W * 0.15 | 0, type: WidthType.DXA }, children: [new Paragraph({ children: [] })], margins: { top: 40, bottom: 40 } }),
      new TableCell({ borders: noBorder(), shading: { fill: COLOR.mid, type: ShadingType.CLEAR }, width: { size: CONTENT_W * 0.25 | 0, type: WidthType.DXA }, children: [new Paragraph({ children: [] })], margins: { top: 40, bottom: 40 } }),
      new TableCell({ borders: noBorder(), shading: { fill: COLOR.brand, type: ShadingType.CLEAR }, width: { size: CONTENT_W * 0.60 | 0, type: WidthType.DXA }, children: [new Paragraph({ children: [] })], margins: { top: 40, bottom: 40 } }),
    ],
  })],
}));

children.push(new Paragraph({
  alignment: AlignmentType.CENTER,
  children: [new TextRun({ text: '洞见 Foresight  ·  同城配送商机智能分析平台  ·  开源驱动，领域深耕', size: 16, color: COLOR.muted, font: 'Source Han Sans CN', italics: true })],
  spacing: { before: 80, after: 40 },
}));
children.push(new Paragraph({
  alignment: AlignmentType.CENTER,
  children: [new TextRun({ text: '本项目为大学生创新创业实践作品，部分数据为模拟生成，技术架构和部署方案已验证可行。', size: 16, color: COLOR.muted, font: 'Source Han Sans CN' })],
  spacing: { before: 0, after: 0 },
}));

// ────────────────────────────────────────────────────────────────
//  构建文档
// ────────────────────────────────────────────────────────────────

const doc = new Document({
  numbering: { config: [] },
  styles: {
    default: {
      document: {
        run: { font: 'Source Han Sans CN', size: 19, color: COLOR.text },
        paragraph: { spacing: { line: 320 } },
      },
    },
  },
  sections: [{
    properties: {
      page: {
        size: { width: PAGE_W, height: PAGE_H },
        margin: { top: MARGIN, right: MARGIN, bottom: MARGIN, left: MARGIN },
      },
    },
    headers: {
      default: new Header({
        children: [
          new Paragraph({
            children: [
              new TextRun({ text: '洞见 Foresight  ·  同城配送商机智能分析平台', size: 16, color: COLOR.muted, font: 'Source Han Sans CN' }),
              new TextRun({ text: '\t', size: 16 }),
              new TextRun({ text: '大创计划 · 创业实践类', size: 16, color: COLOR.muted, font: 'Source Han Sans CN' }),
            ],
            tabStops: [{ type: TabStopType.RIGHT, position: TabStopPosition.MAX }],
            border: { bottom: { style: BorderStyle.SINGLE, size: 2, color: COLOR.border, space: 1 } },
            spacing: { before: 0, after: 60 },
          }),
        ],
      }),
    },
    footers: {
      default: new Footer({
        children: [
          new Paragraph({
            children: [
              new TextRun({ text: '项目介绍书  ·  共 6 页', size: 16, color: COLOR.muted, font: 'Source Han Sans CN' }),
              new TextRun({ text: '\t', size: 16 }),
              new TextRun({ text: '第 ', size: 16, color: COLOR.muted }),
              new TextRun({ children: [PageNumber.CURRENT], size: 16, color: COLOR.brand }),
              new TextRun({ text: ' 页', size: 16, color: COLOR.muted }),
            ],
            tabStops: [{ type: TabStopType.RIGHT, position: TabStopPosition.MAX }],
            border: { top: { style: BorderStyle.SINGLE, size: 2, color: COLOR.border, space: 1 } },
            spacing: { before: 60, after: 0 },
          }),
        ],
      }),
    },
    children,
  }],
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync('D:/Desktop/painpoint-engine/docs/项目介绍书.docx', buffer);
  console.log('✅ 文档生成成功: D:/Desktop/painpoint-engine/docs/项目介绍书.docx');
}).catch(err => {
  console.error('❌ 生成失败:', err);
});
