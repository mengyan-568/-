# 洞见 Foresight — 报告智能化 + 浏览器端 AI 集成

## Context

当前问题：
1. **AI 分析从未生效** — Gemini API Key 未设置，Ollama 未安装，`ai_analysis` 始终为空 `{}`
2. **模板报告不回答核心问题** — 首页承诺"告诉你哪里有机会、怎么切入"，但报告没有专门的"机会"和"切入策略"章节
3. **关键战略章节被折叠** — `industry_analysis` 和 `action_plan` 默认 collapsed
4. **报告缺乏智能感** — 全是硬编码模板，每条报告格式雷同

目标：
- 零配置 AI 分析（不需要 API Key、不需要安装任何软件）
- 报告明确回答"哪里有机会"和"怎么切入"
- 战略章节默认可见，商机信息突出展示

## 方案

**浏览器端 AI（@mlc-ai/web-llm）**：在浏览器中运行 Qwen2.5-1.5B-Instruct（~1.6GB），通过 WebGPU 本地推理。模型首次下载后缓存在 IndexedDB，后续秒开。完全零配置。

| 层级 | 方案 | 质量 | 零配置 |
|------|------|------|--------|
| 主 | 浏览器 Qwen2.5-1.5B | 中等 | ✅ |
| 降级 | 浏览器 Qwen2.5-0.5B | 基础（低配设备） | ✅ |
| 兜底 | 增强后的模板 | 专业 | ✅ |

## 文件变更清单

### 1. 新建 `frontend/js/ai-browser.js` — 浏览器 AI 管线（~250行）

`BrowserAI` 模块：
- `init()` — 检测 WebGPU → 动态 import `@mlc-ai/web-llm`（CDN）→ 下载模型到 IndexedDB → 加载到 GPU
- `isSupported()` — 检查 `navigator.gpu`
- `generate(prompt)` — 单次推理，含 JSON 容错（markdown code block 提取 + 首尾 `{}` 匹配）
- `analyzeReport(report)` — 运行全部 6 个分析任务
- `getStatus()` — 返回 `{stage, progress, message}`
- `destroy()` — 释放 GPU 显存

Prompt 模板从 `backend/llm/prompts.py` 移植为 JS 模板字符串。

### 2. 修改 `frontend/js/app.js` — 三项改动

#### 2a. `startAnalysis()` 集成浏览器 AI

```
startAnalysis()
  → fetch /api/analyze → renderReport()     // 模板报告立即展示
  → renderAIStatusBanner('detecting')         // 显示 AI 状态横幅
  → BrowserAI.init()                          // 加载模型（异步）
     → 成功 → renderAIStatusBanner('analyzing')
       → BrowserAI.analyzeReport(report)      // 6 个分析任务
       → 注入结果到 DOM（更新 AI section）
       → renderAIStatusBanner('done')
     → WebGPU 不支持 → renderAIStatusBanner('unsupported')
     → 错误 → renderAIStatusBanner('error')
```

#### 2b. 新增 `renderOpportunitySynthesis()` 

报告顶部添加"核心商机"三列卡片：
- 📍 **哪里有机会？** — Top 痛点 + 频次 + 满足度缺口
- 🎯 **怎么切入？** — 差异化建议 + 具体行动
- ⚡ **为什么现在？** — 负面率 + 付费意愿 + 季节性

下方附 Top 3 商机排序列表。橙色描边，始终可见，不可折叠。

#### 2c. 新增 `renderAIStatusBanner()`

5 种状态：loading/analyzing/done/unsupported/error，各有不同配色和文案。

#### 2d. 默认展开战略章节

`industry_analysis` 和 `action_plan` 移除 `collapsed` 类。

### 3. 修改 `backend/analyzer/engine.py` — 模板报告增强

- `_generate_summary()` 末尾增加商机结论句："核心商机：XXX 是当前最大的差异化切入点…"
- `_generate_industry_analysis()` 末尾增加【切入策略】标注段落
- `_generate_action_plan()` Phase 1 标注"快速赢单"最高优先级行动

### 4. 修改 `frontend/css/style.css` — 新增样式（~90行）

- `.opportunity-synthesis` — 橙色描边 + 渐变背景
- `.synthesis-badge` — 橙色胶囊标签"核心商机"
- `.synthesis-grid` — 3 列响应式网格
- `.synthesis-card--where/how/why` — 左色条区分
- `.ai-status-banner` — 5 种状态配色 + spinner

### 5. 修改 `frontend/index.html`

无需修改（`@mlc-ai/web-llm` 通过动态 import 从 CDN 加载，不增加首屏负担）。

## 实施顺序

1. 模板报告增强 — `engine.py` summary/industry_analysis/action_plan
2. 机会合成渲染 — `app.js` renderOpportunitySynthesis() + CSS
3. 默认展开 — `app.js` 移除 collapsed
4. 浏览器 AI 管线 — 新建 `ai-browser.js`
5. AI 集成到流程 — `app.js` startAnalysis() + 状态横幅
6. AI 横幅样式 — `style.css`
7. 浏览器验证

## 验证

1. **无 WebGPU**：模板报告正常，机会合成卡片清晰，AI 横幅提示"不支持"
2. **有 WebGPU（Chrome 113+）**：模型下载后 6 个 AI section 出现，中文专业
3. **模型缓存**：第二次分析秒开，不重新下载
4. **模板增强**：summary 有商机结论，战略章节默认展开
