---
name: painpoint-engine-project-overview
description: 洞见 Foresight 项目架构、技术栈、关键文件路径
metadata: 
  node_type: memory
  type: project
  originSessionId: c4feedcf-e0df-4a7f-b6d6-f86d74b59c88
---

## 洞见 Foresight — 项目概述

**定位**：从用户声音中发现下一个商机，大连同城配送行业痛点挖掘与商机识别平台

### 技术栈
- **后端**：FastAPI + SQLite (DuckDB/PostgreSQL 可选)
- **前端**：原生 HTML/CSS/JS，无框架
- **NLP**：jieba 分词 + SnowNLP 情感分析 + sklearn (TF-IDF/SVD/KMeans)
- **地图**：Leaflet + 高德瓦片
- **图表**：ECharts 5.5
- **拖拽**：SortableJS 1.15.6

### 项目路径
- `D:/Desktop/painpoint-engine/backend/main.py` — 主入口，所有 API 端点
- `D:/Desktop/painpoint-engine/backend/nlp/analyzer.py` — NLP 分析器 + 聚类
- `D:/Desktop/painpoint-engine/backend/analyzer/engine.py` — 商机洞察引擎
- `D:/Desktop/painpoint-engine/backend/tracking/` — 商机跟踪后端
- `D:/Desktop/painpoint-engine/frontend/index.html` — 前端 HTML
- `D:/Desktop/painpoint-engine/frontend/js/app.js` — 前端 JS 逻辑
- `D:/Desktop/painpoint-engine/frontend/css/style.css` — 样式

### 启动方式
```bash
cd D:/Desktop/painpoint-engine/backend
python -m uvicorn main:app --reload --port 8000
```
或
```bash
cd D:/Desktop/painpoint-engine/backend
python main.py
```

### 关键 API
- `POST /api/analyze` — 分析关键词
- `GET /api/track/opportunities` — 商机列表
- `GET /api/track/stats` — 商机统计
- `POST /api/track/opportunities` — 创建商机
- 完整端点见 main.py 行 100-514

### 已知问题
- 商机 ID 是 UUID 字符串，前端已修复 parseInt 截断 bug
- SortableJS filter 已添加，防止拖拽拦截按钮点击
- GEMINI_API_KEY 未设置时 AI 分析降级为模板
