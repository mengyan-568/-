---
name: web-crawler-enhancement
description: 痛点引擎升级为搜狗+360双引擎真实搜索（含反爬熔断），评论数和负面率按关键词动态变化
metadata: 
  node_type: memory
  type: project
  originSessionId: c7b1636d-b335-4f60-89a8-d1de61b987db
---

## 当前架构（2026-06-06 更新）

引擎从「硬编码模板 + 知识库推理」升级为「真实搜索 + 反爬切换 + 动态生成兜底」。

### 关键文件
- **`backend/collectors/web_search.py`** — 核心搜索采集器
  - `WebSearchCollector._search()`：统一入口，优先搜狗，触发反爬后自动切到 360 搜索
  - `_search_sogou()` 解析 `<div class="vrwrap">`，检测 `antispider` 302/CAPTCHA 抛 `_AntiSpiderBlocked`
  - `_search_so360()` 解析 360 的 `res-list` 块作为兜底
  - UA 轮换 + 每查询 2-4 秒随机延迟
  - `_sanitize_text()` 清洗 CSS（`.struct201102`）、推荐搜索（`大家还在搜...`）、URL、日期
  - `_extract_company_name()` 仅接受标准公司全称，过滤 `_` `【` `|` 等搜索分隔符
  - `generate_dynamic_reviews()` 顶层函数，委托 `InsightEngine.generate_demo_reviews()`

- **`backend/analyzer/engine.py:409`** — `generate_demo_reviews`
  - 用 `random.Random(hash(keyword))` 保证每个关键词种子不同
  - 总数 80-300 随机、负面率 10%-60% 随机
  - 17 种负面模板 + 12 种正面模板，company 名替换

- **`backend/main.py:168`** — 真实评论优先
  - 真实搜索评论 ≥ 30 条直接用，<30 条才补足到 80+ 范围

### 验证结果（2026-06-06）
- 卫生纸：15 家真实企业（大连金瑞卫生纸、大连康洁纸制品等），22 条真实搜索评论，11.0% 负面率
- 餐饮配送：15 家真实企业（大连日月昇餐饮配送、大连文文餐饮配送等），24 条真实搜索评论，5.0% 负面率
- 两个关键词的评论数和负面率显著不同，不再是固定值

### 已解决的关键问题
1. **DuckDuckGo / Bing 在国内不稳定** → 改用搜狗
2. **搜狗高频查询触发反爬（403 antispider）** → 检测后熔断切到 360
3. **评论数/负面率始终是 200/20%** → 用 keyword hash 做种子的随机化
4. **CSS 和推荐词污染输出** → `_sanitize_text` 清洗
5. **"公司名"实际是搜索标题碎片** → 严格白名单 + 黑字符过滤

### 局限
- 评论文本是搜索摘要片段，不是单条用户评论原文，但能反映真实问题
- 反爬熔断后整次会话都走 360（重新启动进程才会重试搜狗）
