---
name: tracking-board-optimization-plan
description: 商机跟踪面板企业级优化清单
metadata: 
  node_type: memory
  type: project
  originSessionId: c4feedcf-e0df-4a7f-b6d6-f86d74b59c88
---

## 商机跟踪面板 — 企业级优化

### 已修复
- [x] `parseInt(btn.dataset.id)` → `btn.dataset.id`（UUID 截断 bug，3处）
- [x] SortableJS `filter: '.kanban-card-actions, .kanban-card-name'` + `preventOnFilter: false`

### 待优化
- [ ] Toast 通知系统
- [ ] 搜索防抖 (debounce 300ms)
- [ ] Modal 开/关动画
- [ ] 所有 API 调用 try/catch
- [ ] 表单校验反馈
- [ ] 按钮 loading 态
- [ ] SortableJS 拖拽不发 deal_amount:0
- [ ] 自定义确认框替代 confirm()
- [ ] 看板加载骨架屏
- [ ] CSV 导出
- [ ] 键盘快捷键 (Escape/Ctrl+N)
- [ ] 详情弹窗活动时间线
- [ ] 统计数字脉冲动画
- [ ] 看板卡片下次跟进日期

**Why**: 当前面板功能可用但缺乏企业级 polish — 无 loading/error 反馈、原生 confirm、无动画、无导出
**How to apply**: 按优先级逐项实现，先 toast/debounce/error 处理，再动画/导出/时间线
