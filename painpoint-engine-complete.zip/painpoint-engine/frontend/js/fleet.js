/**
 * Enterprise Fleet Dashboard v2
 * Gaode tiles + GCJ-02 coords + route planner + timeline + alerts
 */

// ===== State =====
let fleetMap = null;
let fleetMarkers = {};
let fleetRouteLines = {};
let fleetTrails = {};
let fleetPollInterval = null;
let fleetActiveVehicle = null;
let fleetGeofenceLayer = null;
let fleetGeofencesVisible = false;
let fleetRouteLabelsVisible = false;
let planStops = []; // {lat, lon, name, demand_kg, time_window_min, service_minutes}
let planMarkers = [];
let planRouteLines = [];
let planMarkerCounter = 0;

// ===== GCJ-02 Conversion =====
function wgs84ToGcj02(lat, lon) {
  if (typeof gcoord !== 'undefined') {
    var result = gcoord.transform([lon, lat], gcoord.WGS84, gcoord.GCJ02);
    return { lat: result[1], lon: result[0] };
  }
  return { lat: lat, lon: lon };
}

// ===== Vehicle Icons =====
function createVehicleIcon(status, heading) {
  var colors = { driving: '#43A047', stopped: '#F57C00', idle: '#9E9E9E' };
  var color = colors[status] || '#9E9E9E';
  var rotation = heading || 0;
  return L.divIcon({
    className: 'fv-icon',
    html: '<div style="width:32px;height:32px;background:' + color + ';border-radius:50%;border:2px solid rgba(255,255,255,0.6);display:flex;align-items:center;justify-content:center;font-size:14px;transform:rotate(' + rotation + 'deg);box-shadow:0 2px 8px rgba(0,0,0,0.4)">&#9650;</div>',
    iconSize: [32, 32], iconAnchor: [16, 16],
  });
}

// ===== Init Map =====
function initFleetMap() {
  if (fleetMap) return;
  var mapEl = document.getElementById('fleet-map');
  if (!mapEl) return;

  fleetMap = L.map('fleet-map', {
    center: [38.92, 121.63], zoom: 12, zoomControl: false,
    attributionControl: false,
  });

  // Gaode tiles — no API key needed for basic vector tiles
  L.tileLayer('https://webrd0{s}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=8&x={x}&y={y}&z={z}', {
    subdomains: ['1', '2', '3', '4'],
    maxZoom: 18,
  }).addTo(fleetMap);

  L.control.attribution({ position: 'bottomright', prefix: '高德地图' }).addTo(fleetMap);

  addDepotMarkers();
  initGeofenceLayer();
  initMapClickHandler();
  initSidebarTabs();

  // Start polling
  pollFleetPositions();
  if (fleetPollInterval) clearInterval(fleetPollInterval);
  fleetPollInterval = setInterval(pollFleetPositions, 4000);
}

// ===== Depot Markers =====
function addDepotMarkers() {
  var depots = [
    { name: '甘井子仓储中心', lat: 38.9522, lon: 121.5500 },
    { name: '大连湾物流园', lat: 38.9833, lon: 121.6833 },
    { name: '开发区配送站', lat: 39.0500, lon: 121.7833 },
    { name: '高新园区前置仓', lat: 38.8500, lon: 121.5167 },
  ];
  depots.forEach(function(d) {
    var gcj = wgs84ToGcj02(d.lat, d.lon);
    var icon = L.divIcon({
      className: 'fv-icon',
      html: '<div style="width:24px;height:24px;background:#FF6900;border-radius:4px;border:2px solid #FF8A33;display:flex;align-items:center;justify-content:center;font-size:11px;color:#fff;font-weight:700;box-shadow:0 2px 8px rgba(255,105,0,0.4)">仓</div>',
      iconSize: [24, 24], iconAnchor: [12, 12],
    });
    L.marker([gcj.lat, gcj.lon], { icon: icon })
      .bindPopup('<b>' + d.name + '</b><br><span style="color:#757575;font-size:11px">仓储配送节点</span>')
      .addTo(fleetMap);
  });
}

// ===== Geofence Layer =====
function initGeofenceLayer() {
  fleetGeofenceLayer = L.layerGroup().addTo(fleetMap);
  // Demo geofence zones (Dalian key areas)
  var zones = [
    { name: '中山核心商圈', coords: [[38.925,121.63],[38.925,121.655],[38.91,121.655],[38.91,121.63]], color: '#FF6B6B' },
    { name: '甘井子仓储区', coords: [[38.96,121.54],[38.96,121.57],[38.94,121.57],[38.94,121.54]], color: '#6BCB77' },
    { name: '高新园区', coords: [[38.86,121.50],[38.86,121.53],[38.84,121.53],[38.84,121.50]], color: '#A29BFE' },
  ];
  zones.forEach(function(z) {
    var gcjCoords = z.coords.map(function(c) {
      var gcj = wgs84ToGcj02(c[0], c[1]);
      return [gcj.lat, gcj.lon];
    });
    L.polygon(gcjCoords, {
      color: z.color, weight: 1.5, opacity: 0.6, fillOpacity: 0.08,
      dashArray: '6 4',
    }).bindTooltip(z.name, { permanent: true, direction: 'center', className: 'fleet-geofence-label' }).addTo(fleetGeofenceLayer);
  });
  fleetMap.removeLayer(fleetGeofenceLayer); // hidden by default
}

function toggleGeofenceLayer() {
  fleetGeofencesVisible = !fleetGeofencesVisible;
  if (fleetGeofencesVisible) {
    fleetGeofenceLayer.addTo(fleetMap);
  } else {
    fleetMap.removeLayer(fleetGeofenceLayer);
  }
}

function toggleRouteLabels() {
  fleetRouteLabelsVisible = !fleetRouteLabelsVisible;
}

// ===== Map Click: Add Plan Stop =====
function initMapClickHandler() {
  fleetMap.on('click', function(e) {
    if (!isPlannerActive()) return;

    var gcj = e.latlng;
    // GCJ-02 to WGS-84 for backend
    var wgs = { lat: gcj.lat, lon: gcj.lng };
    if (typeof gcoord !== 'undefined') {
      var result = gcoord.transform([gcj.lng, gcj.lat], gcoord.GCJ02, gcoord.WGS84);
      wgs = { lat: result[1], lon: result[0] };
    }

    planMarkerCounter++;
    var name = '配送点 #' + planMarkerCounter;

    planStops.push({
      lat: wgs.lat, lon: wgs.lon,
      name: name,
      demand_kg: Math.floor(Math.random() * 300 + 50),
      time_window_min: [480 + Math.floor(Math.random() * 240), 720 + Math.floor(Math.random() * 240)],
      service_minutes: Math.floor(Math.random() * 20 + 10),
    });

    addPlanMarker(gcj.lat, gcj.lng, name, planStops.length - 1);
    renderPlanStopsList();
    updatePlanOptimizeBtn();
  });
}

function isPlannerActive() {
  var panel = document.getElementById('fleet-panel-planner');
  return panel && panel.classList.contains('active');
}

function addPlanMarker(lat, lon, name, idx) {
  var icon = L.divIcon({
    className: 'fv-icon',
    html: '<div style="width:24px;height:24px;background:#FF6900;border-radius:50%;border:2px solid #fff;display:flex;align-items:center;justify-content:center;font-size:11px;color:#fff;font-weight:700;box-shadow:0 2px 8px rgba(255,105,0,0.4)">' + (idx + 1) + '</div>',
    iconSize: [24, 24], iconAnchor: [12, 12],
  });
  var marker = L.marker([lat, lon], { icon: icon, draggable: true })
    .bindPopup('<b>' + name + '</b><br><span style="font-size:11px;color:#757575">拖拽调整位置</span>')
    .addTo(fleetMap);

  marker.on('dragend', function() {
    var newGcj = marker.getLatLng();
    var newWgs = { lat: newGcj.lat, lon: newGcj.lng };
    if (typeof gcoord !== 'undefined') {
      var result = gcoord.transform([newGcj.lng, newGcj.lat], gcoord.GCJ02, gcoord.WGS84);
      newWgs = { lat: result[1], lon: result[0] };
    }
    planStops[idx].lat = newWgs.lat;
    planStops[idx].lon = newWgs.lon;
    clearPlanRoutes();
  });

  planMarkers.push(marker);
}

function renderPlanStopsList() {
  var list = document.getElementById('plan-stops-list');
  if (!list) return;
  if (!planStops.length) {
    list.innerHTML = '<div class="fleet-empty-state" style="padding:20px"><p style="font-size:12px">在地图上点击添加配送点</p></div>';
    return;
  }
  list.innerHTML = planStops.map(function(s, i) {
    return '<div class="plan-stop-item">' +
      '<span class="plan-stop-num">' + (i + 1) + '</span>' +
      '<span class="plan-stop-name">' + s.name + '</span>' +
      '<span style="font-size:10px;color:var(--text-dim)">' + s.demand_kg + 'kg</span>' +
      '<span class="plan-stop-del" onclick="removePlanStop(' + i + ')">&times;</span>' +
      '</div>';
  }).join('');
}

function removePlanStop(idx) {
  if (planMarkers[idx]) {
    fleetMap.removeLayer(planMarkers[idx]);
    planMarkers.splice(idx, 1);
  }
  planStops.splice(idx, 1);
  // Renumber
  planMarkers.forEach(function(m, i) {
    // Update icon
    var icon = L.divIcon({
      className: 'fv-icon',
      html: '<div style="width:24px;height:24px;background:#FF6B6B;border-radius:50%;border:2px solid #fff;display:flex;align-items:center;justify-content:center;font-size:11px;color:#fff;font-weight:700;box-shadow:0 2px 8px rgba(255,107,107,0.4)">' + (i + 1) + '</div>',
      iconSize: [24, 24], iconAnchor: [12, 12],
    });
    m.setIcon(icon);
  });
  clearPlanRoutes();
  renderPlanStopsList();
  updatePlanOptimizeBtn();
}

function clearPlanRoutes() {
  planRouteLines.forEach(function(l) { fleetMap.removeLayer(l); });
  planRouteLines = [];
  document.getElementById('plan-result').style.display = 'none';
}

function clearPlanStops() {
  planMarkers.forEach(function(m) { fleetMap.removeLayer(m); });
  planMarkers = [];
  planRouteLines.forEach(function(l) { fleetMap.removeLayer(l); });
  planRouteLines = [];
  planStops = [];
  planMarkerCounter = 0;
  renderPlanStopsList();
  updatePlanOptimizeBtn();
  document.getElementById('plan-result').style.display = 'none';
}

function updatePlanOptimizeBtn() {
  var btn = document.getElementById('plan-optimize-btn');
  if (btn) btn.disabled = planStops.length < 2;
}

// ===== Run Route Optimization =====
async function runRoutePlan() {
  if (planStops.length < 2) return;

  var depotSelect = document.getElementById('plan-depot');
  var depotVal = depotSelect.value.split(',');
  var scenario = document.getElementById('plan-scenario').value;

  var depot = { lat: parseFloat(depotVal[0]), lon: parseFloat(depotVal[1]), name: depotSelect.options[depotSelect.selectedIndex].text };

  var btn = document.getElementById('plan-optimize-btn');
  btn.disabled = true;
  btn.textContent = '优化中...';

  try {
    var resp = await fetch('/api/optimize', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        keyword: scenario,
        depot: depot,
        stops: planStops,
        vehicles: [
          { id: 'v1', plate: '辽B·12345', capacity_kg: 1000, cost_per_km: 3.5, fixed_cost: 30 },
          { id: 'v2', plate: '辽B·23456', capacity_kg: 1500, cost_per_km: 4.0, fixed_cost: 40 },
        ],
        strategy: 'min_distance',
      }),
    });

    if (!resp.ok) throw new Error(await resp.text());
    var data = await resp.json();

    // Clear previous route lines
    planRouteLines.forEach(function(l) { fleetMap.removeLayer(l); });
    planRouteLines = [];

    var colors = ['#FF6900', '#43A047', '#F57C00', '#2196F3', '#9C27B0'];

    // Draw routes on map
    data.routes.forEach(function(r, ri) {
      var color = colors[ri % colors.length];
      var coords = [];

      r.stops.forEach(function(st) {
        var gcj = wgs84ToGcj02(st.lat, st.lon);
        coords.push([gcj.lat, gcj.lon]);
      });

      if (coords.length >= 2) {
        var line = L.polyline(coords, {
          color: color, weight: 3, opacity: 0.8, dashArray: ri === 0 ? '' : '8 6',
        }).addTo(fleetMap);
        planRouteLines.push(line);

        // Add direction arrows at midpoint
        for (var i = 0; i < coords.length - 1; i++) {
          var midLat = (coords[i][0] + coords[i+1][0]) / 2;
          var midLon = (coords[i][1] + coords[i+1][1]) / 2;
          if (fleetRouteLabelsVisible) {
            var label = L.marker([midLat, midLon], {
              icon: L.divIcon({
                className: 'fv-icon',
                html: '<div style="font-size:10px;color:' + color + ';font-weight:700;text-shadow:0 1px 3px rgba(0,0,0,0.8)">&#9654;</div>',
                iconSize: [16, 16], iconAnchor: [8, 8],
              }),
            }).addTo(fleetMap);
            planRouteLines.push(label);
          }
        }
      }
    });

    // Fit bounds
    var allCoords = [];
    data.routes.forEach(function(r) {
      r.stops.forEach(function(st) {
        var gcj = wgs84ToGcj02(st.lat, st.lon);
        allCoords.push([gcj.lat, gcj.lon]);
      });
    });
    if (allCoords.length) {
      fleetMap.fitBounds(allCoords, { padding: [40, 40] });
    }

    // Render result
    var resultDiv = document.getElementById('plan-result');
    var statsDiv = document.getElementById('plan-result-stats');
    var routesDiv = document.getElementById('plan-result-routes');

    resultDiv.style.display = 'block';
    var s = data.summary || {};
    statsDiv.innerHTML =
      '<span>求解: <b>' + data.solver_status + '</b></span>' +
      '<span>总里程: <b>' + s.total_km + ' km</b></span>' +
      '<span>总成本: <b>&yen;' + s.total_cost + '</b></span>' +
      '<span>车辆: <b>' + s.vehicles_used + ' 辆</b></span>';

    routesDiv.innerHTML = data.routes.map(function(r, ri) {
      var color = colors[ri % colors.length];
      var stopsHTML = r.stops.map(function(st, j) {
        if (st.type === 'depot') {
          return '<div class="plan-route-stop"><span class="plan-route-stop-num" style="background:#FF6900">仓</span><span>' + st.name + ' <span style="font-size:10px;color:var(--text-dim)">出发</span></span></div>';
        }
        var arriveTime = st.arrive_min
          ? String(Math.floor(st.arrive_min / 60)).padStart(2, '0') + ':' + String(st.arrive_min % 60).padStart(2, '0')
          : '--:--';
        return '<div class="plan-route-stop"><span class="plan-route-stop-num" style="background:' + color + '">' + j + '</span><span>' + st.name + ' <span style="font-size:10px;color:var(--text-dim)">' + arriveTime + ' &middot; ' + st.demand_kg + 'kg</span></span></div>';
      }).join('');
      return '<div class="plan-route-card" style="border-left-color:' + color + '">' +
        '<div class="plan-route-header"><span style="color:' + color + '">&#128666; ' + r.plate + '</span><span style="font-size:11px;color:var(--text-dim)">' + r.load_pct + '%</span></div>' +
        '<div style="font-size:11px;color:var(--text-dim);margin-bottom:6px">' + r.total_km + ' km &middot; ' + r.total_minutes + '分钟 &middot; &yen;' + r.cost + '</div>' +
        stopsHTML + '</div>';
    }).join('');
  } catch (err) {
    alert('路径优化失败: ' + err.message);
  } finally {
    btn.disabled = false;
    btn.textContent = '优化路线';
  }
}

// ===== Fleet Tracking =====
async function startFleetTracking() {
  var btn = document.getElementById('fleet-start-btn');
  btn.disabled = true;
  btn.textContent = '启动中...';
  try {
    await fetch('/api/tracking/start', { method: 'POST' });
  } catch (e) { /* may already be running */ }
  btn.textContent = '追踪中';
  btn.className = 'btn-outline btn-sm';
  pollFleetPositions();
  if (fleetPollInterval) clearInterval(fleetPollInterval);
  fleetPollInterval = setInterval(pollFleetPositions, 3000);
}

async function pollFleetPositions() {
  try {
    var resp = await fetch('/api/tracking/live');
    var data = await resp.json();
    updateKPIBar(data);
    updateVehicleMarkers(data.positions || []);
    updateVehicleList(data.positions || []);
    updateSidebarFooter(data);
    generateAlerts(data.positions || []);
  } catch (e) {
    console.error('Fleet poll error:', e);
  }
}

function updateKPIBar(data) {
  var positions = data.positions || [];
  var online = positions.filter(function(p) { return p.ignition !== false; }).length;
  var driving = positions.filter(function(p) { return p.status === 'driving'; }).length;

  document.getElementById('fk-online').textContent = online;
  document.getElementById('fk-active').textContent = driving;

  // Estimate today's distance from pings
  var totalDist = (data.total_pings || 0) * 0.5; // rough estimate
  document.getElementById('fk-distance').textContent = Math.round(totalDist) + ' km';

  document.getElementById('fk-cost').textContent = '¥' + Math.round(totalDist * 4.5);
}

function updateVehicleMarkers(positions) {
  if (!fleetMap) return;
  var seenIds = new Set();

  positions.forEach(function(pos) {
    var vid = pos.vehicle_id;
    seenIds.add(vid);
    var icon = createVehicleIcon(pos.status, pos.heading);
    var gcj = wgs84ToGcj02(pos.latitude, pos.longitude);
    var latlng = [gcj.lat, gcj.lon];

    if (fleetMarkers[vid]) {
      fleetMarkers[vid].setLatLng(latlng);
      fleetMarkers[vid].setIcon(icon);
      fleetMarkers[vid].getPopup().setContent(vehiclePopupHTML(pos));
      updateTrail(vid, latlng);
    } else {
      var marker = L.marker(latlng, { icon: icon })
        .bindPopup(vehiclePopupHTML(pos))
        .addTo(fleetMap);
      marker.on('click', function() {
        fleetActiveVehicle = vid;
        highlightVehicleCard(vid);
        showTimeline(vid);
      });
      fleetMarkers[vid] = marker;
      fleetTrails[vid] = [latlng];
    }
  });

  Object.keys(fleetMarkers).forEach(function(vid) {
    if (!seenIds.has(vid)) {
      fleetMap.removeLayer(fleetMarkers[vid]);
      delete fleetMarkers[vid];
      delete fleetTrails[vid];
      if (fleetRouteLines[vid]) {
        fleetMap.removeLayer(fleetRouteLines[vid]);
        delete fleetRouteLines[vid];
      }
    }
  });
}

function updateTrail(vid, newPoint) {
  if (!fleetTrails[vid]) fleetTrails[vid] = [];
  fleetTrails[vid].push(newPoint);
  if (fleetTrails[vid].length > 30) {
    fleetTrails[vid] = fleetTrails[vid].slice(-30);
  }
  if (fleetRouteLines[vid]) {
    fleetMap.removeLayer(fleetRouteLines[vid]);
  }
  var trail = fleetTrails[vid];
  if (trail.length >= 2) {
    fleetRouteLines[vid] = L.polyline(trail, {
      color: '#FF6900', weight: 2, opacity: 0.4, dashArray: '4 6',
    }).addTo(fleetMap);
  }
}

function vehiclePopupHTML(pos) {
  var labels = { driving: '行驶中', stopped: '停留中', idle: '空闲' };
  return '<div style="min-width:170px">' +
    '<b style="font-size:14px">' + (pos.plate_number || pos.vehicle_id) + '</b>' +
    '<br><span style="color:#757575;font-size:11px">' + (pos.driver_name || '') + '</span>' +
    '<br><span style="color:#FF6900;font-weight:600">' + (labels[pos.status] || pos.status) + '</span>' +
    (pos.speed_kmh != null ? ' &middot; <span style="color:#43A047">' + pos.speed_kmh + ' km/h</span>' : '') +
    '<br><span style="font-size:11px;color:#757575">经纬度: ' + pos.latitude.toFixed(4) + ', ' + pos.longitude.toFixed(4) + '</span>' +
    (pos.order_id ? '<br><span style="font-size:11px;color:#757575">订单: ' + pos.order_id + '</span>' : '') +
    '</div>';
}

function updateVehicleList(positions) {
  var list = document.getElementById('fleet-vehicle-list');
  if (!list) return;
  if (!positions.length) {
    list.innerHTML = '<div class="fleet-empty-state">' +
      '<svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#BDBDBD" stroke-width="1"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>' +
      '<p>暂无车辆数据</p><button class="btn-primary btn-sm" onclick="startFleetTracking()">启动模拟追踪</button></div>';
    return;
  }

  var searchTerm = (document.getElementById('fleet-search-input')?.value || '').toLowerCase();
  var filtered = positions;
  if (searchTerm) {
    filtered = positions.filter(function(p) {
      return (p.plate_number || '').toLowerCase().indexOf(searchTerm) !== -1 ||
             (p.driver_name || '').toLowerCase().indexOf(searchTerm) !== -1;
    });
  }

  var labels = { driving: '行驶中', stopped: '停留中', idle: '空闲' };
  list.innerHTML = filtered.map(function(pos) {
    var isActive = fleetActiveVehicle === pos.vehicle_id;
    return '<div class="fleet-vehicle-card status-' + pos.status + (isActive ? ' active' : '') +
      '" onclick="focusVehicle(\'' + pos.vehicle_id + '\')">' +
      '<div class="fv-card-top">' +
      '<span class="fv-plate">' + (pos.plate_number || pos.vehicle_id) + '</span>' +
      '<span class="fv-status-badge ' + pos.status + '">' + (labels[pos.status] || pos.status) + '</span>' +
      '</div>' +
      '<div class="fv-driver">' + (pos.driver_name || '—') + '</div>' +
      '<div class="fv-details">' +
      (pos.speed_kmh != null ? '<span class="fv-speed">' + pos.speed_kmh + ' km/h</span>' : '') +
      (pos.order_id ? '<span>#' + pos.order_id + '</span>' : '') +
      '</div></div>';
  }).join('');
}

function filterVehicleList() {
  pollFleetPositions();
}

function focusVehicle(vid) {
  fleetActiveVehicle = vid;
  highlightVehicleCard(vid);
  var marker = fleetMarkers[vid];
  if (marker && fleetMap) {
    fleetMap.setView(marker.getLatLng(), 15, { animate: true });
    marker.openPopup();
  }
  showTimeline(vid);
}

function highlightVehicleCard(vid) {
  document.querySelectorAll('.fleet-vehicle-card').forEach(function(c) { c.classList.remove('active'); });
  document.querySelectorAll('.fleet-vehicle-card').forEach(function(c) {
    if (c.textContent.indexOf(vid) !== -1) c.classList.add('active');
  });
}

function resetFleetView() {
  fleetActiveVehicle = null;
  document.querySelectorAll('.fleet-vehicle-card').forEach(function(c) { c.classList.remove('active'); });
  if (fleetMap) fleetMap.setView([38.92, 121.63], 12);
  closeTimeline();
}

function updateSidebarFooter(data) {
  var now = new Date();
  var timeEl = document.getElementById('fs-update-time');
  var dot = document.getElementById('fs-dot');
  var statusText = document.getElementById('fs-status-text');
  if (timeEl) timeEl.textContent = now.toLocaleTimeString();
  if (dot) dot.className = 'fleet-status-dot' + (data.running ? ' live' : '');
  if (statusText) {
    statusText.textContent = data.running ? '实时追踪中' : '未连接';
    statusText.style.color = data.running ? '#43A047' : '#9E9E9E';
  }
}

// ===== Alerts =====
var lastAlertCount = 0;
function generateAlerts(positions) {
  var feed = document.getElementById('fleet-alert-feed');
  if (!feed) return;
  var alerts = [];
  var now = new Date();
  var timeStr = String(now.getHours()).padStart(2,'0') + ':' + String(now.getMinutes()).padStart(2,'0');

  positions.forEach(function(p) {
    if (p.status === 'stopped' && p.ignition !== false) {
      alerts.push({ time: timeStr, msg: p.plate_number + ' 在 ' + p.driver_name + ' 位置停留', level: 'warn' });
    }
    if (p.speed_kmh > 70) {
      alerts.push({ time: timeStr, msg: p.plate_number + ' 超速告警 (' + p.speed_kmh + 'km/h)', level: 'critical' });
    }
  });

  if (alerts.length > lastAlertCount) {
    document.getElementById('fk-alerts').textContent = alerts.length;
  }
  lastAlertCount = alerts.length;

  // Update feed with latest
  var existingItems = feed.querySelectorAll('.fleet-alert-item').length;
  if (alerts.length > existingItems) {
    var newAlerts = alerts.slice(existingItems);
    newAlerts.forEach(function(a) {
      var item = document.createElement('div');
      item.className = 'fleet-alert-item fleet-alert-' + a.level;
      item.innerHTML = '<div class="fleet-alert-time">' + a.time + '</div><div class="fleet-alert-msg">' + a.msg + '</div>';
      feed.insertBefore(item, feed.firstChild);
    });
    // Keep max 20
    while (feed.children.length > 20) feed.removeChild(feed.lastChild);
  }
}

// ===== Timeline =====
function showTimeline(vid) {
  var timeline = document.getElementById('fleet-timeline');
  if (!timeline) return;
  timeline.style.display = 'block';
  document.getElementById('fleet-timeline-start').textContent = '08:00';
  document.getElementById('fleet-timeline-end').textContent = '18:00';
  document.getElementById('fleet-timeline-slider').value = 100;
}

function closeTimeline() {
  var timeline = document.getElementById('fleet-timeline');
  if (timeline) timeline.style.display = 'none';
}

function scrubTimeline(val) {
  // In production: replay vehicle position at given percentage through recorded history
  // For demo: interpolate trail position
  if (!fleetActiveVehicle) return;
  var trail = fleetTrails[fleetActiveVehicle];
  if (!trail || trail.length < 2) return;
  var idx = Math.floor((val / 100) * (trail.length - 1));
  var marker = fleetMarkers[fleetActiveVehicle];
  if (marker) marker.setLatLng(trail[idx]);
}

// ===== Sidebar Tabs =====
function initSidebarTabs() {
  document.querySelectorAll('.fleet-tab').forEach(function(tab) {
    tab.addEventListener('click', function() {
      var tabName = this.dataset.tab;
      document.querySelectorAll('.fleet-tab').forEach(function(t) { t.classList.remove('active'); });
      this.classList.add('active');
      document.querySelectorAll('.fleet-tab-panel').forEach(function(p) { p.classList.remove('active'); });
      var panel = document.getElementById('fleet-panel-' + tabName);
      if (panel) panel.classList.add('active');

      // If switching away from planner, disable map click-to-add
      if (tabName !== 'planner') {
        // Keep plan markers but disable click-to-add behavior
      }
    });
  });
}

// ===== Init =====
document.addEventListener('DOMContentLoaded', function() {
  document.querySelectorAll('.nav-link[data-page="fleet"]').forEach(function(link) {
    link.addEventListener('click', function() {
      setTimeout(function() {
        initFleetMap();
      }, 300);
    });
  });
});
