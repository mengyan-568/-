/**
 * ai-browser.js — Browser-based AI analysis using @mlc-ai/web-llm
 *
 * Runs Qwen2.5-1.5B-Instruct entirely in the browser via WebGPU.
 * Zero config: no API key, no server, no installation.
 * Model weights (~1.6GB) download once and cache in IndexedDB.
 */

const BrowserAI = {
  _engine: null,
  _stage: 'idle',
  _progress: 0,
  _message: '',
  _currentModel: '',

  MODELS: {
    primary: {
      id: 'Qwen2.5-1.5B-Instruct-q4f16_1-MLC',
      name: 'Qwen2.5-1.5B-Instruct',
      size: '~1.6GB',
    },
    fallback: {
      id: 'Qwen2.5-0.5B-Instruct-q4f16_1-MLC',
      name: 'Qwen2.5-0.5B-Instruct',
      size: '~945MB',
    },
  },

  SYSTEM_PROMPT: `你是「洞见 Foresight」平台的资深商业策略分析师，专精于中国同城配送和最后一公里物流。

你的核心能力：
1. 基于真实用户评论数据，发现市场中未被满足的需求
2. 生成专业、数据驱动的商业分析报告
3. 为物流企业提供可执行的战略建议

输出规则：
- 必须严格使用中文
- 语气专业、自信、数据驱动，像麦肯锡咨询报告
- 目标受众是物流企业老板/决策者，让他们产生"这就是我要找的机会"的冲动
- 对于基于有限数据推断的结论，标注 [基于有限数据推断]
- 不要使用模糊表述（如"可能""也许"），用数据说话
- 每个结论都要有具体的、可执行的支撑
- 输出必须是合法的 JSON`,

  // ── WebGPU Detection ──

  isSupported() {
    return typeof navigator !== 'undefined' && !!navigator.gpu;
  },

  // ── Init & Model Loading ──

  async init(options = {}) {
    if (this._stage === 'ready') return true;
    if (this._stage === 'downloading' || this._stage === 'loading') {
      // Wait for existing load to finish
      while (this._stage !== 'ready' && this._stage !== 'error') {
        await new Promise(r => setTimeout(r, 200));
      }
      return this._stage === 'ready';
    }

    if (!this.isSupported()) {
      this._stage = 'error';
      this._message = 'WebGPU not supported';
      return false;
    }

    const modelChoice = options.model || 'primary';
    const model = this.MODELS[modelChoice] || this.MODELS.primary;
    this._currentModel = model.name;

    try {
      this._stage = 'downloading';
      this._progress = 0;
      this._message = `Loading ${model.name}...`;

      const { CreateMLCEngine } = await import(
        'https://cdn.jsdelivr.net/npm/@mlc-ai/web-llm@0.2.84/+esm'
      );

      this._engine = await CreateMLCEngine(model.id, {
        initProgressCallback: (report) => {
          this._progress = Math.round((report.progress || 0) * 100);
          this._message = report.text || `Downloading ${model.name}...`;
        },
      });

      this._stage = 'ready';
      this._message = `${model.name} ready`;
      return true;
    } catch (err) {
      console.error('[BrowserAI] Init failed:', err);

      // Try fallback model
      if (modelChoice === 'primary' && this.MODELS.fallback) {
        console.log('[BrowserAI] Trying fallback model...');
        return this.init({ model: 'fallback' });
      }

      this._stage = 'error';
      this._message = err.message || 'Unknown error';
      return false;
    }
  },

  // ── Inference ──

  async generate(prompt, opts = {}) {
    if (this._stage !== 'ready' || !this._engine) {
      throw new Error('Model not ready. Call init() first.');
    }

    this._stage = 'generating';

    const fullPrompt = this.SYSTEM_PROMPT + '\n\n---\n\n' + prompt;

    try {
      const response = await this._engine.chat.completions.create({
        messages: [{ role: 'user', content: fullPrompt }],
        temperature: 0.3,
        max_tokens: opts.maxTokens || 2048,
      });

      const text = response.choices[0].message.content;

      this._stage = 'ready';

      // Robust JSON extraction
      return this._parseJSON(text);
    } catch (err) {
      this._stage = 'ready';
      console.error('[BrowserAI] Generation failed:', err);
      return null;
    }
  },

  _parseJSON(text) {
    // Try direct parse
    try {
      return JSON.parse(text);
    } catch (e) { /* continue */ }

    // Try extracting from markdown code block
    const codeMatch = text.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (codeMatch) {
      try { return JSON.parse(codeMatch[1]); } catch (e) { /* continue */ }
    }

    // Try finding first { ... } block
    const braceMatch = text.match(/\{[\s\S]*\}/);
    if (braceMatch) {
      try { return JSON.parse(braceMatch[0]); } catch (e) { /* continue */ }
    }

    // Return raw text as fallback
    console.warn('[BrowserAI] Could not parse JSON, returning raw text');
    return { _raw: text, _parseError: true };
  },

  // ── Prompt Templates (ported from backend/llm/prompts.py) ──

  _formatOpps(opps) {
    return opps.slice(0, 5).map((o, i) =>
      `  ${i + 1}. ${o.category || '未知'} — 频次 ${((o.frequency || 0) * 100).toFixed(0)}%, 痛感 ${((o.pain_intensity || 0) * 100).toFixed(0)}%, 商机分 ${(o.score || 0).toFixed(0)}`
    ).join('\n');
  },

  _executiveSummaryPrompt(keyword, stats, opps) {
    return `## 任务：生成执行摘要

### 分析数据
- 关键词/场景：${keyword}
- 分析评论总数：${stats.total_reviews || 0} 条
- 负面评论占比：${((stats.negativity_rate || 0) * 100).toFixed(1)}%
- Top 3 痛点：
${this._formatOpps(opps.slice(0, 3))}

### 要求
生成一份让物流企业老板眼前一亮的执行摘要。包含：
1. headline：一句话点出最大的商业机会
2. summary：2-3 句话，涵盖数据洞察 + 核心商机 + 行动方向

请输出 JSON：
{"headline": "标题", "summary": "摘要正文"}`;
  },

  _swotPrompt(keyword, opps, report) {
    return `## 任务：SWOT 分析 — 新进入者的战略评估

### 背景
一个物流企业计划进入「${keyword}」市场（大连地区）。请基于以下真实数据做 SWOT 分析。

### 市场数据
- Top 痛点（来自真实评论）：
${this._formatOpps(opps.slice(0, 5))}

- 行业信息：${(report.industry_analysis || '').slice(0, 500)}

### 要求
SWOT 分析要基于真实评论数据，不是泛泛而谈：
- S（优势）：新进入者相对于现有玩家的优势（从现有玩家的差评中找）
- W（劣势）：新进入者面临的挑战（品牌、网络、资金等）
- O（机会）：市场中未被满足的需求（从高频痛点中提炼）
- T（威胁）：现有玩家的反击、价格战、客户锁定等

每个象限至少 3 条，每条要有数据依据。

输出 JSON：
{"strengths": ["..."], "weaknesses": ["..."], "opportunities": ["..."], "threats": ["..."]}`;
  },

  _strategyPrompt(keyword, opps, report) {
    return `## 任务：市场进入策略

### 场景
一个新物流企业要进入大连「${keyword}」市场。请基于数据制定进入策略。

### 核心痛点（评论数据）：
${this._formatOpps(opps.slice(0, 3))}

### 要求
1. positioning：一句话定位（如"大连首家午市30分钟必达的餐饮配送服务"）
2. geo_rollout：3 个区域，从易到难排列
3. pricing_strategy：渗透/溢价/价值定价？具体说明
4. key_differentiators：3-5 个，直接回应评论中的痛点

输出 JSON：
{"positioning": "...", "geo_rollout": ["区域1", "区域2", "区域3"], "pricing_strategy": "...", "key_differentiators": ["..."]}`;
  },

  _competitorGapPrompt(keyword, opps, report) {
    const merchants = (report.target_merchants || []).slice(0, 8).map(m => m.name).join(', ');
    return `## 任务：竞争差距分析

### 场景
分析「${keyword}」市场现有玩家的服务短板，找出新进入者可以切入的缝隙。

### 现有玩家
${merchants || '待识别'}

### 用户反馈的痛点（来自评论）：
${this._formatOpps(opps.slice(0, 5))}

### 要求
1. incumbent_weaknesses：从评论数据反推现有玩家弱点，具体到运营环节
2. differentiation_opportunities：新进入者可以怎么做不同
3. market_entry_angle：一句话，最有杀伤力的切入方式

输出 JSON：
{"incumbent_weaknesses": ["..."], "differentiation_opportunities": ["..."], "market_entry_angle": "..."}`;
  },

  _actionPlanPrompt(keyword, opps, report) {
    const merchantCount = (report.target_merchants || []).length;
    return `## 任务：90 天行动路线图

### 场景
一个物流企业要在 90 天内从零启动「${keyword}」业务（大连地区）。

### 需要解决的 Top 痛点：
${this._formatOpps(opps.slice(0, 3))}

### 潜在目标商家数量：${merchantCount} 家

### 要求
制定分阶段的 90 天行动路线图，每个阶段 3-4 项行动：
- Phase 1（前 30 天）：基础设施搭建
- Phase 2（30-60 天）：试运营和市场验证
- Phase 3（60-90 天）：规模扩展

每项行动包含：具体做什么、预期效果、实施难度（低/中/高）。

输出 JSON：
{"items": [{"phase": "30天", "action": "...", "expected_impact": "...", "difficulty": "低|中|高"}, ...]}`;
  },

  _roiPrompt(keyword, opps, report) {
    const merchantCount = (report.target_merchants || []).length;
    return `## 任务：ROI 潜力评估

### 场景
评估在「${keyword}」市场（大连地区）的投入回报潜力。

### 数据
- 潜在目标商家数：${merchantCount} 家
- Top 痛点：${this._formatOpps(opps.slice(0, 3))}

### 要求
保守估算：
1. estimated_market_size：一句话描述（如"大连地区餐饮配送日订单量约X万单，年市场规模约Y万元"）
2. addressable_share_pct：第一年预计可获取的市场份额百分比（数字）
3. revenue_potential：一句话描述预期年营收
4. key_assumptions：3-4 个支撑估算的关键假设

输出 JSON：
{"estimated_market_size": "...", "addressable_share_pct": 数字, "revenue_potential": "...", "key_assumptions": ["..."]}`;
  },

  // ── Run All 6 Analysis Tasks ──

  async analyzeReport(report) {
    const keyword = report.keyword || '';
    const opps = report.opportunities || [];
    const stats = report.stats || {};

    if (!opps.length) {
      console.warn('[BrowserAI] No opportunities to analyze');
      return {};
    }

    const results = {};

    const tasks = [
      { key: 'executive_summary', fn: () => this.generate(this._executiveSummaryPrompt(keyword, stats, opps)) },
      { key: 'swot', fn: () => this.generate(this._swotPrompt(keyword, opps, report)) },
      { key: 'strategy', fn: () => this.generate(this._strategyPrompt(keyword, opps, report)) },
      { key: 'competitor_gap', fn: () => this.generate(this._competitorGapPrompt(keyword, opps, report)) },
      { key: 'action_plan', fn: () => this.generate(this._actionPlanPrompt(keyword, opps, report)) },
      { key: 'roi', fn: () => this.generate(this._roiPrompt(keyword, opps, report)) },
    ];

    for (const task of tasks) {
      try {
        const result = await task.fn();
        if (result && !result._parseError) {
          results[task.key] = result;
        }
      } catch (err) {
        console.warn(`[BrowserAI] Task ${task.key} failed:`, err.message);
      }
    }

    return results;
  },

  // ── Status ──

  getStatus() {
    return {
      stage: this._stage,
      progress: this._progress,
      message: this._message,
      modelName: this._currentModel,
    };
  },

  // ── Cleanup ──

  async destroy() {
    if (this._engine) {
      try {
        await this._engine.unload();
      } catch (e) { /* ignore */ }
      this._engine = null;
    }
    this._stage = 'idle';
    this._progress = 0;
    this._message = '';
  },
};

// Export for use in app.js
if (typeof window !== 'undefined') {
  window.BrowserAI = BrowserAI;
}
