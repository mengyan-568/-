/**
 * 痛点挖掘引擎 — 前端交互逻辑 v2
 * ECharts 替代 Chart.js + 骨架屏 + 渐进式披露
 */
const API = '/api';

// ===== Page Navigation =====
document.querySelectorAll('.nav-link').forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    const page = link.dataset.page;
    document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
    link.classList.add('active');
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.getElementById(`page-${page}`).classList.add('active');
    if (page === 'reports') loadReports();
    if (page === 'tracking') loadTrackingBoard();
  });
});

// ===== Quick Tags =====
document.querySelectorAll('.tag').forEach(tag => {
  tag.addEventListener('click', () => {
    document.getElementById('keyword-input').value = tag.dataset.keyword;
    startAnalysis();
  });
});

// ===== Analyze Button =====
document.getElementById('analyze-btn').addEventListener('click', startAnalysis);
document.getElementById('keyword-input').addEventListener('keydown', e => {
  if (e.key === 'Enter') startAnalysis();
});

// ===== Modal Close =====
document.querySelector('.modal-close')?.addEventListener('click', () => {
  document.getElementById('report-modal').style.display = 'none';
});
document.querySelector('.modal-overlay')?.addEventListener('click', () => {
  document.getElementById('report-modal').style.display = 'none';
});

// ===== ECharts: window resize handler =====
window.addEventListener('resize', () => {
  Object.values(chartInstances).forEach(c => c?.resize?.());
});

// ===== Start Analysis =====
async function startAnalysis() {
  const input = document.getElementById('keyword-input');
  const keyword = input.value.trim();
  if (!keyword) { input.focus(); return; }

  const btn = document.getElementById('analyze-btn');
  btn.disabled = true;
  btn.querySelector('.btn-text').style.display = 'none';
  btn.querySelector('.btn-loader').style.display = 'inline';

  const container = document.getElementById('report-container');
  container.style.display = 'block';
  container.innerHTML = renderSkeleton();
  container.scrollIntoView({ behavior: 'smooth' });

  try {
    const resp = await fetch(`${API}/analyze`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ keyword, sources: ['app_store', 'ecommerce'], max_reviews: 200 }),
    });
    if (!resp.ok) throw new Error((await resp.json()).detail || '分析失败');
    const report = await resp.json();
    renderReport(report);

    // Kick off browser AI analysis (non-blocking, progressive enhancement)
    runBrowserAI(report);
  } catch (err) {
    container.innerHTML = `<div class="loading"><p style="color:var(--danger)">分析出错: ${err.message}</p><button class="btn-outline" onclick="startAnalysis()">重试</button></div>`;
  } finally {
    btn.disabled = false;
    btn.querySelector('.btn-text').style.display = 'inline';
    btn.querySelector('.btn-loader').style.display = 'none';
  }
}

function renderSkeleton() {
  return `
    <div class="skeleton-container">
      <div class="skeleton-card">
        <div class="skeleton skeleton-line skeleton-line--lg"></div>
        <div class="skeleton skeleton-line"></div>
        <div class="skeleton skeleton-line skeleton-line--sm"></div>
      </div>
      <div class="kpi-stats" style="padding:0;margin-bottom:24px">
        ${[1,2,3,4].map(() => `<div class="kpi-card"><div class="skeleton skeleton-line skeleton-line--lg" style="margin:0 auto;width:60%"></div><div class="skeleton skeleton-line skeleton-line--sm" style="margin:8px auto 0;width:40%"></div></div>`).join('')}
      </div>
      <div class="charts-row">
        <div class="skeleton-card"><div class="skeleton skeleton-line" style="width:30%;margin-bottom:16px"></div><div class="skeleton skeleton-chart"></div></div>
        <div class="skeleton-card"><div class="skeleton skeleton-line" style="width:30%;margin-bottom:16px"></div><div class="skeleton skeleton-chart"></div></div>
      </div>
      <div class="skeleton-card"><div class="skeleton skeleton-line skeleton-line--lg" style="width:25%"></div><div class="skeleton skeleton-line" style="margin-top:12px"></div><div class="skeleton skeleton-line skeleton-line--sm"></div></div>
    </div>`;
}

// ===== Render Report =====
let chartInstances = {};

function destroyCharts() {
  Object.values(chartInstances).forEach(c => {
    try { c?.dispose?.(); } catch(e) {}
  });
  chartInstances = {};
}

function renderReport(report) {
  destroyCharts();
  const container = document.getElementById('report-container');
  const opps = (report.opportunities || []).slice(0, 5);
  const stats = report.stats || {};
  const heatmap = report.pain_heatmap || [];
  let html = renderReportHTML(report, opps, stats);
  html += `<div class="download-bar reveal"><p>专业版用户可下载完整 PDF 报告（含原始数据导出）</p><button class="btn-outline" onclick="window.print()">打印 / 导出 PDF</button></div>`;
  container.innerHTML = html;

  // Update KPI stats row
  updateKPIStats(report, opps);

  // Trigger staggered reveal animations
  container.querySelectorAll('.report-summary, .report-stats, .report-section, .chart-card, .stat-card, .download-bar, .opp-table').forEach(el => {
    el.classList.add('reveal');
  });

  container.scrollIntoView({ behavior: 'smooth' });
  setTimeout(() => renderCharts(heatmap, report.satisfaction_radar || [], opps, report.stats), 150);
}

function updateKPIStats(report, opps) {
  const kpiRow = document.getElementById('kpi-stats');
  if (!kpiRow) return;
  kpiRow.style.display = 'grid';
  const stats = report.stats || {};
  document.getElementById('kpi-total').textContent = stats.total_reviews || 0;
  document.getElementById('kpi-neg').textContent = ((stats.negativity_rate || 0) * 100).toFixed(1) + '%';
  document.getElementById('kpi-score').textContent = opps[0]?.score || '--';
  document.getElementById('kpi-opps').textContent = opps.length || 0;
}

// ===== ECharts Rendering (4 chart types) =====

function renderCharts(heatmap, satisfaction, opportunities, stats) {

  // 1. Pain Heatmap — Horizontal Bar
  const heatDom = document.getElementById('chart-pain-heatmap');
  if (heatDom && heatmap.length) {
    const chart = echarts.init(heatDom);
    chart.setOption({
      tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
      grid: { left: '3%', right: '8%', bottom: '3%', containLabel: true },
      xAxis: { type: 'value', name: '负面频次' },
      yAxis: {
        type: 'category',
        data: heatmap.map(h => h.category).reverse(),
        axisLabel: { fontSize: 13, color: '#191919' },
        axisLine: { lineStyle: { color: '#E0E0E0' } },
      },
      series: [{
        type: 'bar',
        data: [...heatmap].reverse().map(h => ({
          value: h.count,
          itemStyle: {
            color: `rgba(255,105,0,${0.25 + h.avg_pain_score * 0.65})`,
            borderRadius: [0, 4, 4, 0],
          },
        })),
        barWidth: '55%',
        emphasis: { itemStyle: { color: '#FF6900' } },
      }],
    });
    chartInstances.heatmap = chart;
  }

  // 2. Satisfaction Radar
  const satDom = document.getElementById('chart-satisfaction');
  if (satDom && satisfaction.length) {
    const chart = echarts.init(satDom);
    chart.setOption({
      tooltip: {},
      radar: {
        center: ['50%', '55%'],
        radius: '65%',
        indicator: satisfaction.map(s => ({ name: s.dimension, max: 10 })),
        axisName: { color: '#191919', fontSize: 12 },
        splitArea: { areaStyle: { color: ['rgba(255,105,0,0.02)', 'rgba(255,105,0,0.04)'] } },
        axisLine: { lineStyle: { color: '#E0E0E0' } },
        splitLine: { lineStyle: { color: '#F0F0F0' } },
      },
      series: [{
        type: 'radar',
        data: [{
          value: satisfaction.map(s => s.satisfaction),
          name: '满足度',
          areaStyle: { color: 'rgba(255,105,0,0.15)' },
          lineStyle: { color: '#FF6900', width: 2 },
          itemStyle: { color: '#FF6900' },
          symbol: 'circle',
          symbolSize: 5,
        }],
      }],
    });
    chartInstances.satisfaction = chart;
  }

  // 3. Opportunity Scatter/Bubble
  const scatterDom = document.getElementById('chart-opportunity-scatter');
  if (scatterDom && opportunities.length) {
    const chart = echarts.init(scatterDom);
    const data = opportunities.slice(0, 8).map(o => ({
      value: [(o.frequency * 100).toFixed(0), (o.pain_intensity * 100).toFixed(0), o.score, o.category],
      name: o.category,
    }));
    chart.setOption({
      tooltip: {
        formatter: p => `${p.name}<br/>频次: ${p.value[0]}%<br/>痛感: ${p.value[1]}%<br/>商机分数: ${p.value[2]}`,
      },
      grid: { left: '8%', right: '5%', top: '10%', bottom: '10%' },
      xAxis: { name: '发生频次 (%)', nameTextStyle: { color: '#757575' }, axisLabel: { color: '#757575' } },
      yAxis: { name: '痛感强度 (%)', nameTextStyle: { color: '#757575' }, axisLabel: { color: '#757575' } },
      series: [{
        type: 'scatter',
        data: data,
        symbolSize: d => Math.max(12, Math.min(60, d[2] * 0.8)),
        itemStyle: {
          color: p => {
            const score = p.value[2];
            if (score > 30) return 'rgba(229,57,53,0.7)';
            if (score > 15) return 'rgba(245,124,0,0.7)';
            return 'rgba(67,160,71,0.7)';
          },
          shadowBlur: 8,
          shadowColor: 'rgba(255,105,0,0.15)',
        },
        label: {
          show: true,
          formatter: p => p.name,
          position: 'right',
          fontSize: 11,
          color: '#191919',
        },
        emphasis: { scale: 1.3 },
      }],
    });
    chartInstances.scatter = chart;
  }

  // 4. Gauge — Overall Negativity
  const gaugeDom = document.getElementById('chart-negativity-gauge');
  if (gaugeDom && stats) {
    const chart = echarts.init(gaugeDom);
    const rate = (stats.negativity_rate || 0) * 100;
    chart.setOption({
      series: [{
        type: 'gauge',
        startAngle: 210, endAngle: -30,
        min: 0, max: 100,
        splitNumber: 10,
        progress: { show: true, width: 14, itemStyle: { color: rate > 40 ? '#E53935' : rate > 20 ? '#F57C00' : '#43A047' } },
        axisLine: { lineStyle: { width: 14, color: [[0.3, '#43A047'], [0.6, '#F57C00'], [1, '#E53935']] } },
        axisTick: { show: false },
        splitLine: { show: false },
        axisLabel: { show: false },
        detail: { valueAnimation: true, fontSize: 28, fontWeight: 'bold', color: '#FF6900', formatter: '{value}%' },
        title: { fontSize: 12, color: '#757575', offsetCenter: [0, '75%'] },
        data: [{ value: rate.toFixed(1), name: '整体负面率' }],
      }],
    });
    chartInstances.gauge = chart;
  }
}

// ===== Load Reports History =====
async function loadReports() {
  const list = document.getElementById('reports-list');
  list.innerHTML = '<div class="loading"><div class="spinner"></div></div>';
  try {
    const resp = await fetch(`${API}/reports`);
    const reports = await resp.json();
    if (!reports.length) { list.innerHTML = '<div class="loading"><p>暂无历史报告</p></div>'; return; }
    list.innerHTML = reports.map(r => `
      <div class="report-item" onclick="viewReport(${r.id})">
        <div><div class="report-item-title">${r.keyword}</div><div class="report-item-date">${r.created_at}</div></div>
        <button class="btn-outline">查看报告</button>
      </div>`).join('');
  } catch (err) { list.innerHTML = `<div class="loading"><p>加载失败: ${err.message}</p></div>`; }
}

async function viewReport(id) {
  const modal = document.getElementById('report-modal');
  const body = document.getElementById('modal-body');
  modal.style.display = 'flex';
  body.innerHTML = '<div class="loading"><div class="spinner"></div></div>';
  try {
    const resp = await fetch(`${API}/reports/${id}`);
    const report = await resp.json();
    document.getElementById('modal-title').textContent = `商机洞察: ${report.keyword}`;
    destroyCharts();
    const opps = (report.opportunities || []).slice(0, 5);
    const stats = report.stats || {};
    const heatmap = report.pain_heatmap || [];
    let html = renderReportHTML(report, opps, stats);
    html += `<div class="download-bar"><p>专业版用户可下载完整 PDF 报告（含原始数据导出）</p><button class="btn-outline" onclick="window.print()">打印 / 导出 PDF</button></div>`;
    body.innerHTML = html;
    setTimeout(() => renderCharts(heatmap, report.satisfaction_radar || []), 100);
  } catch (err) { body.innerHTML = `<div class="loading"><p>加载失败: ${err.message}</p></div>`; }
}

function renderReportHTML(report, opps, stats) {
  const scenarioLabel = report.scenario ? ` <span style="font-size:13px;color:var(--text-dim);font-weight:400">（${report.scenario}场景）</span>` : '';
  return `
    ${renderReportSourceBar(report)}
    ${renderOpportunitySynthesis(report)}
    <div class="report-summary">${report.summary || ''}</div>
    <div class="report-stats">
      <div class="stat-card"><div class="stat-value">${stats.total_reviews || 0}</div><div class="stat-label">采集评论数</div></div>
      <div class="stat-card"><div class="stat-value">${stats.total_negative || 0}</div><div class="stat-label">负面评价数</div></div>
      <div class="stat-card"><div class="stat-value">${((stats.negativity_rate || 0) * 100).toFixed(1)}%</div><div class="stat-label">负面率</div></div>
      <div class="stat-card"><div class="stat-value" style="color:var(--xiaomi-orange)">${opps[0]?.score || '-'}</div><div class="stat-label">最大商机分数</div></div>
    </div>
    ${renderAISections(report.ai_analysis)}
    ${report.industry_analysis ? `
      <div class="report-section">
        <div class="section-toggle" onclick="this.classList.toggle('collapsed');this.nextElementSibling.classList.toggle('collapsed')">
          <h3 style="margin:0">行业分析${scenarioLabel}</h3>
        </div>
        <div class="section-body" style="max-height:3000px"><p>${report.industry_analysis.replace(/\n\n/g, '</p><p>')}</p></div>
      </div>` : ''}
    <div class="charts-row">
      <div class="chart-card"><h3>痛点热度分布</h3><div class="chart-wrapper"><div id="chart-pain-heatmap" style="width:100%;height:300px"></div></div></div>
      <div class="chart-card"><h3>现有方案满足度</h3><div class="chart-wrapper"><div id="chart-satisfaction" style="width:100%;height:300px"></div></div></div>
    </div>
    <div class="charts-row">
      <div class="chart-card"><h3>商机分布地图</h3><div class="chart-wrapper"><div id="chart-opportunity-scatter" style="width:100%;height:300px"></div></div></div>
      <div class="chart-card"><h3>综合满意度</h3><div class="chart-wrapper"><div id="chart-negativity-gauge" style="width:100%;height:300px"></div></div></div>
    </div>
    ${report.pain_deepdive ? `
      <div class="report-section">
        <div class="section-toggle" onclick="this.classList.toggle('collapsed');this.nextElementSibling.classList.toggle('collapsed')">
          <h3 style="margin:0">痛点深度分析</h3>
        </div>
        <div class="section-body" style="max-height:4000px"><p>${report.pain_deepdive.replace(/\n\n/g, '</p><p>')}</p></div>
      </div>` : ''}
    ${report.target_merchants ? renderTargetMerchants(report.target_merchants) : ''}
    ${report.negative_reviews ? renderNegativeReviewWall(report.negative_reviews) : ''}
    <div class="opportunities-section"><h3>商机排序</h3>
      <table class="opp-table">
        <thead><tr><th>排名</th><th>痛点维度</th><th>商机分数</th><th>频次</th><th>痛感强度</th><th>满足度缺口</th><th>付费意愿</th><th>建议</th></tr></thead>
        <tbody>${opps.map((o, i) => {
          const sc = o.score > 30 ? 'score-high' : o.score > 15 ? 'score-mid' : 'score-low';
          const wl = o.willingness_to_pay === '高' ? 'willingness-high' : o.willingness_to_pay === '中' ? 'willingness-mid' : 'willingness-low';
          return `<tr><td><strong>#${i+1}</strong></td><td>${o.category}</td><td><span class="score-badge ${sc}">${o.score}</span></td><td>${((o.frequency||0)*100).toFixed(0)}%</td><td>${o.pain_intensity?.toFixed(2)||'-'}</td><td>${o.satisfaction_gap||'-'}</td><td class="${wl}">${o.willingness_to_pay}</td><td style="font-size:13px;color:var(--text-dim)">${o.suggestion||''}</td></tr>`;
        }).join('')}</tbody>
      </table>
    </div>
    ${report.action_plan ? `
      <div class="report-section">
        <div class="section-toggle" onclick="this.classList.toggle('collapsed');this.nextElementSibling.classList.toggle('collapsed')">
          <h3 style="margin:0">行动建议</h3>
        </div>
        <div class="section-body" style="max-height:5000px"><p>${report.action_plan.replace(/\n/g, '<br>')}</p></div>
      </div>` : ''}`;
}

// ===== AI Analysis Rendering =====

function renderAISections(ai) {
  if (!ai || Object.keys(ai).length === 0) return '';
  let html = '';

  if (ai.executive_summary) {
    const es = ai.executive_summary;
    html += `<div class="report-section ai-section">
      <div class="section-toggle"><h3 style="margin:0">AI 执行摘要 <span class="ai-badge">AI 生成</span></h3></div>
      <div class="section-body">
        <p style="font-size:18px;font-weight:700;color:var(--xiaomi-orange);margin-bottom:8px">${escapeHTML(es.headline || '')}</p>
        <p style="font-size:14px;line-height:1.8;color:var(--text-dim)">${escapeHTML(es.summary || '')}</p>
      </div>
    </div>`;
  }

  if (ai.swot) html += renderSWOTQuadrant(ai.swot);
  if (ai.strategy) html += renderStrategyCards(ai.strategy);
  if (ai.competitor_gap) html += renderCompetitorGap(ai.competitor_gap);
  if (ai.action_plan) html += renderActionTimeline(ai.action_plan);
  if (ai.roi) html += renderROICards(ai.roi);

  return html;
}

function renderSWOTQuadrant(swot) {
  const quadrants = [
    { key: 'strengths', label: 'S 优势', cls: 'swot-s' },
    { key: 'weaknesses', label: 'W 劣势', cls: 'swot-w' },
    { key: 'opportunities', label: 'O 机会', cls: 'swot-o' },
    { key: 'threats', label: 'T 威胁', cls: 'swot-t' },
  ];

  const cells = quadrants.map(q => {
    const items = (swot[q.key] || []).map(s => `<li>${escapeHTML(s)}</li>`).join('');
    return `<div class="swot-quad ${q.cls}"><h4>${q.label}</h4><ul>${items}</ul></div>`;
  }).join('');

  return `<div class="report-section ai-section">
    <div class="section-toggle"><h3 style="margin:0">SWOT 分析 <span class="ai-badge">AI 生成</span></h3></div>
    <div class="section-body"><div class="swot-grid">${cells}</div></div>
  </div>`;
}

function renderStrategyCards(strategy) {
  const geoItems = (strategy.geo_rollout || []).map((g, i) =>
    `<li>${i + 1}. ${escapeHTML(g)}</li>`
  ).join('');
  const diffItems = (strategy.key_differentiators || []).map(d =>
    `<li>${escapeHTML(d)}</li>`
  ).join('');

  return `<div class="report-section ai-section">
    <div class="section-toggle"><h3 style="margin:0">市场进入策略 <span class="ai-badge">AI 生成</span></h3></div>
    <div class="section-body">
      <div class="strategy-cards">
        <div class="strategy-card">
          <h4>定位</h4>
          <p>${escapeHTML(strategy.positioning || '')}</p>
        </div>
        <div class="strategy-card">
          <h4>区域扩展路线</h4>
          <ul>${geoItems}</ul>
        </div>
        <div class="strategy-card">
          <h4>定价策略</h4>
          <p>${escapeHTML(strategy.pricing_strategy || '')}</p>
        </div>
        <div class="strategy-card">
          <h4>核心差异化</h4>
          <ul>${diffItems}</ul>
        </div>
      </div>
    </div>
  </div>`;
}

function renderCompetitorGap(gap) {
  const weaknesses = (gap.incumbent_weaknesses || []).map(w =>
    `<li><strong>现存问题：</strong>${escapeHTML(w)}</li>`
  ).join('');
  const opps = (gap.differentiation_opportunities || []).map(o =>
    `<li><strong>差异化机会：</strong>${escapeHTML(o)}</li>`
  ).join('');

  return `<div class="report-section ai-section">
    <div class="section-toggle"><h3 style="margin:0">竞争差距分析 <span class="ai-badge">AI 生成</span></h3></div>
    <div class="section-body">
      <div class="gap-angle">切入角度：${escapeHTML(gap.market_entry_angle || '')}</div>
      <ul class="competitor-gap-list">${weaknesses}${opps}</ul>
    </div>
  </div>`;
}

function renderActionTimeline(plan) {
  const items = plan.items || [];
  const phases = [
    { key: '30天', label: 'Phase 1 · 前 30 天', sub: '基础设施搭建' },
    { key: '60天', label: 'Phase 2 · 30-60 天', sub: '试运营和市场验证' },
    { key: '90天', label: 'Phase 3 · 60-90 天', sub: '规模扩展' },
  ];

  const timelineHTML = phases.map(p => {
    const phaseItems = items.filter(i => i.phase === p.key);
    if (!phaseItems.length) return '';
    const cards = phaseItems.map(item => {
      const diffKey = item.difficulty === '高' ? 'hard' : item.difficulty === '中' ? 'medium' : 'easy';
      return `<div class="timeline-item">
        <div class="timeline-item-icon ${diffKey}">${item.difficulty === '高' ? '!' : item.difficulty === '中' ? '~' : '✓'}</div>
        <div class="timeline-item-text">
          <strong>${escapeHTML(item.action)}</strong>
          <span>${escapeHTML(item.expected_impact || '')}</span>
        </div>
      </div>`;
    }).join('');
    return `<div class="timeline-phase">
      <div class="timeline-dot"></div>
      <h4>${p.label} <span style="font-size:12px;color:var(--text-dim);font-weight:400">${p.sub}</span></h4>
      <div class="timeline-items">${cards}</div>
    </div>`;
  }).join('');

  return `<div class="report-section ai-section">
    <div class="section-toggle"><h3 style="margin:0">90 天行动路线图 <span class="ai-badge">AI 生成</span></h3></div>
    <div class="section-body"><div class="action-timeline">${timelineHTML}</div></div>
  </div>`;
}

function renderROICards(roi) {
  const assumptions = (roi.key_assumptions || []).map(a => `<li>${escapeHTML(a)}</li>`).join('');
  return `<div class="report-section ai-section">
    <div class="section-toggle"><h3 style="margin:0">ROI 潜力评估 <span class="ai-badge">AI 生成</span></h3></div>
    <div class="section-body">
      <div class="roi-cards">
        <div class="roi-card">
          <h4>预估市场规模</h4>
          <div class="roi-value">${escapeHTML(roi.estimated_market_size || '')}</div>
        </div>
        <div class="roi-card">
          <h4>可获取份额（首年）</h4>
          <div class="roi-value">${roi.addressable_share_pct != null ? roi.addressable_share_pct + '%' : '--'}</div>
        </div>
        <div class="roi-card">
          <h4>营收潜力</h4>
          <div class="roi-value">${escapeHTML(roi.revenue_potential || '')}</div>
        </div>
      </div>
      ${assumptions ? `<div class="roi-assumptions"><h4 style="font-size:13px;color:var(--text-dim);margin:0 0 8px">关键假设</h4><ul style="margin:0;padding-left:18px;font-size:13px;color:var(--text-dim);line-height:1.8">${assumptions}</ul></div>` : ''}
    </div>
  </div>`;
}

// ===== Browser AI Integration =====

async function runBrowserAI(report) {
  if (!window.BrowserAI) {
    console.log('[app] BrowserAI not available, skipping');
    return;
  }

  const ai = window.BrowserAI;

  // Check if WebGPU is supported
  if (!ai.isSupported()) {
    renderAIStatusBanner('unsupported');
    return;
  }

  // Show loading banner
  renderAIStatusBanner('downloading');

  // Load model (downloads on first use, cached on subsequent)
  const loaded = await ai.init();
  if (!loaded) {
    renderAIStatusBanner('error');
    return;
  }

  // Show analyzing banner
  renderAIStatusBanner('analyzing');

  // Run all 6 analysis tasks
  const results = await ai.analyzeReport(report);

  if (results && Object.keys(results).length > 0) {
    // Inject AI results into the DOM by re-rendering AI sections
    const container = document.getElementById('report-container');
    // Find the first ai-section or insert after opportunity-synthesis
    const afterEl = container.querySelector('.report-stats');
    const existingAI = container.querySelector('.ai-section');

    if (existingAI) {
      // Remove existing AI sections and re-render
      let el = existingAI;
      while (el) {
        const next = el.nextElementSibling;
        if (el.classList.contains('ai-section')) {
          el.remove();
        } else {
          break;
        }
        el = next;
      }
    }

    // Insert new AI sections after stats
    if (afterEl) {
      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = renderAISections(results);

      // Insert all children after the stats row
      const frag = document.createDocumentFragment();
      while (tempDiv.firstChild) {
        frag.appendChild(tempDiv.firstChild);
      }
      afterEl.insertAdjacentElement('afterend', frag.firstChild);

      // Actually, insert all children properly
      let insertAfter = afterEl;
      while (tempDiv.firstChild) {
        insertAfter.after(tempDiv.firstChild);
        insertAfter = insertAfter.nextElementSibling;
      }
    }

    // Also update report data so viewReport can use it
    report.ai_analysis = results;

    renderAIStatusBanner('done');

    // Auto-hide banner after 8 seconds
    setTimeout(() => {
      const banner = document.getElementById('ai-status-banner');
      if (banner) banner.style.display = 'none';
    }, 8000);
  } else {
    renderAIStatusBanner('error');
  }

  // Free GPU memory
  ai.destroy();
}

// ===== Data Source Bar =====
function renderReportSourceBar(report) {
  const stats = report.stats || {};
  const neg = report.negative_reviews || [];
  const sources = {};
  let demoCount = 0, webCount = 0;
  neg.forEach(r => {
    const s = (r.source || '').toLowerCase();
    if (s.includes('demo') || s.includes('模拟')) demoCount++;
    else if (s.includes('web')) webCount++;
    else if (s) webCount++;
    else demoCount++;
  });

  const hasCompanies = (report.target_merchants || []).length > 0;
  const hasWebSearch = webCount > 0 || hasCompanies;

  let parts = [];
  parts.push(`<span class="src-badge src-badge--total">📊 分析基数：${stats.total_reviews || 0} 条评论（负面 ${stats.total_negative || 0} 条，负面率 ${((stats.negativity_rate||0)*100).toFixed(1)}%）</span>`);

  if (hasWebSearch) {
    parts.push(`<span class="src-badge src-badge--web">🌐 互联网采集：${webCount} 条真实评论` + (hasCompanies ? ` + ${report.target_merchants.length} 家企业数据` : '') + `</span>`);
  }
  if (demoCount > 0) {
    parts.push(`<span class="src-badge src-badge--demo">📋 AI 模拟：${demoCount} 条场景化评论（基于行业模板生成）</span>`);
  }
  if (report.scenario) {
    parts.push(`<span class="src-badge src-badge--scenario">🎯 场景匹配：${escapeHTML(report.scenario)}</span>`);
  }

  return `<div class="report-source-bar">${parts.join('')}</div>`;
}

// ===== Opportunity Synthesis =====

function renderOpportunitySynthesis(report) {
  const opps = (report.opportunities || []).slice(0, 3);
  if (!opps.length) return '';
  const top = opps[0];
  const stats = report.stats || {};

  const seasonalNote = report.scenario === '生鲜冷链' ? '大连樱桃季、海鲜旺季即将到来，冷链配送需求激增。'
    : report.scenario === '餐饮配送' ? '大连旅游旺季餐饮配送需求暴涨，现有运力明显不足。'
    : report.scenario === '家具配送' ? '大连老城区大量无电梯老楼，搬运服务是刚需也是壁垒。'
    : report.scenario === '医药配送' ? 'GSP合规要求趋严，不合规的小型配送商将被淘汰。'
    : report.scenario === '商超补货' ? '鲜食日配的时效要求极高，延误直接导致报损。'
    : `整体负面率${(stats.negativity_rate * 100).toFixed(1)}%，市场存在明确的改善需求。`;

  return `<div class="report-section opportunity-synthesis">
    <div class="synthesis-badge">核心商机</div>
    <h2 class="synthesis-headline">
      最大机会在<span class="highlight">「${top.category}」</span>
      <span class="synthesis-score">商机分数 ${top.score}</span>
    </h2>
    <div class="synthesis-grid">
      <div class="synthesis-card synthesis-card--where">
        <div class="synthesis-card-icon">&#x1F4CD;</div>
        <h4>哪里有机会？</h4>
        <p>「${top.category}」痛点频次${((top.frequency || 0) * 100).toFixed(0)}%，满足度缺口${top.satisfaction_gap || '--'}分。${stats.total_negative || 0}条负面评论中约${Math.round((top.frequency || 0) * (stats.total_negative || 0))}条与此相关，现有方案在该维度明显不足。</p>
      </div>
      <div class="synthesis-card synthesis-card--how">
        <div class="synthesis-card-icon">&#x1F3AF;</div>
        <h4>怎么切入？</h4>
        <p>${top.suggestion || `针对「${top.category}」痛点设计差异化服务方案，用可量化的服务标准（如准时率99%+赔付承诺）建立信任，在核心商圈打造标杆客户案例后快速复制。`}</p>
      </div>
      <div class="synthesis-card synthesis-card--why">
        <div class="synthesis-card-icon">&#x26A1;</div>
        <h4>为什么现在？</h4>
        <p>${seasonalNote} 付费意愿<span class="${top.willingness_to_pay === '高' ? 'willingness-high' : top.willingness_to_pay === '中' ? 'willingness-mid' : 'willingness-low'}">${top.willingness_to_pay || '中'}</span>，先行者有时间窗口建立品牌壁垒。</p>
      </div>
    </div>
    <div class="synthesis-opps">
      <h4>Top 3 商机排序</h4>
      <div class="synthesis-opp-list">
        ${opps.map((o, i) => {
          const wlCls = o.willingness_to_pay === '高' ? 'willingness-high' : o.willingness_to_pay === '中' ? 'willingness-mid' : 'willingness-low';
          return `<div class="synthesis-opp-item">
            <span class="synthesis-opp-rank">#${i + 1}</span>
            <span class="synthesis-opp-name">${o.category}</span>
            <span class="synthesis-opp-score">${o.score}分</span>
            <span class="${wlCls}" style="font-size:12px;font-weight:600">付费意愿${o.willingness_to_pay || '中'}</span>
          </div>`;
        }).join('')}
      </div>
    </div>
  </div>`;
}

// ===== AI Status Banner =====

function renderAIStatusBanner(state) {
  const bannerId = 'ai-status-banner';
  let existing = document.getElementById(bannerId);
  if (!existing) {
    existing = document.createElement('div');
    existing.id = bannerId;
    const container = document.getElementById('report-container');
    container.insertBefore(existing, container.firstChild);
  }

  const states = {
    detecting: {
      icon: '<div class="spinner" style="width:16px;height:16px;border-width:2px"></div>',
      text: '正在检测浏览器 AI 能力...',
      cls: 'ai-banner--loading',
    },
    downloading: {
      icon: '<div class="spinner" style="width:16px;height:16px;border-width:2px"></div>',
      text: '正在下载 AI 模型（首次约需下载 1.6GB，后续秒开）...',
      cls: 'ai-banner--loading',
    },
    analyzing: {
      icon: '<div class="spinner" style="width:16px;height:16px;border-width:2px"></div>',
      text: 'AI 正在分析商机数据，生成战略洞察...',
      cls: 'ai-banner--analyzing',
    },
    done: {
      icon: '&#x2713;',
      text: 'AI 分析完成 — 以下内容由浏览器本地 AI 生成，数据不会上传到任何服务器',
      cls: 'ai-banner--done',
    },
    unsupported: {
      icon: '&#x26A0;',
      text: '您的浏览器不支持 WebGPU。请使用 Chrome 113+ 或 Edge 113+ 以启用 AI 分析。当前展示基于模板的深度洞察。',
      cls: 'ai-banner--unsupported',
    },
    error: {
      icon: '&#x2717;',
      text: 'AI 模型加载失败。可能是内存不足或浏览器不支持。当前展示基于模板的深度洞察。',
      cls: 'ai-banner--error',
    },
  };

  const s = states[state] || states.unsupported;
  existing.className = `ai-status-banner ${s.cls}`;
  existing.innerHTML = `<span class="ai-banner-icon">${s.icon}</span><span>${s.text}</span>`;
}

function renderTargetMerchants(merchants) {
  if (!merchants || !merchants.length) return '';

  let merchantIdx = 0;
  const cards = merchants.map(m => {
    const score = m.match_score ?? 0;
    const level = m.match_level || (score >= 80 ? '极高' : score >= 60 ? '高' : score >= 40 ? '中' : score >= 20 ? '低' : '不匹配');
    const levelCls = level === '极高' ? 'willingness-high' : level === '高' ? 'willingness-high' : level === '中' ? 'willingness-mid' : level === '不匹配' ? 'willingness-low' : 'willingness-low';
    const barColor = score >= 80 ? 'var(--success)' : score >= 60 ? 'var(--primary-light)' : score >= 40 ? 'var(--warning)' : score >= 20 ? 'var(--danger)' : '#666';
    const urgency = m.urgency || '中';
    const urgencyCls = urgency === '高' ? 'willingness-high' : urgency === '中' ? 'willingness-mid' : 'willingness-low';
    const dd = m.delivery_detail || null;
    const idx = ++merchantIdx;

    return `<div class="merchant-card">
      <div class="merchant-card-header">
        <div class="merchant-card-rank">#${idx}</div>
        <div class="merchant-card-info">
          <div class="merchant-card-name">${escapeHTML(m.name)}${m.url ? ` <a href="${m.url}" target="_blank" rel="noopener" class="merchant-card-link">&#8599;</a>` : ''}</div>
          <div class="merchant-card-meta">
            <span class="merchant-tag">${escapeHTML(m.area)}</span>
            <span class="merchant-tag" style="background:rgba(0,0,0,0.04)">${escapeHTML(m.scale)}</span>
            <span class="merchant-tag ${urgencyCls}" style="font-size:11px">${escapeHTML(urgency)}紧迫度</span>
          </div>
        </div>
        <div class="merchant-card-score">
          <div class="merchant-score-bar">
            <div class="merchant-score-fill" style="width:${score}%;background:${barColor}"></div>
          </div>
          <span class="merchant-score-value ${levelCls}">${score} <small>${level}</small></span>
        </div>
      </div>
      <div class="merchant-card-body">
        <div class="merchant-card-need">
          <span class="merchant-need-label">配送需求</span>
          <span class="merchant-need-text">${escapeHTML(m.need)}</span>
        </div>
        ${dd ? `
        <div class="merchant-delivery-detail">
          <div class="delivery-detail-row">
            <span class="delivery-detail-icon">&#x1F69A;</span>
            <span class="delivery-detail-label">推荐车型</span>
            <span class="delivery-detail-value">${escapeHTML(dd.vehicle)}</span>
          </div>
          <div class="delivery-detail-row">
            <span class="delivery-detail-icon">&#x1F4B0;</span>
            <span class="delivery-detail-label">价格参考</span>
            <span class="delivery-detail-value">${escapeHTML(dd.price_ref)}</span>
          </div>
          <div class="delivery-detail-row">
            <span class="delivery-detail-icon">&#x1F4CD;</span>
            <span class="delivery-detail-label">配送路线</span>
            <span class="delivery-detail-value">${escapeHTML(dd.route)}</span>
          </div>
          <div class="delivery-detail-row">
            <span class="delivery-detail-icon">&#x23F0;</span>
            <span class="delivery-detail-label">时效窗口</span>
            <span class="delivery-detail-value">${escapeHTML(dd.time_window)}</span>
          </div>
          <div class="delivery-detail-row">
            <span class="delivery-detail-icon">&#x1F4CB;</span>
            <span class="delivery-detail-label">合规要求</span>
            <span class="delivery-detail-value">${escapeHTML(dd.compliance)}</span>
          </div>
        </div>` : ''}
      </div>
    </div>`;
  }).join('');

  return `<div class="report-section"><h3>目标商家清单（大连地区）</h3>
    <p style="margin-bottom:16px;font-size:13px;color:var(--text-dim)">匹配度基于配送复杂度、订单频次、地理密度、B2B占比、痛点强度、付费意愿六维度综合评分。配送依据来自大连地理知识库和行业公开数据。</p>
    <div class="merchant-cards">${cards}</div></div>`;
}

// ===== 负面评论墙 =====
let reviewWallState = { filter: 'all', search: '' };

function renderNegativeReviewWall(reviews) {
  if (!reviews || !reviews.length) return '';

  const painHigh = reviews.filter(r => r.pain_score >= 0.4).length;
  const painMid = reviews.filter(r => r.pain_score >= 0.2 && r.pain_score < 0.4).length;
  const painLow = reviews.filter(r => r.pain_score < 0.2).length;

  return `
    <div class="report-section" id="review-wall-section">
      <div class="section-toggle" onclick="this.classList.toggle('collapsed');document.getElementById('review-wall-body').classList.toggle('collapsed')">
        <h3 style="margin:0">负面评论墙 <span style="font-size:13px;color:var(--text-dim);font-weight:400">（共 ${reviews.length} 条）</span></h3>
      </div>
      <div class="section-body" id="review-wall-body" style="max-height:none">
        <div class="review-wall-toolbar">
          <div class="review-filter-pills">
            <button class="review-filter-pill active" onclick="filterReviewWall('all', this)">全部 (${reviews.length})</button>
            <button class="review-filter-pill review-filter-pill--high" onclick="filterReviewWall('high', this)">高痛感 (${painHigh})</button>
            <button class="review-filter-pill review-filter-pill--mid" onclick="filterReviewWall('mid', this)">中痛感 (${painMid})</button>
            <button class="review-filter-pill review-filter-pill--low" onclick="filterReviewWall('low', this)">低痛感 (${painLow})</button>
          </div>
          <input type="text" class="review-search-input" placeholder="搜索关键词..." oninput="searchReviewWall(this.value)" />
        </div>
        <div class="review-wall-grid" id="review-wall-grid">
          ${reviews.map((r, i) => renderReviewCard(r, i)).join('')}
        </div>
      </div>
    </div>`;
}

function renderReviewCard(r, idx) {
  const painLevel = r.pain_score >= 0.4 ? 'high' : r.pain_score >= 0.2 ? 'mid' : 'low';
  const painLabel = painLevel === 'high' ? '高痛感' : painLevel === 'mid' ? '中痛感' : '低痛感';
  const borderColor = painLevel === 'high' ? 'var(--danger)' : painLevel === 'mid' ? 'var(--warning)' : '#757575';
  const bgTint = painLevel === 'high' ? 'rgba(255,107,107,0.06)' : painLevel === 'mid' ? 'rgba(255,217,61,0.04)' : 'transparent';
  const sentimentColor = r.sentiment < 0.15 ? 'var(--danger)' : r.sentiment < 0.25 ? 'var(--warning)' : 'var(--text-dim)';

  const kwTags = (r.keywords || []).slice(0, 4).map(kw =>
    `<span class="review-kw-tag">${escapeHTML(kw)}</span>`
  ).join('');

  const ratingStars = r.rating != null
    ? '★'.repeat(Math.round(r.rating)) + '☆'.repeat(5 - Math.round(r.rating))
    : '';

  // Source label: normalize source field into human-readable labels
  const rawSource = (r.source || '').toLowerCase();
  let sourceLabel = '', sourceCls = '';
  if (rawSource.includes('web')) {
    sourceLabel = '🌐 互联网采集';
    sourceCls = 'review-source--web';
  } else if (rawSource.includes('app_store') || rawSource.includes('app store')) {
    sourceLabel = '📱 应用商店';
    sourceCls = 'review-source--app';
  } else if (rawSource.includes('ecommerce') || rawSource.includes('电商')) {
    sourceLabel = '🛒 电商平台';
    sourceCls = 'review-source--ec';
  } else if (rawSource.includes('demo') || rawSource.includes('模拟')) {
    sourceLabel = '📋 AI 模拟数据';
    sourceCls = 'review-source--demo';
  } else if (rawSource) {
    sourceLabel = '📌 ' + escapeHTML(r.source);
    sourceCls = 'review-source--other';
  } else {
    sourceLabel = '📋 模拟数据';
    sourceCls = 'review-source--demo';
  }

  return `
    <div class="review-card" data-pain="${painLevel}" data-idx="${idx}" style="border-left: 3px solid ${borderColor}; background: ${bgTint}">
      <div class="review-card-header">
        <span class="review-pain-badge review-pain-badge--${painLevel}">${painLabel} ${(r.pain_score * 100).toFixed(0)}</span>
        <span class="review-sentiment" style="color:${sentimentColor}">情感 ${(r.sentiment * 100).toFixed(0)}%</span>
        ${ratingStars ? `<span class="review-rating" style="color:var(--warning)">${ratingStars}</span>` : ''}
        <span class="review-source ${sourceCls}">${sourceLabel}</span>
      </div>
      <div class="review-card-body">${escapeHTML(r.content)}</div>
      ${kwTags ? `<div class="review-card-tags">${kwTags}</div>` : ''}
    </div>`;
}

function filterReviewWall(filter, btn) {
  reviewWallState.filter = filter;
  document.querySelectorAll('.review-filter-pill').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  applyReviewWallFilters();
}

function searchReviewWall(query) {
  reviewWallState.search = query.toLowerCase();
  applyReviewWallFilters();
}

function applyReviewWallFilters() {
  const cards = document.querySelectorAll('.review-card');
  cards.forEach(card => {
    const pain = card.dataset.pain;
    const text = card.textContent.toLowerCase();
    const painMatch = reviewWallState.filter === 'all' || pain === reviewWallState.filter;
    const searchMatch = !reviewWallState.search || text.includes(reviewWallState.search);
    card.style.display = painMatch && searchMatch ? '' : 'none';
  });
  // Update visible count
  const visible = document.querySelectorAll('.review-card[style=""]').length || document.querySelectorAll('.review-card:not([style*="display: none"])').length;
  const total = document.querySelectorAll('.review-card').length;
  // Show count if filtering
}

function escapeHTML(str) {
  if (str == null) return '';
  return String(str).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

// =============================================
// ===== 商机跟踪 v4 — SortableJS 拖拽 + 搜索 + 详情弹窗 =====
// =============================================

let oppCache = {};
let currentScope = 'active';
let currentFollowId = null;
let searchTerm = '';

const STATUS_COLORS = {
  '新线索': { cls: 'td-status--new', hex: 'var(--text-dim)' },
  '洽谈中': { cls: 'td-status--talk', hex: 'var(--primary-light)' },
  '已报价': { cls: 'td-status--quote', hex: 'var(--warning)' },
  '已成交': { cls: 'td-status--won', hex: 'var(--success)' },
  '已流失': { cls: 'td-status--lost', hex: 'var(--danger)' },
};

const KANBAN_COLS = ['新线索', '洽谈中', '已报价'];
const ALL_STATUSES = ['新线索', '洽谈中', '已报价', '已成交', '已流失'];

// ---- Init ----
(function initTracking() {
  const page = document.getElementById('page-tracking');
  if (!page) return;

  // Search
  document.getElementById('track-search').addEventListener('input', e => {
    searchTerm = e.target.value.trim().toLowerCase();
    loadTrackingBoard();
  });

  // Event delegation for all tracking page buttons
  page.addEventListener('click', e => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    e.stopPropagation();

    const action = btn.dataset.action;
    const id = btn.dataset.id;
    if (!id) return;
    const opp = oppCache[id];

    switch (action) {
      case 'new-opp': showAddForm(); break;
      case 'save-opp': saveOpportunity(); break;
      case 'close-modal': document.getElementById(btn.dataset.target).style.display = 'none'; break;
      case 'add-follow': addFollowUp(); break;
      case 'confirm-close': confirmClose(); break;
      case 'detail': showDetail(id); break;
      case 'edit': document.getElementById('detail-modal').style.display = 'none'; editOpp(id); break;
      case 'follow': document.getElementById('detail-modal').style.display = 'none'; showFollowModal(id); break;
      case 'won': document.getElementById('detail-modal').style.display = 'none'; openCloseModal(id, '已成交', opp); break;
      case 'lost': document.getElementById('detail-modal').style.display = 'none'; openCloseModal(id, '已流失', opp); break;
      case 'delete': if (confirm('确定删除？')) apiDelete(id); break;
      case 'restore': apiRestore(id); break;
      case 'purge': if (confirm('彻底删除？不可恢复！')) apiPurge(id); break;
      case 'archive': apiArchive(id); break;
      case 'unarchive': apiUnarchive(id); break;
    }
  });

  // Tab clicks
  page.addEventListener('click', e => {
    const tab = e.target.closest('.track-tab');
    if (tab && tab.dataset.scope) {
      currentScope = tab.dataset.scope;
      document.querySelectorAll('.track-tab').forEach(t => t.classList.toggle('active', t === tab));
      loadTrackingBoard();
    }
  });

  // Detail modal: clicking merchant name on kanban card
  page.addEventListener('click', e => {
    const nameEl = e.target.closest('.kanban-card-name');
    if (nameEl && nameEl.dataset.id) {
      e.stopPropagation();
      showDetail(nameEl.dataset.id);
    }
  });

  // Status field change in form
  document.getElementById('opp-status').addEventListener('change', () => {
    const st = document.getElementById('opp-status').value;
    document.getElementById('opp-lost-row').style.display = (st === '已流失') ? 'flex' : 'none';
  });
})();

// ---- Search filter ----
function matchesSearch(o) {
  if (!searchTerm) return true;
  const fields = [o.merchant_name, o.contact_person, o.contact_phone, o.notes];
  return fields.some(f => f && f.toLowerCase().includes(searchTerm));
}

// ---- API helpers ----
async function apiDelete(id) { await fetch(`${API}/track/opportunities/${id}`, { method: 'DELETE' }); loadTrackingBoard(); }
async function apiRestore(id) { await fetch(`${API}/track/opportunities/${id}/restore`, { method: 'POST' }); loadTrackingBoard(); }
async function apiPurge(id) { await fetch(`${API}/track/opportunities/${id}/purge`, { method: 'DELETE' }); loadTrackingBoard(); }
async function apiArchive(id) { await fetch(`${API}/track/opportunities/${id}/archive`, { method: 'POST' }); loadTrackingBoard(); }
async function apiUnarchive(id) { await fetch(`${API}/track/opportunities/${id}/unarchive`, { method: 'POST' }); loadTrackingBoard(); }

// ---- Form ----
function showAddForm() {
  document.getElementById('opp-modal-title').textContent = '新增商机';
  document.getElementById('opp-id').value = '';
  document.getElementById('opp-merchant').value = '';
  document.getElementById('opp-contact').value = '';
  document.getElementById('opp-phone').value = '';
  document.getElementById('opp-status').value = '新线索';
  document.getElementById('opp-deal-amount').value = '';
  document.getElementById('opp-close-reason').value = '';
  document.getElementById('opp-notes').value = '';
  document.getElementById('opp-lost-row').style.display = 'none';
  document.getElementById('opp-modal').style.display = 'flex';
}

function editOpp(id) {
  const o = oppCache[id];
  if (!o) { console.warn('editOpp: 未找到 id=' + id + ' 的商机数据，重新加载列表'); loadTrackingBoard(); return; }
  document.getElementById('opp-modal-title').textContent = '编辑商机';
  document.getElementById('opp-id').value = o.id;
  document.getElementById('opp-merchant').value = o.merchant_name || '';
  document.getElementById('opp-contact').value = o.contact_person || '';
  document.getElementById('opp-phone').value = o.contact_phone || '';
  document.getElementById('opp-status').value = o.status || '新线索';
  document.getElementById('opp-deal-amount').value = o.deal_amount || '';
  document.getElementById('opp-close-reason').value = o.close_reason || '';
  document.getElementById('opp-notes').value = o.notes || '';
  document.getElementById('opp-lost-row').style.display = (o.status === '已流失') ? 'flex' : 'none';
  document.getElementById('opp-modal').style.display = 'flex';
}

async function saveOpportunity() {
  const id = document.getElementById('opp-id').value;
  const merchant_name = document.getElementById('opp-merchant').value.trim();
  if (!merchant_name) return;
  const body = {
    merchant_name,
    contact_person: document.getElementById('opp-contact').value.trim(),
    contact_phone: document.getElementById('opp-phone').value.trim(),
    status: document.getElementById('opp-status').value,
    notes: document.getElementById('opp-notes').value.trim(),
    deal_amount: parseFloat(document.getElementById('opp-deal-amount').value) || 0,
    close_reason: document.getElementById('opp-close-reason').value.trim(),
  };
  const url = id ? `${API}/track/opportunities/${id}` : `${API}/track/opportunities`;
  const method = id ? 'PUT' : 'POST';
  await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  document.getElementById('opp-modal').style.display = 'none';
  loadTrackingBoard();
}

// ---- Detail modal ----
function showDetail(id) {
  const o = oppCache[id];
  if (!o) { console.warn('showDetail: 未找到 id=' + id + ' 的商机数据，重新加载列表'); loadTrackingBoard(); return; }
  const st = STATUS_COLORS[o.status] || STATUS_COLORS['新线索'];
  document.getElementById('detail-title').textContent = o.merchant_name;
  document.getElementById('detail-body').innerHTML = `
    <div class="detail-grid">
      <div class="detail-item">
        <div class="detail-item-label">状态</div>
        <div class="detail-item-value"><span class="td-status ${st.cls}">${o.status}</span></div>
      </div>
      <div class="detail-item">
        <div class="detail-item-label">预估金额</div>
        <div class="detail-item-value" style="color:var(--primary-light);font-weight:700">${o.deal_amount > 0 ? '¥' + Number(o.deal_amount).toLocaleString() : '未设定'}</div>
      </div>
      <div class="detail-item">
        <div class="detail-item-label">联系人</div>
        <div class="detail-item-value">${escapeHTML(o.contact_person || '—')}</div>
      </div>
      <div class="detail-item">
        <div class="detail-item-label">联系电话</div>
        <div class="detail-item-value">${escapeHTML(o.contact_phone || '—')}</div>
      </div>
      <div class="detail-item">
        <div class="detail-item-label">创建时间</div>
        <div class="detail-item-value">${(o.created_at||'').slice(0,10)}</div>
      </div>
      <div class="detail-item">
        <div class="detail-item-label">最后更新</div>
        <div class="detail-item-value">${(o.updated_at||'').slice(0,10)}</div>
      </div>
    </div>
    ${o.notes ? `<div class="detail-notes"><div class="detail-notes-label">备注</div><div class="detail-notes-text">${escapeHTML(o.notes)}</div></div>` : ''}
    ${o.close_reason ? `<div class="detail-notes"><div class="detail-notes-label">流失原因</div><div class="detail-notes-text" style="color:var(--danger)">${escapeHTML(o.close_reason)}</div></div>` : ''}
    <div class="detail-actions">
      <button class="btn-outline btn-sm" data-action="edit" data-id="${o.id}">编辑</button>
      <button class="btn-outline btn-sm" data-action="follow" data-id="${o.id}">跟进</button>
      ${o.status !== '已成交' && o.status !== '已流失' ? `
        <button class="btn-primary btn-sm" data-action="won" data-id="${o.id}">标记成交</button>
        <button class="btn-outline btn-sm" style="color:var(--danger);border-color:var(--danger)" data-action="lost" data-id="${o.id}">标记流失</button>
      ` : ''}
    </div>`;
  document.getElementById('detail-modal').style.display = 'flex';
}

// ---- Close (won/lost) ----
function openCloseModal(id, status, opp) {
  document.getElementById('close-opp-id').value = id;
  document.getElementById('close-status').value = status;
  document.getElementById('close-modal-title').textContent = status === '已成交' ? `登记成交 — ${opp?.merchant_name||''}` : `登记流失 — ${opp?.merchant_name||''}`;
  document.getElementById('close-deal-row').style.display = status === '已成交' ? 'flex' : 'none';
  document.getElementById('close-reason-row').style.display = status === '已流失' ? 'flex' : 'none';
  document.getElementById('close-deal-amount').value = opp?.deal_amount || '';
  document.getElementById('close-reason').value = opp?.close_reason || '';
  document.getElementById('close-note').value = '';
  document.getElementById('close-modal').style.display = 'flex';
}

async function confirmClose() {
  const id = document.getElementById('close-opp-id').value;
  const status = document.getElementById('close-status').value;
  await fetch(`${API}/track/opportunities/${id}/status`, {
    method: 'PUT', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      status,
      note: document.getElementById('close-note').value.trim(),
      deal_amount: parseFloat(document.getElementById('close-deal-amount').value) || 0,
      close_reason: document.getElementById('close-reason').value.trim(),
    }),
  });
  document.getElementById('close-modal').style.display = 'none';
  loadTrackingBoard();
}

// ---- Follow-up ----
async function showFollowModal(id) {
  currentFollowId = id;
  const o = oppCache[id];
  document.getElementById('follow-modal-title').textContent = `跟进 — ${o?.merchant_name||''}`;
  document.getElementById('follow-content').value = '';
  document.getElementById('follow-next-date').value = '';
  const div = document.getElementById('follow-logs');
  div.innerHTML = '<div class="loading"><div class="spinner"></div></div>';
  document.getElementById('follow-modal').style.display = 'flex';
  try {
    const resp = await fetch(`${API}/track/opportunities/${id}/logs`);
    const logs = await resp.json();
    if (!logs.length) {
      div.innerHTML = '<p style="color:var(--text-dim);font-size:13px;text-align:center;padding:20px">暂无跟进记录</p>';
    } else {
      div.innerHTML = logs.map(l => `
        <div style="background:var(--bg-input);border-radius:8px;padding:10px;margin-bottom:6px">
          <div style="font-size:11px;color:var(--text-dim);margin-bottom:3px">${l.created_at}</div>
          <div style="font-size:13px;line-height:1.6">${escapeHTML(l.content)}</div>
          ${l.next_follow_date ? `<div style="font-size:11px;color:var(--primary-light);margin-top:3px">下次跟进: ${l.next_follow_date}</div>` : ''}
        </div>`).join('');
    }
  } catch (err) { div.innerHTML = `<p style="color:var(--danger)">加载失败: ${err.message}</p>`; }
}

async function addFollowUp() {
  const content = document.getElementById('follow-content').value.trim();
  if (!content || !currentFollowId) return;
  await fetch(`${API}/track/opportunities/${currentFollowId}/logs`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ content, next_follow_date: document.getElementById('follow-next-date').value }),
  });
  showFollowModal(currentFollowId);
  loadTrackingBoard();
}

// =============================================
// ===== 渲染引擎 =====
// =============================================

async function loadTrackingBoard() {
  oppCache = {};
  document.getElementById('track-update-time').textContent = '更新于 ' + new Date().toLocaleTimeString();

  try {
    const r = await fetch(`${API}/track/stats`);
    if (!r.ok) throw new Error(await r.text());
    const s = await r.json();
    document.getElementById('stat-total').textContent = s.total;
    document.getElementById('stat-active').textContent = s.active;
    document.getElementById('stat-won').textContent = s.won;
    document.getElementById('stat-gmv').textContent = '¥' + Math.round(s.gmv).toLocaleString();
    document.getElementById('stat-winrate').textContent = s.win_rate + '%';
    document.getElementById('stat-overdue').textContent = s.overdue;

    document.getElementById('kanban-view').style.display = 'none';
    document.getElementById('list-view').style.display = 'none';

    if (currentScope === 'active') {
      await renderKanban();
    } else {
      await renderList(currentScope);
    }
  } catch (err) {
    console.error('loadTrackingBoard:', err);
  }
}

// ---- Kanban ----
async function renderKanban() {
  const resp = await fetch(`${API}/track/opportunities?scope=active`);
  if (!resp.ok) return;
  const all = await resp.json();
  all.forEach(o => { oppCache[o.id] = o; });

  const filtered = all.filter(matchesSearch);
  const board = document.getElementById('kanban-view');
  board.style.display = 'flex';
  board.innerHTML = '';

  KANBAN_COLS.forEach(col => {
    const items = filtered.filter(o => o.status === col);
    const totalDeal = items.reduce((sum, o) => sum + (o.deal_amount || 0), 0);

    const colEl = document.createElement('div');
    colEl.className = 'kanban-col';
    colEl.innerHTML = `
      <div class="kanban-col-header">
        <span class="kanban-col-title">${col}</span>
        <span class="kanban-col-badge">${items.length}${totalDeal > 0 ? ' · ¥' + Math.round(totalDeal).toLocaleString() : ''}</span>
      </div>
      <div class="kanban-col-body" data-status="${col}">
        ${items.map(o => renderKanbanCard(o)).join('')}
      </div>`;
    board.appendChild(colEl);

    // SortableJS: make each column body sortable and connect them
    new Sortable(colEl.querySelector('.kanban-col-body'), {
      group: 'pipeline',
      animation: 200,
      easing: 'cubic-bezier(0.2, 0, 0, 1)',
      ghostClass: 'sortable-ghost',
      dragClass: 'sortable-drag',
      filter: '.kanban-card-actions, .kanban-card-name',
      preventOnFilter: false,
      onEnd: async function(evt) {
        const cardEl = evt.item;
        const id = cardEl.dataset.id;
        const newStatus = evt.to.dataset.status;
        const oldStatus = evt.from.dataset.status;
        if (newStatus !== oldStatus) {
          await fetch(`${API}/track/opportunities/${id}/status`, {
            method: 'PUT', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status: newStatus, note: `拖拽: ${oldStatus} → ${newStatus}`, deal_amount: 0, close_reason: '' }),
          });
          loadTrackingBoard();
        }
      },
    });
  });

  if (!filtered.length && searchTerm) {
    board.innerHTML = `<div class="track-empty"><div class="track-empty-icon">🔍</div><div class="track-empty-text">未找到匹配 "${escapeHTML(searchTerm)}" 的商机</div></div>`;
  }
}

function renderKanbanCard(o) {
  const id = o.id;
  const overdue = o.is_overdue;
  return `<div class="kanban-card${overdue ? ' is-overdue' : ''}" data-id="${id}">
    ${overdue ? '<span class="kanban-card-badge-overdue">超期</span>' : ''}
    <div class="kanban-card-name" data-id="${id}">${escapeHTML(o.merchant_name)}</div>
    <div class="kanban-card-meta">
      ${o.contact_person ? `<span>${escapeHTML(o.contact_person)}</span>` : ''}
      ${o.contact_phone ? `<span>${escapeHTML(o.contact_phone)}</span>` : ''}
    </div>
    ${o.deal_amount > 0 ? `<div class="kanban-card-deal">¥${Number(o.deal_amount).toLocaleString()}</div>` : ''}
    <div class="kanban-card-actions">
      <button class="kanban-btn" data-action="detail" data-id="${id}">详情</button>
      <button class="kanban-btn" data-action="follow" data-id="${id}">跟进</button>
      <button class="kanban-btn kanban-btn--won" data-action="won" data-id="${id}">成交</button>
      <button class="kanban-btn kanban-btn--lost" data-action="lost" data-id="${id}">流失</button>
      <button class="kanban-btn kanban-btn--danger" data-action="delete" data-id="${id}">删除</button>
    </div>
  </div>`;
}

// ---- List (all / archived / trash) ----
async function renderList(scope) {
  const resp = await fetch(`${API}/track/opportunities?scope=${scope}`);
  if (!resp.ok) return;
  const all = await resp.json();
  all.forEach(o => { oppCache[o.id] = o; });

  const filtered = all.filter(matchesSearch);
  const list = document.getElementById('list-view');
  list.style.display = 'block';

  if (!filtered.length) {
    const msgs = { archived: '暂无已归档商机', trash: '回收站为空', all: '暂无商机' };
    list.innerHTML = `<div class="track-empty"><div class="track-empty-icon">📋</div><div class="track-empty-text">${msgs[scope]||msgs.all}</div></div>`;
    return;
  }

  const rows = filtered.map(o => {
    const st = STATUS_COLORS[o.status] || STATUS_COLORS['新线索'];
    let actions = '';
    if (scope === 'trash') {
      actions = `<button class="kanban-btn" data-action="restore" data-id="${o.id}">恢复</button>
                 <button class="kanban-btn kanban-btn--danger" data-action="purge" data-id="${o.id}">彻底删除</button>`;
    } else {
      actions = `<button class="kanban-btn" data-action="detail" data-id="${o.id}">详情</button>
                 <button class="kanban-btn" data-action="edit" data-id="${o.id}">编辑</button>
                 <button class="kanban-btn" data-action="follow" data-id="${o.id}">跟进</button>
                 ${o.archived_at && !['已成交','已流失'].includes(o.status) ? `<button class="kanban-btn" data-action="unarchive" data-id="${o.id}">撤销归档</button>` : ''}
                 <button class="kanban-btn kanban-btn--danger" data-action="delete" data-id="${o.id}">删除</button>`;
    }
    return `<tr>
      <td class="td-name" data-action="detail" data-id="${o.id}">${escapeHTML(o.merchant_name)}</td>
      <td><span class="td-status ${st.cls}">${o.status}</span></td>
      <td style="font-weight:600;color:var(--primary-light)">${o.deal_amount > 0 ? '¥' + Number(o.deal_amount).toLocaleString() : '-'}</td>
      <td>${escapeHTML(o.contact_person||'')} ${escapeHTML(o.contact_phone||'')}</td>
      <td style="color:var(--text-dim);font-size:12px">${(o.created_at||'').slice(0,10)}</td>
      <td>${actions}</td>
    </tr>`;
  }).join('');

  list.innerHTML = `<div class="track-table-wrap">
    <table class="track-table">
      <thead><tr><th>商家名称</th><th>状态</th><th>金额</th><th>联系人</th><th>创建</th><th>操作</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
  </div>`;
}